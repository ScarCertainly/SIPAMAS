<?php

namespace App\Support;

class PublicUploadedMedia
{
    public static function url(?string $value): ?string
    {
        $path = self::normalizePath($value);

        if ($path === null) {
            return null;
        }

        if (self::isExternalUrl($path)) {
            return $path;
        }

        $publicPath = PublicWebPath::path($path);
        if (is_file($publicPath)) {
            return asset($path);
        }

        $legacyStoragePath = storage_path('app/public/' . $path);
        if (is_file($legacyStoragePath)) {
            return route('uploads.show', ['path' => $path]);
        }

        return null;
    }

    public static function delete(?string $value): void
    {
        $path = self::normalizePath($value);

        if ($path === null) {
            return;
        }

        if (self::isExternalUrl($path)) {
            return;
        }

        $publicPath = PublicWebPath::path($path);
        if (is_file($publicPath)) {
            @unlink($publicPath);
            return;
        }

        $legacyStoragePath = storage_path('app/public/' . $path);
        if (is_file($legacyStoragePath)) {
            @unlink($legacyStoragePath);
        }
    }

    private static function normalizePath(?string $value): ?string
    {
        if (!$value) {
            return null;
        }

        $path = str_replace('\\', '/', trim((string) $value));

        if ($path === '') {
            return null;
        }

        if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://')) {
            return $path;
        }

        $path = ltrim($path, '/');

        if (str_starts_with($path, 'public/')) {
            $path = substr($path, 7);
        }

        if (str_starts_with($path, 'storage/')) {
            $path = substr($path, 8);
        }

        return $path !== '' ? $path : null;
    }

    private static function isExternalUrl(string $path): bool
    {
        return str_starts_with($path, 'http://') || str_starts_with($path, 'https://');
    }
}
