@php
    $manifestPath = public_path('landing/.vite/manifest.json');
    $manifest = file_exists($manifestPath)
        ? json_decode(file_get_contents($manifestPath), true)
        : [];
    $entry = $manifest['index.html'] ?? null;

    $entryCss = [];
    $visited = [];
    $collectCss = function ($key) use (&$collectCss, &$entryCss, &$visited, $manifest) {
        if (!$key || isset($visited[$key]) || !isset($manifest[$key])) {
            return;
        }
        $visited[$key] = true;
        $node = $manifest[$key];
        foreach (($node['css'] ?? []) as $cssFile) {
            if (!in_array($cssFile, $entryCss, true)) {
                $entryCss[] = $cssFile;
            }
        }
        foreach (($node['imports'] ?? []) as $importKey) {
            $collectCss($importKey);
        }
    };
    $collectCss('index.html');

    // Fallback: grab first hashed asset if manifest not present
    $cssFiles = glob(public_path('landing/assets/index-*.css'));
    $jsFiles  = glob(public_path('landing/assets/index-*.js'));
@endphp
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="color-scheme" content="light dark">
    <title>SIPAMAS - Landing & Login</title>
    <script>
        (function () {
            var storedTheme = null;
            try {
                storedTheme = localStorage.getItem('sipamas-theme');
            } catch (error) {
                storedTheme = null;
            }

            var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
            var useDark = storedTheme ? storedTheme === 'dark' : prefersDark;
            document.documentElement.classList.toggle('dark', useDark);
        })();
    </script>

    @if(!empty($entryCss))
        @foreach($entryCss as $css)
            <link rel="stylesheet" href="{{ asset('landing/' . $css) }}">
        @endforeach
    @elseif(!empty($cssFiles))
        <link rel="stylesheet" href="{{ asset('landing/assets/' . basename($cssFiles[0])) }}">
    @endif

    @if($entry && isset($entry['imports']))
        @foreach($entry['imports'] as $import)
            @php $importFile = $manifest[$import]['file'] ?? null; @endphp
            @if($importFile)
                <link rel="modulepreload" href="{{ asset('landing/' . $importFile) }}">
            @endif
        @endforeach
    @endif
</head>
<body class="min-h-screen bg-white dark:bg-slate-950">
    <div id="root"></div>

    @php
        $oldData = [
            'email' => old('email'),
            'name' => old('name'),
            'guest_name' => old('guest_name'),
            'guest_whatsapp' => old('guest_whatsapp'),
            'whatsapp_number' => old('whatsapp_number'),
        ];
        $serverErrors = $errors->toArray();
    @endphp

    <script>
        window.csrfToken = '{{ csrf_token() }}';
        window.loginPost = '{{ route('login') }}';
        window.registerPost = '{{ route('register') }}';
        window.guestLoginPost = '{{ route('guest.login') }}';
        window.passwordResetUrl = '{{ route('password.request') }}';
        window.googleRedirectUrl = '{{ route('auth.google.redirect') }}';
        window.oldData = {!! json_encode($oldData) !!};
        window.serverErrors = {!! json_encode($serverErrors) !!};
    </script>

    @if($entry)
        <script type="module" src="{{ asset('landing/' . $entry['file']) }}"></script>
    @elseif(!empty($jsFiles))
        <script type="module" src="{{ asset('landing/assets/' . basename($jsFiles[0])) }}"></script>
    @else
        <div style="padding:24px;color:#b91c1c;font-weight:600;">
            Build asset tidak ditemukan. Jalankan <code>npm run build</code> di <code>_design/LandingPageSipamas</code> lalu salin hasilnya ke <code>public/landing</code>.
        </div>
    @endif
</body>
</html>
