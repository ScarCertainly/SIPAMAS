<?php

namespace App\Support;

class PublicWebPath
{
    public static function root(): string
    {
        $configuredPath = trim((string) env('APP_PUBLIC_PATH', ''));

        if ($configuredPath !== '') {
            return self::normalize(self::resolveConfiguredPath($configuredPath));
        }

        $defaultPublicPath = public_path();
        $htdocsSiblingPath = dirname(base_path()) . DIRECTORY_SEPARATOR . 'htdocs';

        if (is_dir($htdocsSiblingPath)) {
            return self::normalize($htdocsSiblingPath);
        }

        return self::normalize($defaultPublicPath);
    }

    public static function path(string $path = ''): string
    {
        $root = self::root();
        $path = trim(str_replace('\\', '/', $path), '/');

        if ($path === '') {
            return $root;
        }

        return $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $path);
    }

    private static function resolveConfiguredPath(string $path): string
    {
        if (preg_match('/^(?:[A-Za-z]:[\\\\\\/]|\\\\\\\\|\/)/', $path) === 1) {
            return $path;
        }

        return base_path($path);
    }

    private static function normalize(string $path): string
    {
        return rtrim($path, "\\/");
    }
}
