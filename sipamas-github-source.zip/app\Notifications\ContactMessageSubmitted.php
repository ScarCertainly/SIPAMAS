<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class ContactMessageSubmitted extends Notification
{
    use Queueable;

    public function __construct(
        private string $senderName,
        private string $senderEmail,
        private string $message,
        private ?int $senderId = null,
    ) {}

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toArray(object $notifiable): array
    {
        return [
            'notification_type' => 'contact_message',
            'title' => 'Pesan Kontak SIPAMAS',
            'message' => $this->message,
            'sender_name' => $this->senderName,
            'sender_email' => $this->senderEmail,
            'sender_id' => $this->senderId,
            'action_url' => route('dashboard', ['section' => 'dashboard']) . '#pesan-kontak-admin',
            'action_label' => 'Buka Dashboard',
            'sent_at' => now()->toDateTimeString(),
        ];
    }
}
