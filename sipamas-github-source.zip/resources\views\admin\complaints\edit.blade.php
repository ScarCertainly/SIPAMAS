@extends('layouts.app')

@section('title', 'Tindak Lanjut Pengaduan')

@push('styles')
<style>
    .admin-edit-shell {
        max-width: 1180px;
        margin: 0 auto;
    }
    .admin-edit-hero {
        border: 1px solid rgba(15, 118, 110, 0.18);
        background: linear-gradient(135deg, rgba(15, 118, 110, 0.08) 0%, rgba(236, 253, 245, 0.96) 100%);
        border-radius: 18px;
        padding: 20px;
    }
    .admin-edit-title {
        font-size: clamp(1.3rem, 2.8vw, 1.95rem);
        font-weight: 800;
        color: #0f3f42;
        margin-bottom: 4px;
    }
    .admin-edit-card {
        border-radius: 22px;
        border: 1px solid rgba(15, 118, 110, 0.16);
        background: linear-gradient(180deg, rgba(255, 255, 255, 0.96) 0%, rgba(249, 253, 252, 0.96) 100%);
        box-shadow: 0 20px 35px rgba(15, 23, 42, 0.08);
        overflow: hidden;
    }
    .admin-edit-body {
        padding: 24px;
    }
    .admin-edit-label {
        font-size: 0.78rem;
        letter-spacing: 0.35px;
        text-transform: uppercase;
        font-weight: 800;
        color: #0f766e;
        margin-bottom: 8px;
    }
    .admin-edit-preview,
    .admin-edit-panel,
    .admin-edit-qr-box,
    .admin-edit-history {
        border: 1px solid rgba(15, 118, 110, 0.16);
        border-radius: 18px;
        background: rgba(240, 253, 250, 0.58);
    }
    .admin-edit-preview {
        overflow: hidden;
        aspect-ratio: 4 / 3;
    }
    .admin-edit-panel,
    .admin-edit-qr-box,
    .admin-edit-history {
        padding: 18px;
    }
    .admin-edit-summary-item + .admin-edit-summary-item {
        margin-top: 16px;
        padding-top: 16px;
        position: relative;
    }
    .admin-edit-summary-item + .admin-edit-summary-item::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: min(100%, 220px);
        height: 1px;
        background: rgba(15, 118, 110, 0.12);
    }
    .admin-edit-history-item + .admin-edit-history-item {
        margin-top: 12px;
    }
    .admin-edit-history-card {
        border: 1px solid rgba(15, 118, 110, 0.12);
        border-radius: 16px;
        padding: 12px 14px;
        background: rgba(255, 255, 255, 0.72);
    }
    #admin-complaint-qr {
        width: 180px;
        min-height: 180px;
        margin: 0 auto;
    }
    #admin-complaint-qr img,
    #admin-complaint-qr canvas {
        display: block;
        margin: 0 auto;
    }
    body.app-theme-dark .admin-edit-hero {
        border-color: rgba(45, 212, 191, 0.24);
        background: linear-gradient(135deg, rgba(20, 184, 166, 0.12) 0%, rgba(15, 23, 42, 0.92) 100%);
    }
    body.app-theme-dark .admin-edit-title {
        color: #ccfbf1;
    }
    body.app-theme-dark .admin-edit-card {
        border-color: rgba(148, 163, 184, 0.28);
        background: linear-gradient(180deg, rgba(15, 23, 42, 0.96) 0%, rgba(17, 24, 39, 0.96) 100%);
        box-shadow: 0 24px 35px rgba(2, 6, 23, 0.45);
    }
    body.app-theme-dark .admin-edit-label {
        color: #99f6e4;
    }
    body.app-theme-dark .admin-edit-preview,
    body.app-theme-dark .admin-edit-panel,
    body.app-theme-dark .admin-edit-qr-box,
    body.app-theme-dark .admin-edit-history,
    body.app-theme-dark .admin-edit-history-card {
        border-color: rgba(45, 212, 191, 0.24);
        background: rgba(15, 60, 56, 0.16);
    }
    body.app-theme-dark .admin-edit-summary-item + .admin-edit-summary-item::before {
        background: rgba(148, 163, 184, 0.16);
    }
    body.app-theme-dark .admin-edit-shell .fw-semibold,
    body.app-theme-dark .admin-edit-shell h4,
    body.app-theme-dark .admin-edit-shell p,
    body.app-theme-dark .admin-edit-shell li,
    body.app-theme-dark .admin-edit-shell div,
    body.app-theme-dark .admin-edit-shell label {
        color: #e2e8f0;
    }
    body.app-theme-dark .admin-edit-shell .text-muted,
    body.app-theme-dark .admin-edit-shell .small,
    body.app-theme-dark .admin-edit-shell .form-text {
        color: #94a3b8 !important;
    }
    @media (prefers-color-scheme: dark) {
        .admin-edit-hero {
            border-color: rgba(45, 212, 191, 0.24);
            background: linear-gradient(135deg, rgba(20, 184, 166, 0.12) 0%, rgba(15, 23, 42, 0.92) 100%);
        }
        .admin-edit-title {
            color: #ccfbf1;
        }
        .admin-edit-card {
            border-color: rgba(148, 163, 184, 0.28);
            background: linear-gradient(180deg, rgba(15, 23, 42, 0.96) 0%, rgba(17, 24, 39, 0.96) 100%);
            box-shadow: 0 24px 35px rgba(2, 6, 23, 0.45);
        }
        .admin-edit-label {
            color: #99f6e4;
        }
        .admin-edit-preview,
        .admin-edit-panel,
        .admin-edit-qr-box,
        .admin-edit-history,
        .admin-edit-history-card {
            border-color: rgba(45, 212, 191, 0.24);
            background: rgba(15, 60, 56, 0.16);
        }
        .admin-edit-summary-item + .admin-edit-summary-item::before {
            background: rgba(148, 163, 184, 0.16);
        }
    }
</style>
@endpush

@section('content')
<div class="admin-edit-shell">
    <div class="admin-edit-hero mb-4">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
            <div>
                <div class="admin-edit-title">Tindak Lanjut Pengaduan</div>
                <p class="text-muted mb-0">Perbarui status, respons resmi, dan bukti penanganan laporan pengguna.</p>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <a href="{{ route('admin.complaints.show', $complaint) }}" class="btn btn-outline-secondary btn-sm">Lihat Detail</a>
                <a href="{{ route('dashboard', ['section' => 'pengaduan']) }}" class="btn btn-outline-secondary btn-sm">Kembali</a>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="admin-edit-card">
                <div class="admin-edit-body">
                    <div class="admin-edit-label">Laporan Pengguna</div>
                    @if($complaint->image_evidence_url)
                        <div class="admin-edit-preview d-flex align-items-center justify-content-center mb-4">
                            <img src="{{ $complaint->image_evidence_url }}" alt="Lampiran" class="w-100 h-100" style="object-fit: contain;">
                        </div>
                    @endif
                    <h4 class="fw-semibold mb-3">{{ $complaint->title }}</h4>
                    <p class="mb-0 lh-lg">{{ $complaint->description }}</p>
                </div>
            </div>

            <div class="admin-edit-card mt-4">
                <div class="admin-edit-body">
                    <div class="admin-edit-label">Form Tindak Lanjut</div>
                    <form method="POST" action="{{ route('admin.complaints.update', $complaint) }}" enctype="multipart/form-data" class="d-flex flex-column gap-3">
                        @csrf
                        @method('PUT')
                        <div>
                            <label for="status" class="form-label">Status</label>
                            <select id="status" name="status" class="form-select @error('status') is-invalid @enderror">
                                <option value="pending" {{ old('status', $complaint->status) === 'pending' ? 'selected' : '' }}>Pending</option>
                                <option value="process" {{ old('status', in_array($complaint->status, ['process', 'approved'], true) ? 'process' : $complaint->status) === 'process' ? 'selected' : '' }}>Diproses</option>
                                <option value="rejected" {{ old('status', $complaint->status) === 'rejected' ? 'selected' : '' }}>Ditolak</option>
                                <option value="done" {{ old('status', $complaint->status) === 'done' ? 'selected' : '' }}>Selesai</option>
                            </select>
                            @error('status')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div>
                            <label for="admin_comment" class="form-label">Komentar Admin</label>
                            <textarea id="admin_comment" name="admin_comment" rows="3" class="form-control @error('admin_comment') is-invalid @enderror" placeholder="Catatan singkat yang juga masuk ke riwayat komentar">{{ old('admin_comment') }}</textarea>
                            @error('admin_comment')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div>
                            <label for="admin_response_message" class="form-label">Pesan Resmi ke Pelapor</label>
                            <textarea id="admin_response_message" name="admin_response_message" rows="4" class="form-control @error('admin_response_message') is-invalid @enderror" placeholder="Jelaskan hasil pengecekan, keputusan, atau arahan lanjutan">{{ old('admin_response_message', $complaint->admin_response_message) }}</textarea>
                            @error('admin_response_message')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div>
                            <label for="admin_action_taken" class="form-label">Tindakan yang Dilakukan</label>
                            <textarea id="admin_action_taken" name="admin_action_taken" rows="3" class="form-control @error('admin_action_taken') is-invalid @enderror" placeholder="Contoh: survey lapangan, koordinasi dinas, pembersihan awal, penutupan laporan">{{ old('admin_action_taken', $complaint->admin_action_taken) }}</textarea>
                            @error('admin_action_taken')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="form-check form-switch">
                            <input
                                class="form-check-input"
                                type="checkbox"
                                role="switch"
                                id="allow_user_chat"
                                name="allow_user_chat"
                                value="1"
                                {{ old('allow_user_chat', $complaint->allow_user_chat) ? 'checked' : '' }}>
                            <label class="form-check-label" for="allow_user_chat">
                                Izinkan chat user dengan admin untuk laporan ini
                            </label>
                            <div class="form-text">Saat aktif, user bisa membalas lewat menu chat pada detail pengaduannya.</div>
                        </div>
                        <div>
                            <label for="admin_response_image" class="form-label">Foto Bukti Tindak Lanjut</label>
                            <input id="admin_response_image" name="admin_response_image" type="file" accept="image/*" class="form-control @error('admin_response_image') is-invalid @enderror">
                            <div class="form-text">Opsional. Upload foto hasil penanganan, survey, atau bukti tindak lanjut admin.</div>
                            @error('admin_response_image')
                                <div class="invalid-feedback d-block">{{ $message }}</div>
                            @enderror
                            @if($complaint->admin_response_image_url)
                                <div class="admin-edit-preview mt-3 d-flex align-items-center justify-content-center">
                                    <img src="{{ $complaint->admin_response_image_url }}" alt="Bukti tindak lanjut admin" class="w-100 h-100" style="object-fit: contain;">
                                </div>
                                <div class="form-check mt-2">
                                    <input class="form-check-input" type="checkbox" value="1" id="remove_admin_response_image" name="remove_admin_response_image">
                                    <label class="form-check-label" for="remove_admin_response_image">
                                        Hapus foto tindak lanjut saat ini
                                    </label>
                                </div>
                            @endif
                        </div>
                        <button type="submit" class="btn btn-primary">Simpan Tindak Lanjut</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="admin-edit-card">
                <div class="admin-edit-body">
                    <div class="admin-edit-label">Ringkasan</div>
                    <div class="admin-edit-summary-item">
                        <div class="text-muted mb-1">Pelapor</div>
                        <div class="fw-semibold">{{ $complaint->user->name ?? '-' }}</div>
                        <div class="small text-muted">{{ $complaint->user->email ?? '' }}</div>
                    </div>
                    <div class="admin-edit-summary-item">
                        <div class="text-muted mb-1">Kategori</div>
                        <div class="fw-semibold">{{ $complaint->category->name ?? '-' }}</div>
                    </div>
                    <div class="admin-edit-summary-item">
                        <div class="text-muted mb-1">Tanggal Laporan</div>
                        <div class="fw-semibold">{{ $complaint->created_at->format('d M Y, H:i') }}</div>
                    </div>
                    <div class="admin-edit-summary-item">
                        <div class="text-muted mb-1">Respons Admin Terakhir</div>
                        @if($complaint->admin_responded_at)
                            <div class="fw-semibold">{{ $complaint->admin_responded_at->format('d M Y, H:i') }}</div>
                            <small class="text-muted">oleh {{ $complaint->adminResponder->name ?? 'Admin' }}</small>
                        @else
                            <div class="text-muted">Belum ada respons resmi.</div>
                        @endif
                    </div>
                    <div class="admin-edit-summary-item">
                        <div class="text-muted mb-2">QR Pantau Laporan</div>
                        <div class="admin-edit-qr-box">
                            <div id="admin-complaint-qr"></div>
                            <div class="small text-muted mt-2 text-center">Scan untuk membuka detail dan progres laporan ini.</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="admin-edit-card mt-4">
                <div class="admin-edit-body">
                    <div class="admin-edit-label">Riwayat Status</div>
                    <div class="admin-edit-history">
                        @forelse($complaint->statusHistories->take(5) as $history)
                            @php
                                $oldLabel = match($history->old_status) {
                                    'approved' => 'Diproses',
                                    'rejected' => 'Ditolak',
                                    'process' => 'Diproses',
                                    'done' => 'Selesai',
                                    'pending' => 'Pending',
                                    default => $history->old_status ?? '-'
                                };
                                $newLabel = match($history->new_status) {
                                    'approved' => 'Diproses',
                                    'rejected' => 'Ditolak',
                                    'process' => 'Diproses',
                                    'done' => 'Selesai',
                                    'pending' => 'Pending',
                                    default => $history->new_status ?? '-'
                                };
                            @endphp
                            <div class="admin-edit-history-item">
                                <div class="admin-edit-history-card small">
                                    <div>{{ $oldLabel }} -> <strong>{{ $newLabel }}</strong></div>
                                    <div class="text-muted">{{ $history->created_at->format('d M Y H:i') }}</div>
                                    @if($history->note)
                                        <div class="mt-1 text-muted">{{ $history->note }}</div>
                                    @endif
                                </div>
                            </div>
                        @empty
                            <div class="text-muted small">Belum ada riwayat.</div>
                        @endforelse
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <script>
        (function () {
            const target = document.getElementById('admin-complaint-qr');
            if (!target || typeof QRCode === 'undefined') {
                return;
            }

            new QRCode(target, {
                text: @json(route('admin.complaints.show', $complaint)),
                width: 180,
                height: 180,
                correctLevel: QRCode.CorrectLevel.M
            });
        })();
    </script>
@endpush
