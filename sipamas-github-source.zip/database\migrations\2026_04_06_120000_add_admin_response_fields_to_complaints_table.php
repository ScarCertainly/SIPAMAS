<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('complaints', function (Blueprint $table) {
            $table->text('admin_response_message')->nullable()->after('image_evidence');
            $table->text('admin_action_taken')->nullable()->after('admin_response_message');
            $table->string('admin_response_image')->nullable()->after('admin_action_taken');
            $table->foreignId('admin_responded_by')->nullable()->after('admin_response_image')->constrained('users')->nullOnDelete();
            $table->timestamp('admin_responded_at')->nullable()->after('admin_responded_by');
        });
    }

    public function down(): void
    {
        Schema::table('complaints', function (Blueprint $table) {
            $table->dropConstrainedForeignId('admin_responded_by');
            $table->dropColumn([
                'admin_response_message',
                'admin_action_taken',
                'admin_response_image',
                'admin_responded_at',
            ]);
        });
    }
};
