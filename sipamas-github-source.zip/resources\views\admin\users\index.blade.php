@extends('layouts.app')

@section('title', 'Daftar User Terdaftar')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-3">
    <div>
        <h3 class="mb-1">Daftar User Terdaftar</h3>
        <p class="text-muted mb-0">Cari user dan ubah role menjadi admin, user, atau blacklisted.</p>
    </div>
    <a href="{{ route('dashboard') }}" class="btn btn-outline-secondary">Kembali ke Dashboard</a>
</div>

@if (session('user_role_status'))
    <div class="alert alert-success">{{ session('user_role_status') }}</div>
@endif
@if (session('user_role_error'))
    <div class="alert alert-danger">{{ session('user_role_error') }}</div>
@endif

<div class="app-card p-3 p-md-4">
    <form method="GET" action="{{ route('admin.users.index') }}" class="row g-2 mb-3">
        <div class="col-12 col-md-8">
            <input
                type="text"
                name="user_q"
                value="{{ request('user_q') }}"
                class="form-control"
                placeholder="Cari nama atau email user"
            >
        </div>
        <div class="col-6 col-md-2">
            <button type="submit" class="btn btn-primary w-100">Cari</button>
        </div>
        <div class="col-6 col-md-2">
            <a href="{{ route('admin.users.index') }}" class="btn btn-outline-secondary w-100">Reset</a>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Terdaftar</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($users as $listedUser)
                    <tr>
                        <td>{{ $loop->iteration + (($users->currentPage() - 1) * $users->perPage()) }}</td>
                        <td>{{ $listedUser->name }}</td>
                        <td>{{ $listedUser->email }}</td>
                        <td>
                            <span class="badge {{
                                $listedUser->role === 'admin'
                                    ? 'text-bg-danger'
                                    : ($listedUser->role === 'blacklisted' ? 'text-bg-dark' : 'text-bg-primary')
                            }}">
                                {{ $listedUser->role }}
                            </span>
                        </td>
                        <td>{{ $listedUser->created_at?->format('d M Y') }}</td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    Make this user
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end p-2" style="min-width: 220px;">
                                    <li class="mb-2">
                                        <form method="POST" action="{{ route('admin.users.role.update', $listedUser) }}">
                                            @csrf
                                            @method('PATCH')
                                            <input type="hidden" name="role" value="admin">
                                            <button type="submit" class="btn btn-sm btn-outline-danger w-100" {{ $listedUser->role === 'admin' ? 'disabled' : '' }}>
                                                Make this user admin
                                            </button>
                                        </form>
                                    </li>
                                    <li>
                                        <form method="POST" action="{{ route('admin.users.role.update', $listedUser) }}">
                                            @csrf
                                            @method('PATCH')
                                            <input type="hidden" name="role" value="user">
                                            <button type="submit" class="btn btn-sm btn-outline-primary w-100" {{ $listedUser->role === 'user' || auth()->id() === $listedUser->id ? 'disabled' : '' }}>
                                                Make this user user
                                            </button>
                                        </form>
                                    </li>
                                    <li class="mt-2">
                                        <form method="POST" action="{{ route('admin.users.role.update', $listedUser) }}">
                                            @csrf
                                            @method('PATCH')
                                            <input type="hidden" name="role" value="blacklisted">
                                            <button type="submit" class="btn btn-sm btn-outline-dark w-100" {{ $listedUser->role === 'blacklisted' || auth()->id() === $listedUser->id ? 'disabled' : '' }}>
                                                Make this user blacklisted
                                            </button>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted">Belum ada user ditemukan.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="mt-3">
        {{ $users->links() }}
    </div>
</div>
@endsection
