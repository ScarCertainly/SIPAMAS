<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ComplaintController;
use App\Http\Controllers\Admin\ComplaintAdminController;
use App\Http\Controllers\Admin\UserManagementController;
use App\Notifications\ContactMessageSubmitted;
use App\Models\Category;
use App\Models\Complaint;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;
use App\Support\AuthRedirect;

/*
|--------------------------------------------------------------------------
| Landing Page
|--------------------------------------------------------------------------
| Redirect otomatis ke halaman login
*/
Route::get('/', function () {
    return redirect()->route('login');
});

Route::get('/home', function () {
    return redirect(AuthRedirect::pathFor(auth()->user()));
})->middleware('auth');

Route::middleware(['auth', 'verified', 'user'])->group(function () {
    Route::view('/tentang-kami', 'pages.about')->name('about');
    Route::view('/kontak', 'pages.contact')->name('contact');
    Route::view('/faq', 'pages.faq')->name('faq');
    Route::post('/kontak', function (Request $request) {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'email', 'max:120'],
            'message' => ['required', 'string', 'max:2000'],
        ]);

        $admins = User::query()
            ->where('role', 'admin')
            ->get();

        foreach ($admins as $admin) {
            $admin->notify(new ContactMessageSubmitted(
                senderName: $validated['name'],
                senderEmail: $validated['email'],
                message: $validated['message'],
                senderId: $request->user()?->id
            ));
        }

        return back()->with('status', 'contact-message-sent');
    })->name('contact.submit');
});

Route::get('/setting', function () {
    return view('pages.setting');
})->middleware('auth')->name('setting');

Route::patch('/setting/notifications', function (Request $request) {
    $validated = $request->validate([
        'show_notifications' => ['required', 'boolean'],
    ]);

    $request->user()->update([
        'show_notifications' => (bool) $validated['show_notifications'],
    ]);

    return back()->with('status', 'notification-preference-updated');
})->middleware('auth')->name('setting.notifications.update');

/*
|--------------------------------------------------------------------------
| Dashboard (User)
|--------------------------------------------------------------------------
| Hanya bisa diakses user login dengan role 'user'
*/
Route::get('/dashboard', function (Request $request) {
    $complaints = collect();
    $complaintTable = collect();
    $activeComplaintLocations = collect();
    $dashboardUsers = collect();
    $dashboardCategories = collect();
    $categoryStats = collect();
    $locationStats = collect();
    $monthlyStats = collect();
    $statisticsOverview = [];
    $monthlyTrendStats = collect();
    $categoryBreakdownStats = collect();
    $areaDistributionStats = collect();
    $responseTimeStats = collect();
    $resolutionRateStats = collect();
    $adminContactNotifications = collect();
    $dashboardSearch = trim((string) $request->query('q', ''));
    $dashboardUserSearch = trim((string) $request->query('user_q', ''));
    $dashboardStatus = trim((string) $request->query('status', ''));
    $dashboardCategoryId = trim((string) $request->query('category_id', ''));
    $dashboardDateFrom = trim((string) $request->query('date_from', ''));
    $dashboardDateTo = trim((string) $request->query('date_to', ''));
    $stats = [
        'total' => 0,
        'process' => 0,
        'rejected' => 0,
        'pending' => 0,
    ];

    if (auth()->check() && auth()->user()->role === 'admin') {
        $dashboardCategories = Category::query()->orderBy('name')->get(['id', 'name']);

        $applyComplaintFilters = function ($query) use ($dashboardSearch, $dashboardStatus, $dashboardCategoryId, $dashboardDateFrom, $dashboardDateTo) {
            if ($dashboardSearch !== '') {
                $query->where(function ($builder) use ($dashboardSearch) {
                    $builder->where('title', 'like', '%' . $dashboardSearch . '%')
                        ->orWhere('description', 'like', '%' . $dashboardSearch . '%')
                        ->orWhere('city', 'like', '%' . $dashboardSearch . '%')
                        ->orWhere('province', 'like', '%' . $dashboardSearch . '%')
                        ->orWhereHas('user', function ($userQuery) use ($dashboardSearch) {
                            $userQuery->where('name', 'like', '%' . $dashboardSearch . '%')
                                ->orWhere('email', 'like', '%' . $dashboardSearch . '%');
                        })
                        ->orWhereHas('category', function ($categoryQuery) use ($dashboardSearch) {
                            $categoryQuery->where('name', 'like', '%' . $dashboardSearch . '%');
                        });
                });
            }

            if ($dashboardStatus !== '') {
                if ($dashboardStatus === 'process') {
                    $query->whereIn('status', ['process', 'approved']);
                } else {
                    $query->where('status', $dashboardStatus);
                }
            }

            if ($dashboardCategoryId !== '') {
                $query->where('category_id', $dashboardCategoryId);
            }

            if ($dashboardDateFrom !== '') {
                $query->whereDate('created_at', '>=', $dashboardDateFrom);
            }

            if ($dashboardDateTo !== '') {
                $query->whereDate('created_at', '<=', $dashboardDateTo);
            }

            return $query;
        };

        $complaintQuery = Complaint::query()
            ->with(['user', 'category'])
            ->withMin('statusHistories', 'created_at');
        $applyComplaintFilters($complaintQuery);

        $complaintStatsQuery = Complaint::query();
        $applyComplaintFilters($complaintStatsQuery);

        $complaints = (clone $complaintQuery)->latest()->get();
        $complaintTable = (clone $complaintQuery)
            ->latest()
            ->paginate(12, ['*'], 'complaints_page')
            ->withQueryString();
        $activeComplaintLocations = (clone $complaintQuery)
            ->select(['id', 'title', 'status', 'latitude', 'longitude', 'street_address', 'village', 'district', 'city', 'province'])
            ->whereIn('status', ['pending', 'process', 'approved'])
            ->whereNotNull('latitude')
            ->whereNotNull('longitude')
            ->latest()
            ->get();

        $stats['total'] = (clone $complaintQuery)->count();
        $stats['process'] = (clone $complaintQuery)->whereIn('status', ['process', 'approved'])->count();
        $stats['rejected'] = (clone $complaintQuery)->where('status', 'rejected')->count();
        $stats['pending'] = (clone $complaintQuery)->where('status', 'pending')->count();

        $dashboardUsers = User::query()
            ->select(['id', 'name', 'email', 'role', 'created_at'])
            ->when($dashboardUserSearch !== '', function ($query) use ($dashboardUserSearch) {
                $query->where(function ($userQuery) use ($dashboardUserSearch) {
                    $userQuery->where('name', 'like', '%' . $dashboardUserSearch . '%')
                        ->orWhere('email', 'like', '%' . $dashboardUserSearch . '%');
                });
            })
            ->withCount('complaints')
            ->latest()
            ->paginate(12, ['*'], 'users_page')
            ->withQueryString();

        $categoryStats = (clone $complaintStatsQuery)
            ->leftJoin('categories', 'complaints.category_id', '=', 'categories.id')
            ->selectRaw('COALESCE(categories.name, "Tanpa Kategori") as label, COUNT(*) as total')
            ->groupBy('categories.name')
            ->orderByDesc('total')
            ->limit(5)
            ->get();

        $locationStats = (clone $complaintStatsQuery)
            ->selectRaw('COALESCE(city, "Lokasi belum diisi") as label, COUNT(*) as total')
            ->groupBy('city')
            ->orderByDesc('total')
            ->limit(5)
            ->get();

        $monthlyStats = (clone $complaintStatsQuery)
            ->selectRaw("DATE_FORMAT(created_at, '%Y-%m') as month_key, DATE_FORMAT(created_at, '%b %Y') as month_label, COUNT(*) as total")
            ->where('created_at', '>=', now()->subMonths(5)->startOfMonth())
            ->groupBy('month_key', 'month_label')
            ->orderBy('month_key')
            ->get();

        $currentWindowStart = now()->copy()->subMonths(5)->startOfMonth();
        $previousWindowStart = $currentWindowStart->copy()->subMonths(6);
        $previousWindowEnd = $currentWindowStart->copy()->subSecond();

        $currentWindowTotal = (clone $complaintStatsQuery)
            ->where('created_at', '>=', $currentWindowStart)
            ->count();
        $previousWindowTotal = (clone $complaintStatsQuery)
            ->whereBetween('created_at', [$previousWindowStart, $previousWindowEnd])
            ->count();
        $currentWindowResolved = (clone $complaintStatsQuery)
            ->where('created_at', '>=', $currentWindowStart)
            ->where('status', 'done')
            ->count();
        $previousWindowResolved = (clone $complaintStatsQuery)
            ->whereBetween('created_at', [$previousWindowStart, $previousWindowEnd])
            ->where('status', 'done')
            ->count();
        $resolutionRate = $currentWindowTotal > 0
            ? round(($currentWindowResolved / $currentWindowTotal) * 100, 1)
            : 0;
        $previousResolutionRate = $previousWindowTotal > 0
            ? round(($previousWindowResolved / $previousWindowTotal) * 100, 1)
            : 0;

        $resolveFirstHandledAt = function ($complaint) {
            if ($complaint->admin_responded_at) {
                return $complaint->admin_responded_at;
            }

            $historyStartedAt = $complaint->status_histories_min_created_at ?? null;

            return $historyStartedAt
                ? \Illuminate\Support\Carbon::parse($historyStartedAt)
                : null;
        };

        $handledComplaints = $complaints->filter(function ($complaint) use ($resolveFirstHandledAt) {
            return in_array($complaint->status, ['process', 'approved', 'done', 'rejected'], true)
                && $complaint->created_at
                && $resolveFirstHandledAt($complaint);
        });

        $avgResponseDays = $handledComplaints->isNotEmpty()
            ? round($handledComplaints->avg(function ($complaint) use ($resolveFirstHandledAt) {
                $handledAt = $resolveFirstHandledAt($complaint);

                return max(0, $complaint->created_at->diffInHours($handledAt) / 24);
            }), 1)
            : 0;

        $currentWindowHandled = $handledComplaints->filter(function ($complaint) use ($currentWindowStart) {
            return $complaint->created_at >= $currentWindowStart;
        });
        $previousWindowHandled = $handledComplaints->filter(function ($complaint) use ($previousWindowStart, $previousWindowEnd) {
            return $complaint->created_at >= $previousWindowStart && $complaint->created_at <= $previousWindowEnd;
        });
        $previousAvgResponseDays = $previousWindowHandled->isNotEmpty()
            ? round($previousWindowHandled->avg(function ($complaint) use ($resolveFirstHandledAt) {
                $handledAt = $resolveFirstHandledAt($complaint);

                return max(0, $complaint->created_at->diffInHours($handledAt) / 24);
            }), 1)
            : 0;

        $changePercent = function (float|int $current, float|int $previous): ?float {
            if ((float) $previous === 0.0) {
                return $current > 0 ? 100.0 : null;
            }

            return round((($current - $previous) / $previous) * 100, 1);
        };

        $statisticsOverview = [
            'total' => [
                'value' => $stats['total'],
                'change' => $changePercent($currentWindowTotal, $previousWindowTotal),
                'suffix' => '%',
                'copy' => 'vs 6 bulan sebelumnya',
            ],
            'resolution_rate' => [
                'value' => $resolutionRate,
                'change' => $changePercent($resolutionRate, $previousResolutionRate),
                'suffix' => '%',
                'copy' => 'tingkat penyelesaian',
            ],
            'avg_response_days' => [
                'value' => $avgResponseDays,
                'change' => $changePercent($avgResponseDays, $previousAvgResponseDays),
                'suffix' => ' hari',
                'copy' => 'respon rata-rata',
            ],
            'active_areas' => [
                'value' => $locationStats->count(),
                'change' => null,
                'suffix' => '',
                'copy' => 'wilayah aktif',
            ],
        ];

        $monthlyBuckets = collect(range(5, 0))->map(function ($offset) {
            $date = now()->copy()->startOfMonth()->subMonths($offset);

            return [
                'key' => $date->format('Y-m'),
                'label' => $date->translatedFormat('M'),
            ];
        });

        $monthlyTrendStats = $monthlyBuckets->map(function ($bucket) use ($complaints) {
            $items = $complaints->filter(function ($complaint) use ($bucket) {
                return optional($complaint->created_at)->format('Y-m') === $bucket['key'];
            });
            $total = $items->count();
            $resolved = $items->where('status', 'done')->count();
            $pending = $items->where('status', 'pending')->count();

            return [
                'month' => $bucket['label'],
                'total' => $total,
                'resolved' => $resolved,
                'pending' => $pending,
            ];
        })->values();

        $resolutionRateStats = $monthlyTrendStats->map(function ($item) {
            $rate = $item['total'] > 0
                ? round(($item['resolved'] / $item['total']) * 100, 1)
                : 0;

            return [
                'month' => $item['month'],
                'rate' => $rate,
            ];
        })->values();

        $categoryBreakdownStats = $categoryStats->map(function ($category) use ($stats) {
            return [
                'category' => $category->label,
                'count' => $category->total,
                'share' => ($stats['total'] ?? 0) > 0
                    ? round(($category->total / $stats['total']) * 100, 1)
                    : 0,
            ];
        })->values();

        $palette = ['#16a34a', '#3b82f6', '#8b5cf6', '#f59e0b', '#ef4444', '#6b7280'];
        $areaDistributionStats = $locationStats->values()->map(function ($location, $index) use ($stats, $palette) {
            return [
                'name' => $location->label,
                'value' => ($stats['total'] ?? 0) > 0
                    ? round(($location->total / $stats['total']) * 100, 1)
                    : 0,
                'count' => $location->total,
                'color' => $palette[$index % count($palette)],
            ];
        })->values();

        $responseTimeStats = $complaints
            ->filter(function ($complaint) {
                return $complaint->category && in_array($complaint->status, ['process', 'approved', 'done', 'rejected'], true)
                    && $complaint->created_at
                    && $complaint->updated_at;
            })
            ->groupBy(fn ($complaint) => $complaint->category->name ?? 'Tanpa Kategori')
            ->map(function ($items, $label) {
                return [
                    'category' => $label,
                    'avgTime' => round($items->avg(function ($complaint) {
                        return max(0, $complaint->created_at->diffInHours($complaint->updated_at) / 24);
                    }), 1),
                ];
            })
            ->sortByDesc('avgTime')
            ->take(5)
            ->values();

        if (Schema::hasTable('notifications')) {
            $adminContactNotifications = auth()->user()
                ->notifications()
                ->where('type', ContactMessageSubmitted::class)
                ->latest()
                ->limit(6)
                ->get();
        }
    }

    return view('dashboard', compact(
        'complaints',
        'complaintTable',
        'stats',
        'activeComplaintLocations',
        'dashboardUsers',
        'dashboardCategories',
        'categoryStats',
        'locationStats',
        'monthlyStats',
        'statisticsOverview',
        'monthlyTrendStats',
        'categoryBreakdownStats',
        'areaDistributionStats',
        'responseTimeStats',
        'resolutionRateStats',
        'adminContactNotifications',
        'dashboardSearch',
        'dashboardUserSearch',
        'dashboardStatus',
        'dashboardCategoryId',
        'dashboardDateFrom',
        'dashboardDateTo'
    ));
})->middleware(['auth', 'verified', 'user'])->name('dashboard');

Route::get('/uploads/{path}', function (string $path) {
    $fullPath = storage_path('app/public/' . ltrim($path, '/'));
    if (!is_file($fullPath)) {
        abort(404);
    }

    return response()->file($fullPath);
})->where('path', '.*')->middleware('auth')->name('uploads.show');

Route::post('/notifications/read-all', function () {
    auth()->user()->unreadNotifications->markAsRead();
    return back();
})->middleware('auth')->name('notifications.readAll');

Route::get('/notifications', function () {
    $notifications = collect();

    if (Schema::hasTable('notifications')) {
        $notifications = auth()->user()
            ->notifications()
            ->latest()
            ->paginate(12);
    }

    return view('notifications.index', compact('notifications'));
})->middleware('auth')->name('notifications.index');

/*
|--------------------------------------------------------------------------
| User Routes (Authenticated Users)
|--------------------------------------------------------------------------
| CRUD Complaint & Profile
*/
Route::middleware(['auth', 'user'])->group(function () {

    // Profile user
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    Route::get('/profil', [ProfileController::class, 'edit'])->name('profil.edit');
    Route::patch('/profil', [ProfileController::class, 'update'])->name('profil.update');
    Route::delete('/profil', [ProfileController::class, 'destroy'])->name('profil.destroy');

    // Complaint CRUD
    Route::resource('complaints', ComplaintController::class);
    Route::post('/complaints/{complaint}/chat', [ComplaintController::class, 'storeChatMessage'])
        ->name('complaints.chat.store');

});

/*
|--------------------------------------------------------------------------
| Admin Routes (Role: admin only)
|--------------------------------------------------------------------------
| Hanya admin yang bisa akses
*/
Route::middleware(['auth', 'admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {

        // Dashboard admin complaints
        Route::get('/complaints', function () {
            return redirect()->route('dashboard', ['section' => 'pengaduan']);
        })->name('complaints.index');
        Route::get('/complaints/export/csv', [ComplaintAdminController::class, 'exportCsv'])
            ->name('complaints.export.csv');
        Route::get('/complaints/{complaint}', [ComplaintAdminController::class, 'show'])
            ->name('complaints.show');
        Route::get('/complaints/{complaint}/edit', [ComplaintAdminController::class, 'edit'])
            ->name('complaints.edit');
        Route::put('/complaints/{complaint}', [ComplaintAdminController::class, 'update'])
            ->name('complaints.update');
        Route::get('/users', [UserManagementController::class, 'index'])
            ->name('users.index');
        Route::patch('/users/{user}/role', [UserManagementController::class, 'updateRole'])
            ->name('users.role.update');

        // Tambahan action admin misal verifikasi & tanggapan bisa ditambah di sini
        // Route::post('/complaints/{complaint}/verify', [ComplaintAdminController::class, 'verify'])->name('complaints.verify');
        // Route::post('/complaints/{complaint}/respond', [ComplaintAdminController::class, 'respond'])->name('complaints.respond');
    });

/*
|--------------------------------------------------------------------------
| Authentication Routes (Laravel Breeze)
|--------------------------------------------------------------------------
*/
require __DIR__ . '/auth.php';
