@extends('layouts.app')

@section('title', 'Semua Notifikasi')

@push('styles')
<style>
    .notif-page-title {
        color: #0f172a;
        font-weight: 800;
    }
    body.app-theme-dark .notif-page-title {
        color: #f8fafc;
    }
    body.app-theme-dark .app-card {
        border-color: rgba(148, 163, 184, 0.22);
    }
    body.app-theme-dark .notif-empty {
        background: linear-gradient(180deg, #0f172a 0%, #111827 100%);
        border-color: rgba(45, 212, 191, 0.24);
        color: #94a3b8 !important;
    }
    body.app-theme-dark .page-link {
        color: #cbd5e1;
        background: rgba(15, 23, 42, 0.9);
        border-color: rgba(148, 163, 184, 0.2);
    }
    body.app-theme-dark .page-link:hover {
        color: #f8fafc;
        background: rgba(15, 118, 110, 0.2);
        border-color: rgba(45, 212, 191, 0.35);
    }
    body.app-theme-dark .page-item.active .page-link {
        color: #ffffff;
        background: #0f766e;
        border-color: #0f766e;
    }
    body.app-theme-dark .page-item.disabled .page-link {
        color: #64748b;
        background: rgba(15, 23, 42, 0.75);
        border-color: rgba(148, 163, 184, 0.12);
    }
</style>
@endpush

@section('content')
@php
    $backUrl = auth()->check() && auth()->user()->role === 'admin'
        ? route('dashboard', ['section' => 'dashboard'])
        : route('complaints.index');
@endphp
<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
    <div>
        <h3 class="mb-1 notif-page-title">Semua Notifikasi</h3>
        <p class="text-muted mb-0">Riwayat notifikasi sistem, tanggapan admin, dan pesan kontak yang masuk.</p>
    </div>
    <div class="d-flex gap-2">
        <form method="POST" action="{{ route('notifications.readAll') }}">
            @csrf
            <button type="submit" class="btn btn-outline-secondary">Tandai semua dibaca</button>
        </form>
        <a href="{{ $backUrl }}" class="btn btn-primary">Kembali</a>
    </div>
</div>

<div class="app-card p-3 p-md-4">
    @forelse($notifications as $notification)
        @php
            $data = $notification->data;
            $notificationTitle = $data['title'] ?? $data['complaint_title'] ?? 'Pengaduan Lingkungan';
            $notificationPreview = $data['message'] ?? $data['comment'] ?? '-';
            $notificationSender = $data['sender_name'] ?? $data['admin_name'] ?? 'Admin';
            $notificationActionUrl = $data['action_url'] ?? route('complaints.index');
            $notificationActionLabel = $data['action_label'] ?? 'Lihat Pengaduan';
        @endphp
        <div class="notif-card {{ is_null($notification->read_at) ? 'unread' : '' }}">
            <div class="notif-headline">{{ $notificationTitle }}</div>
            <div class="text-muted small mb-2">
                {{ $notification->created_at->format('d M Y H:i') }}
            </div>
            <div class="notif-preview">
                {{ $notificationPreview }}
            </div>
            <div class="notif-meta">
                <span>Dari: {{ $notificationSender }}</span>
                @if(is_null($notification->read_at))
                    <span class="notif-pill">Baru</span>
                @else
                    <span class="small text-muted">Sudah dibaca</span>
                @endif
            </div>
            <div class="mt-2 d-flex justify-content-end">
                <a href="{{ $notificationActionUrl }}" class="btn btn-sm btn-outline-secondary py-0 px-2">{{ $notificationActionLabel }}</a>
            </div>
        </div>
    @empty
        <div class="notif-empty">Belum ada notifikasi.</div>
    @endforelse

    @if($notifications instanceof \Illuminate\Pagination\AbstractPaginator)
        <div class="mt-2">
            {{ $notifications->links() }}
        </div>
    @endif
</div>
@endsection
