<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="color-scheme" content="light dark">
    <title>SIPAMAS - Layanan Pengaduan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Plus Jakarta Sans', 'ui-sans-serif', 'system-ui'],
                    },
                },
            },
        };
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            color-scheme: light;
        }
        .grid-pattern {
            background-image:
                linear-gradient(to right, rgba(15, 118, 110, 0.08) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(15, 118, 110, 0.08) 1px, transparent 1px);
            background-size: 36px 36px;
        }
        @media (prefers-color-scheme: dark) {
            body {
                background-image: linear-gradient(to bottom right, #0f172a, #111827, #0f172a) !important;
                color: #e5e7eb !important;
            }
            header {
                background-color: rgba(15, 23, 42, 0.9) !important;
                border-color: #334155 !important;
            }
            section.bg-slate-50 {
                background-color: #0b1220 !important;
            }
            footer {
                background-color: #020617 !important;
            }
            .text-gray-900 {
                color: #f8fafc !important;
            }
            .text-gray-700,
            .text-gray-600 {
                color: #cbd5e1 !important;
            }
            .border-gray-200,
            .border-gray-100,
            .border-gray-800,
            .border-teal-100,
            .border-slate-200 {
                border-color: #334155 !important;
            }
            .bg-white\/80 {
                background-color: rgba(15, 23, 42, 0.9) !important;
            }
            .bg-white {
                background-color: #0f172a !important;
            }
            .bg-teal-50 {
                background-color: rgba(13, 148, 136, 0.12) !important;
            }
            .hover\:bg-teal-50:hover {
                background-color: rgba(13, 148, 136, 0.2) !important;
            }
            .text-teal-600 {
                color: #2dd4bf !important;
            }
            .bg-teal-600 {
                background-color: #0f766e !important;
            }
            .bg-teal-100 {
                background-color: rgba(13, 148, 136, 0.18) !important;
            }
            .grid-pattern {
                background-image:
                    linear-gradient(to right, rgba(45, 212, 191, 0.12) 1px, transparent 1px),
                    linear-gradient(to bottom, rgba(45, 212, 191, 0.12) 1px, transparent 1px);
            }
        }
    </style>
</head>
<body class="min-h-screen bg-gradient-to-br from-cyan-50 via-white to-teal-50 text-gray-900">
    @php
        $isAdmin = auth()->user()?->role === 'admin';
        $complaintListUrl = route('dashboard', ['section' => 'pengaduan']);
    @endphp

    <header class="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md z-50 border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <div class="w-12 h-12 bg-teal-600 rounded-xl flex items-center justify-center">
                    <i data-lucide="leaf" class="w-7 h-7 text-white"></i>
                </div>
                <div>
                    <h1 class="font-bold text-gray-900">SIPAMAS</h1>
                    <p class="text-xs text-gray-600">DINAS LINGKUNGAN</p>
                </div>
            </div>
            <nav class="hidden md:flex gap-6 items-center">
                <a href="{{ route('home') }}" class="text-gray-700 font-medium">Beranda</a>
                <a href="{{ $complaintListUrl }}" class="text-gray-600 hover:text-teal-600 transition">Pengaduan</a>
                <a href="{{ route('profil.edit') }}" class="text-gray-600 hover:text-teal-600 transition">Edit Profil</a>
            </nav>
        </div>
        <div class="max-w-7xl mx-auto px-6 pb-3 md:hidden">
            <div class="flex flex-wrap gap-2">
                <a href="{{ $complaintListUrl }}" class="text-sm border border-teal-600 text-teal-600 hover:bg-teal-50 px-3 py-2 rounded-lg transition">Pengaduan</a>
                <a href="{{ route('profil.edit') }}" class="text-sm border border-gray-300 text-gray-700 hover:bg-gray-50 px-3 py-2 rounded-lg transition">Profil</a>
            </div>
        </div>
    </header>

    <section class="relative overflow-hidden pt-32 pb-20 px-6">
        <div class="absolute inset-0">
            <img src="https://images.unsplash.com/photo-1641941672934-9e33a79ec482?auto=format&fit=crop&w=2000&q=80" alt="Lanskap hijau" class="w-full h-full object-cover opacity-65">
            <div class="absolute inset-0 bg-gradient-to-br from-white/55 via-white/65 to-teal-50/55"></div>
        </div>
        <div class="relative max-w-7xl mx-auto">
            <div class="grid lg:grid-cols-2 gap-12 items-center">
                <div class="space-y-8">
                    <span class="inline-flex bg-teal-100 text-teal-700 px-4 py-2 rounded-full text-sm font-semibold">
                        Platform Pengaduan Lingkungan
                    </span>

                    <h1 class="text-5xl md:text-6xl font-bold text-gray-900 leading-tight">
                        SIPAMAS
                        <span class="block text-teal-600">Kanal Pengaduan Masyarakat</span>
                    </h1>

                    <p class="text-xl text-gray-600 leading-relaxed">
                        Platform pengaduan lingkungan hidup masyarakat untuk mendukung layanan Dinas Lingkungan Hidup yang responsif dan transparan.
                    </p>

                    <div class="flex flex-wrap gap-4">
                        @if($isAdmin)
                            <a href="{{ route('dashboard') }}" class="bg-teal-600 hover:bg-teal-700 text-white px-8 py-4 text-lg rounded-lg inline-flex items-center group transition">
                                Pergi ke Dashboard
                                <i data-lucide="arrow-right" class="ml-2 w-5 h-5 group-hover:translate-x-1 transition"></i>
                            </a>
                        @else
                            <a href="{{ route('complaints.create') }}" class="bg-teal-600 hover:bg-teal-700 text-white px-8 py-4 text-lg rounded-lg inline-flex items-center group transition">
                                Buat Pengaduan
                                <i data-lucide="arrow-right" class="ml-2 w-5 h-5 group-hover:translate-x-1 transition"></i>
                            </a>
                        @endif
                        <a href="{{ $complaintListUrl }}" class="border-2 border-teal-600 text-teal-600 hover:bg-teal-50 px-8 py-4 text-lg rounded-lg inline-flex items-center transition">
                            Lihat Komplain
                        </a>
                    </div>

                    <div class="grid grid-cols-3 gap-6 pt-6">
                        <div>
                            <div class="text-3xl font-bold text-teal-600">1,234+</div>
                            <div class="text-sm text-gray-600">Aduan Selesai</div>
                        </div>
                        <div>
                            <div class="text-3xl font-bold text-teal-600">98%</div>
                            <div class="text-sm text-gray-600">Kepuasan</div>
                        </div>
                        <div>
                            <div class="text-3xl font-bold text-teal-600">24/7</div>
                            <div class="text-sm text-gray-600">Layanan</div>
                        </div>
                    </div>
                </div>

                <div class="relative">
                    <div class="relative rounded-3xl overflow-hidden shadow-2xl">
                        <img
                            src="https://images.unsplash.com/photo-1641941672934-9e33a79ec482?auto=format&fit=crop&w=1600&q=80"
                            alt="Environment"
                            class="w-full h-[360px] md:h-[500px] object-cover">
                        <div class="absolute inset-0 bg-gradient-to-t from-teal-900/40 to-transparent"></div>
                    </div>
                    <div class="absolute -bottom-8 -left-8 bg-white rounded-2xl shadow-xl p-6 max-w-xs border border-gray-100">
                        <div class="flex items-center gap-4">
                            <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                                <i data-lucide="check-circle-2" class="w-6 h-6 text-green-600"></i>
                            </div>
                            <div>
                                <div class="font-bold text-gray-900">Cepat & Terpercaya</div>
                                <div class="text-sm text-gray-600">Respon dalam 24 jam</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="py-20 px-6 bg-white">
        <div class="max-w-7xl mx-auto">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-gray-900 mb-4">Fitur Unggulan</h2>
                <p class="text-xl text-gray-600">Solusi lengkap untuk pengelolaan lingkungan hidup</p>
            </div>

            <div class="grid md:grid-cols-3 gap-8">
                <article class="p-8 hover:shadow-xl transition border-2 border-gray-100 rounded-2xl">
                    <div class="w-16 h-16 bg-teal-100 rounded-2xl flex items-center justify-center mb-6">
                        <i data-lucide="shield" class="w-8 h-8 text-teal-600"></i>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-900 mb-4">Pemantauan Lingkungan</h3>
                    <p class="text-gray-600 leading-relaxed mb-6">
                        Pantau kondisi lingkungan secara real-time dengan sistem monitoring terintegrasi.
                    </p>
                    <a href="{{ $complaintListUrl }}" class="text-teal-600 font-medium inline-flex items-center hover:gap-2 transition-all">
                        Pelajari Lebih Lanjut
                        <i data-lucide="arrow-right" class="ml-1 w-4 h-4"></i>
                    </a>
                </article>

                <article class="p-8 hover:shadow-xl transition border-2 border-gray-100 rounded-2xl">
                    <div class="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mb-6">
                        <i data-lucide="file-text" class="w-8 h-8 text-blue-600"></i>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-900 mb-4">Respon Cepat Aduan</h3>
                    <p class="text-gray-600 leading-relaxed mb-6">
                        Sistem tanggapan cepat untuk menangani setiap aduan masyarakat dengan efektif.
                    </p>
                    <a href="{{ $complaintListUrl }}" class="text-blue-600 font-medium inline-flex items-center hover:gap-2 transition-all">
                        Pelajari Lebih Lanjut
                        <i data-lucide="arrow-right" class="ml-1 w-4 h-4"></i>
                    </a>
                </article>

                <article class="p-8 hover:shadow-xl transition border-2 border-gray-100 rounded-2xl">
                    <div class="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mb-6">
                        <i data-lucide="bar-chart-3" class="w-8 h-8 text-purple-600"></i>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-900 mb-4">Data untuk Kebijakan</h3>
                    <p class="text-gray-600 leading-relaxed mb-6">
                        Analisis data komprehensif untuk mendukung pengambilan keputusan berbasis data.
                    </p>
                    <a href="{{ $complaintListUrl }}" class="text-purple-600 font-medium inline-flex items-center hover:gap-2 transition-all">
                        Pelajari Lebih Lanjut
                        <i data-lucide="arrow-right" class="ml-1 w-4 h-4"></i>
                    </a>
                </article>
            </div>
        </div>
    </section>

    <section class="py-20 px-6">
        <div class="max-w-5xl mx-auto">
            <div class="bg-gradient-to-r from-teal-600 to-cyan-600 rounded-3xl p-12 md:p-16 text-center relative overflow-hidden">
                <div class="absolute inset-0 opacity-10">
                    <img
                        src="https://images.unsplash.com/photo-1677943356981-bc48941c5ba9?auto=format&fit=crop&w=1600&q=80"
                        alt="City"
                        class="w-full h-full object-cover">
                </div>
                <div class="relative z-10 space-y-6">
                    <h2 class="text-4xl md:text-5xl font-bold text-white">
                        Mulai Berkontribusi untuk Lingkungan Lebih Baik
                    </h2>
                    <p class="text-xl text-teal-50 max-w-2xl mx-auto">
                        Laporkan masalah lingkungan di sekitar Anda dan bantu kami menciptakan kota yang lebih bersih dan sehat.
                    </p>
                    <a href="{{ route('complaints.create') }}" class="inline-flex bg-white text-teal-600 hover:bg-gray-100 px-10 py-4 text-lg font-semibold rounded-lg transition">
                        Mulai Sekarang
                    </a>
                </div>
            </div>
        </div>
    </section>

    <footer class="bg-gray-900 text-gray-300 py-12 px-6">
        <div class="max-w-7xl mx-auto">
            <div class="grid md:grid-cols-4 gap-8 mb-8">
                <div>
                    <div class="flex items-center gap-3 mb-4">
                        <div class="w-10 h-10 bg-teal-600 rounded-lg flex items-center justify-center">
                            <i data-lucide="leaf" class="w-6 h-6 text-white"></i>
                        </div>
                        <div>
                            <div class="font-bold text-white">SIPAMAS</div>
                            <div class="text-xs">DINAS LINGKUNGAN</div>
                        </div>
                    </div>
                    <p class="text-sm">
                        Adaptasi kanal pengaduan masyarakat berbasis layanan pemerintah daerah.
                    </p>
                </div>

                <div>
                    <h4 class="font-bold text-white mb-4">Layanan</h4>
                    <ul class="space-y-2 text-sm">
                        <li><a href="{{ $complaintListUrl }}" class="hover:text-teal-400 transition">Pengaduan</a></li>
                        <li><a href="{{ route('dashboard') }}" class="hover:text-teal-400 transition">Dashboard</a></li>
                        <li><a href="{{ route('notifications.index') }}" class="hover:text-teal-400 transition">Notifikasi</a></li>
                    </ul>
                </div>

                <div>
                    <h4 class="font-bold text-white mb-4">Informasi</h4>
                    <ul class="space-y-2 text-sm">
                        <li><a href="{{ route('about') }}" class="hover:text-teal-400 transition">Tentang Kami</a></li>
                        <li><a href="{{ route('contact') }}" class="hover:text-teal-400 transition">Kontak</a></li>
                        <li><a href="{{ route('faq') }}" class="hover:text-teal-400 transition">FAQ</a></li>
                    </ul>
                </div>

                <div>
                    <h4 class="font-bold text-white mb-4">Kontak</h4>
                    <ul class="space-y-2 text-sm">
                        <li>Email: pengaduan@ecovoice.local</li>
                        <li>Telp: (024) 0000-0000</li>
                        <li>Senin - Jumat: 08:00 - 17:00</li>
                    </ul>
                </div>
            </div>

            <div class="border-t border-gray-800 pt-8 text-center text-sm">
                <p>&copy; 2026 SIPAMAS Dinas Lingkungan. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
        window.lucide.createIcons();
    </script>
</body>
</html>
