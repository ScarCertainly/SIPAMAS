<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class UserManagementController extends Controller
{
    public function index(Request $request): View
    {
        $usersQuery = User::query()->select(['id', 'name', 'email', 'role', 'created_at']);

        if ($request->filled('user_q')) {
            $keyword = trim((string) $request->user_q);
            $usersQuery->where(function ($builder) use ($keyword) {
                $builder->where('name', 'like', '%' . $keyword . '%')
                    ->orWhere('email', 'like', '%' . $keyword . '%');
            });
        }

        $users = $usersQuery->latest()->paginate(12)->withQueryString();

        return view('admin.users.index', compact('users'));
    }

    public function updateRole(Request $request, User $user): RedirectResponse
    {
        $validated = $request->validate([
            'role' => ['required', 'in:user,admin,blacklisted'],
        ]);

        if ((int) auth()->id() === (int) $user->id && $validated['role'] !== 'admin') {
            return back()->with('user_role_error', 'Role akun yang sedang dipakai tidak bisa diturunkan.');
        }

        $user->update([
            'role' => $validated['role'],
        ]);

        return back()->with('user_role_status', 'Role user berhasil diperbarui.');
    }
}
