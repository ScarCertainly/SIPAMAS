# Deploy ke InfinityFree

Panduan ini menyiapkan struktur Laravel yang aman untuk shared hosting InfinityFree: kode aplikasi disimpan di luar `htdocs`, sedangkan isi folder `public` dipindah ke `htdocs`.

## Yang sudah diringankan

- Halaman guest Breeze tidak lagi memuat bundle React besar.
- `laravel/tinker` dipindahkan ke `require-dev`, jadi tidak ikut paket produksi jika `composer install --no-dev`.
- Tersedia template env produksi di `.env.infinityfree.example`.
- Tersedia skrip packaging di `scripts/prepare-infinityfree.ps1`.

## Persiapan lokal

1. Salin `.env.infinityfree.example` menjadi `.env` sementara untuk staging produksi, atau copy nilainya ke file deploy Anda.
2. Isi `APP_KEY`, database InfinityFree, URL domain, SMTP, dan kredensial Google jika login Google dipakai.
   Untuk struktur deploy `app` sejajar `htdocs`, biarkan `APP_PUBLIC_PATH=../htdocs`.
3. Build aset Laravel utama:

```powershell
npm run build
```

4. Jika landing page di `public/landing` berubah, rebuild juga project desainnya lalu salin hasilnya lagi ke `public/landing`.
5. Install vendor produksi agar paket upload lebih ringan:

```powershell
composer install --no-dev --optimize-autoloader
```

6. Cache konfigurasi dan route secara lokal:

```powershell
php artisan config:clear
php artisan route:clear
php artisan view:clear
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

## Buat paket upload

Jalankan:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\prepare-infinityfree.ps1
```

Hasilnya akan ada di `_deploy/infinityfree` dengan struktur:

- `_deploy/infinityfree/app`
- `_deploy/infinityfree/htdocs`

## Upload ke InfinityFree

1. Upload folder `_deploy/infinityfree/app` ke folder di luar `htdocs`.
   Contoh yang disarankan: `/app`, sehingga posisinya sejajar dengan `/htdocs`.
2. Upload seluruh isi `_deploy/infinityfree/htdocs` ke `htdocs`.
3. Pastikan `htdocs/index.php` tetap menunjuk ke:

```php
require __DIR__.'/../app/vendor/autoload.php';
$app = require_once __DIR__.'/../app/bootstrap/app.php';
```

Jika lokasi folder `app` Anda berbeda, sesuaikan path ini.

## Wajib dicek setelah upload

- File `.env` ada di folder aplikasi (`app/.env`), bukan di `htdocs`.
- Folder ini ada dan writable:
  - `storage/framework/cache/data`
  - `storage/framework/sessions`
  - `storage/framework/views`
  - `storage/logs`
  - `bootstrap/cache`
- `APP_DEBUG=false`
- `QUEUE_CONNECTION=sync`
- `CACHE_DRIVER=file`
- `SESSION_DRIVER=file`
- `FILESYSTEM_DISK=local`

## Catatan penting InfinityFree

- Jangan andalkan queue worker, Redis, supervisor, atau websocket.
- Jalankan migrasi dari lokal memakai koneksi database InfinityFree, karena shell server biasanya tidak tersedia.
- Jangan upload `node_modules`, `tests`, `_design`, atau file lokal seperti `.env` development.
- Upload foto proyek ini disimpan langsung ke `uploads/...` pada web root publik lewat `App\Support\PublicImageUpload`, jadi tidak perlu symlink `public/storage`.
- Folder `uploads` pada web root publik dibuat otomatis saat upload pertama (`mkdir` rekursif), dan file langsung bisa diakses via `asset('uploads/...')`.
- Route `/uploads/...` sekarang hanya dipertahankan sebagai fallback untuk file lama yang dulu sempat tersimpan di `storage/app/public`.
