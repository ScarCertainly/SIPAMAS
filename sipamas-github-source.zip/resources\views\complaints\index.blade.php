@extends('layouts.app')

@section('title', 'Pengaduan Lingkungan Saya')

@push('styles')
<style>
    .user-page-shell {
        max-width: 1120px;
        margin: 0 auto;
    }
    .user-page-eyebrow {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        font-size: 0.8rem;
        font-weight: 800;
        letter-spacing: 0.16em;
        text-transform: uppercase;
        color: #0f766e;
        margin-bottom: 14px;
    }
    .user-page-eyebrow-badge {
        width: 44px;
        height: 44px;
        border-radius: 14px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #0f766e 0%, #16a34a 100%);
        color: #fff;
        box-shadow: 0 14px 26px rgba(22, 163, 74, 0.2);
    }
    .user-page-hero {
        position: relative;
        border: 1px solid rgba(148, 163, 184, 0.22);
        background: linear-gradient(135deg, rgba(255, 255, 255, 0.92) 0%, rgba(240, 253, 250, 0.94) 48%, rgba(224, 242, 254, 0.92) 100%);
        border-radius: 28px;
        padding: 28px;
        margin-bottom: 24px;
        overflow: hidden;
        box-shadow: 0 28px 60px rgba(15, 23, 42, 0.08);
    }
    .user-page-hero::before,
    .user-page-hero::after {
        content: "";
        position: absolute;
        border-radius: 999px;
        filter: blur(26px);
        pointer-events: none;
    }
    .user-page-hero::before {
        width: 220px;
        height: 220px;
        right: -70px;
        top: -70px;
        background: rgba(20, 184, 166, 0.16);
    }
    .user-page-hero::after {
        width: 180px;
        height: 180px;
        left: -60px;
        bottom: -60px;
        background: rgba(22, 163, 74, 0.12);
    }
    .user-page-title {
        font-size: clamp(1.5rem, 3vw, 2.2rem);
        font-weight: 800;
        color: #0f172a;
        margin-bottom: 8px;
    }
    .user-page-copy {
        max-width: 620px;
        color: #475569;
        margin-bottom: 0;
    }
    .user-page-card {
        border-radius: 28px;
        border: 1px solid rgba(148, 163, 184, 0.2);
        background: rgba(255, 255, 255, 0.94);
        box-shadow: 0 24px 46px rgba(15, 23, 42, 0.08);
        overflow: hidden;
        backdrop-filter: blur(10px);
    }
    .user-page-stats {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 16px;
        margin-bottom: 24px;
    }
    .user-page-stat-card {
        position: relative;
        border-radius: 22px;
        border: 1px solid rgba(148, 163, 184, 0.2);
        background: rgba(255, 255, 255, 0.92);
        padding: 18px 20px;
        box-shadow: 0 20px 36px rgba(15, 23, 42, 0.06);
        overflow: hidden;
    }
    .user-page-stat-card::after {
        content: "";
        position: absolute;
        inset: auto -20px -28px auto;
        width: 86px;
        height: 86px;
        border-radius: 999px;
        opacity: 0.14;
        pointer-events: none;
    }
    .user-page-stat-card.total::after {
        background: #16a34a;
    }
    .user-page-stat-card.process::after {
        background: #3b82f6;
    }
    .user-page-stat-card.done::after {
        background: #22c55e;
    }
    .user-page-stat-card.pending::after {
        background: #f59e0b;
    }
    .user-page-stat-label {
        color: #64748b;
        font-size: 0.82rem;
        font-weight: 600;
    }
    .user-page-stat-value {
        margin-top: 10px;
        font-size: 2rem;
        line-height: 1;
        font-weight: 800;
        color: #0f172a;
    }
    .user-page-stat-meta {
        margin-top: 10px;
        font-size: 0.8rem;
        color: #475569;
    }
    .user-page-toolbar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        flex-wrap: wrap;
        margin-bottom: 18px;
        padding: 2px 4px 0;
    }
    .user-page-toolbar-title {
        margin: 0;
        font-size: 1.05rem;
        font-weight: 800;
        color: #0f172a;
    }
    .user-page-toolbar-copy {
        margin: 4px 0 0;
        color: #64748b;
        font-size: 0.86rem;
    }
    .user-page-chip {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 8px 12px;
        border-radius: 999px;
        border: 1px solid rgba(148, 163, 184, 0.26);
        background: rgba(248, 250, 252, 0.9);
        color: #475569;
        font-size: 0.8rem;
        font-weight: 700;
    }
    .user-page-search .input-group {
        padding: 6px;
        border-radius: 18px;
        background: rgba(255, 255, 255, 0.82);
        border: 1px solid rgba(148, 163, 184, 0.24);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.7);
    }
    .user-page-search .form-control {
        border: 0;
        background: transparent;
        min-height: 48px;
    }
    .user-page-search .form-control:focus {
        box-shadow: none;
    }
    .user-page-table thead th {
        border-bottom: 0;
        color: #64748b;
        font-size: 0.76rem;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        font-weight: 800;
    }
    .user-page-table td,
    .user-page-table th {
        padding-top: 18px;
        padding-bottom: 18px;
    }
    .user-page-title-cell {
        min-width: 240px;
    }
    .user-page-item-title {
        font-weight: 700;
        color: #0f172a;
    }
    .user-page-item-subtitle {
        margin-top: 4px;
        font-size: 0.86rem;
        color: #64748b;
    }
    .user-page-item-meta {
        margin-top: 8px;
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
    }
    .user-page-item-pill {
        display: inline-flex;
        align-items: center;
        border-radius: 999px;
        padding: 6px 10px;
        background: #f8fafc;
        color: #475569;
        font-size: 0.76rem;
        font-weight: 700;
        border: 1px solid rgba(148, 163, 184, 0.2);
    }
    .user-page-status {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 8px 12px;
        border-radius: 999px;
        font-size: 0.78rem;
        font-weight: 700;
        border: 1px solid transparent;
    }
    .user-page-status.pending {
        background: #fef3c7;
        border-color: #fde68a;
        color: #92400e;
    }
    .user-page-status.process {
        background: #dbeafe;
        border-color: #bfdbfe;
        color: #1d4ed8;
    }
    .user-page-status.done {
        background: #dcfce7;
        border-color: #bbf7d0;
        color: #166534;
    }
    .user-page-status.rejected {
        background: #fee2e2;
        border-color: #fecaca;
        color: #b91c1c;
    }
    .user-page-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
    }
    .user-page-empty {
        padding: 44px 24px;
        text-align: center;
        color: #64748b;
    }
    .user-page-empty-title {
        font-size: 1.1rem;
        font-weight: 800;
        color: #0f172a;
        margin-bottom: 8px;
    }
    .user-page-pagination {
        margin-top: 20px;
    }
    .user-page-pagination nav > div:first-child {
        display: none;
    }
    body.app-theme-dark .user-page-eyebrow {
        color: #99f6e4;
    }
    body.app-theme-dark .user-page-eyebrow-badge {
        box-shadow: 0 14px 26px rgba(20, 184, 166, 0.18);
    }
    body.app-theme-dark .user-page-hero {
        border-color: rgba(45, 212, 191, 0.24);
        background: linear-gradient(135deg, rgba(15, 23, 42, 0.96) 0%, rgba(15, 60, 56, 0.4) 50%, rgba(14, 116, 144, 0.26) 100%);
    }
    body.app-theme-dark .user-page-title {
        color: #f8fafc;
    }
    body.app-theme-dark .user-page-copy {
        color: #cbd5e1;
    }
    body.app-theme-dark .user-page-card,
    body.app-theme-dark .user-page-stat-card {
        border-color: rgba(148, 163, 184, 0.28);
        background: linear-gradient(180deg, rgba(15, 23, 42, 0.96) 0%, rgba(17, 24, 39, 0.96) 100%);
    }
    body.app-theme-dark .user-page-stat-label,
    body.app-theme-dark .user-page-toolbar-copy,
    body.app-theme-dark .user-page-chip,
    body.app-theme-dark .user-page-empty,
    body.app-theme-dark .text-muted {
        color: #94a3b8 !important;
    }
    body.app-theme-dark .user-page-stat-value,
    body.app-theme-dark .user-page-toolbar-title,
    body.app-theme-dark .user-page-empty-title,
    body.app-theme-dark .user-page-item-title {
        color: #f8fafc;
    }
    body.app-theme-dark .user-page-stat-meta,
    body.app-theme-dark .user-page-item-pill,
    body.app-theme-dark .user-page-item-subtitle {
        color: #cbd5e1;
    }
    body.app-theme-dark .user-page-chip,
    body.app-theme-dark .user-page-item-pill {
        background: rgba(15, 23, 42, 0.65);
        border-color: rgba(148, 163, 184, 0.24);
    }
    body.app-theme-dark .user-page-search .input-group {
        background: rgba(15, 23, 42, 0.72);
        border-color: rgba(148, 163, 184, 0.26);
    }
    body.app-theme-dark .user-page-search .form-control,
    body.app-theme-dark .user-page-search .form-control::placeholder {
        color: #e2e8f0;
    }
    body.app-theme-dark .user-page-table .table {
        color: #e2e8f0;
        --bs-table-bg: transparent;
        --bs-table-color: #e2e8f0;
        --bs-table-border-color: rgba(148, 163, 184, 0.18);
        --bs-table-striped-bg: rgba(30, 41, 59, 0.38);
        --bs-table-striped-color: #f8fafc;
        --bs-table-hover-bg: rgba(45, 212, 191, 0.08);
        --bs-table-hover-color: #f8fafc;
    }
    body.app-theme-dark .user-page-table tbody tr {
        border-color: rgba(148, 163, 184, 0.18);
    }
    body.app-theme-dark .user-page-table td {
        color: #e2e8f0;
    }
    body.app-theme-dark .btn-outline-secondary {
        color: #cbd5e1;
        border-color: rgba(148, 163, 184, 0.32);
        background: rgba(15, 23, 42, 0.48);
    }
    body.app-theme-dark .btn-outline-secondary:hover,
    body.app-theme-dark .btn-outline-secondary:focus,
    body.app-theme-dark .btn-outline-secondary:active {
        color: #f8fafc;
        border-color: rgba(45, 212, 191, 0.4);
        background: rgba(15, 118, 110, 0.22);
    }
    body.app-theme-dark .btn-outline-danger {
        color: #fecaca;
        border-color: rgba(248, 113, 113, 0.42);
        background: rgba(69, 10, 10, 0.18);
    }
    body.app-theme-dark .btn-outline-danger:hover,
    body.app-theme-dark .btn-outline-danger:focus,
    body.app-theme-dark .btn-outline-danger:active {
        color: #fff1f2;
        background: rgba(185, 28, 28, 0.28);
        border-color: rgba(248, 113, 113, 0.52);
    }
    body.app-theme-dark .btn-primary {
        background: linear-gradient(135deg, #0f766e 0%, #16a34a 100%);
        border-color: transparent;
        box-shadow: 0 16px 30px rgba(15, 118, 110, 0.26);
    }
    body.app-theme-dark .btn-primary:hover,
    body.app-theme-dark .btn-primary:focus,
    body.app-theme-dark .btn-primary:active {
        background: linear-gradient(135deg, #0d9488 0%, #15803d 100%);
        border-color: transparent;
    }
    body.app-theme-dark .alert-success {
        color: #dcfce7;
        background: rgba(20, 83, 45, 0.55);
        border-color: rgba(74, 222, 128, 0.3);
    }
    body.app-theme-dark .page-link {
        color: #cbd5e1;
        background: rgba(15, 23, 42, 0.9);
        border-color: rgba(148, 163, 184, 0.2);
    }
    body.app-theme-dark .page-link:hover {
        color: #f8fafc;
        background: rgba(15, 118, 110, 0.2);
        border-color: rgba(45, 212, 191, 0.35);
    }
    body.app-theme-dark .page-item.active .page-link {
        color: #ffffff;
        background: #0f766e;
        border-color: #0f766e;
    }
    body.app-theme-dark .page-item.disabled .page-link {
        color: #64748b;
        background: rgba(15, 23, 42, 0.75);
        border-color: rgba(148, 163, 184, 0.12);
    }
    @media (max-width: 991.98px) {
        .user-page-stats {
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }
    }
    @media (max-width: 767.98px) {
        .user-page-stats {
            grid-template-columns: 1fr;
        }
        .user-page-table table {
            min-width: 760px;
        }
    }
</style>
@endpush

@section('content')
<div class="user-page-shell">
    <div class="user-page-hero">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
            <div>
                <div class="user-page-eyebrow">
                    <span class="user-page-eyebrow-badge">
                        <x-application-logo class="h-5 w-5 text-white" />
                    </span>
                    SIPAMAS • Pengaduan Saya
                </div>
                <h3 class="user-page-title">Pengaduan Lingkungan Saya</h3>
                <p class="user-page-copy">Pantau semua laporan yang Anda kirimkan dengan tampilan yang sejalur dengan landing page SIPAMAS.</p>
            </div>
            <div class="d-flex gap-2">
                @if(auth()->check() && auth()->user()->role === 'admin')
                    <a href="{{ route('dashboard') }}" class="btn btn-outline-secondary">Admin Dashboard</a>
                @endif
                <a href="{{ route('complaints.create') }}" class="btn btn-primary">+ Lapor Lingkungan</a>
            </div>
        </div>
        <form method="GET" action="{{ route('complaints.index') }}" class="mt-4 user-page-search">
            <div class="input-group">
                <input
                    type="text"
                    name="q"
                    value="{{ $keyword ?? request('q') }}"
                    class="form-control"
                    placeholder="Cari pengaduan berdasarkan judul atau deskripsi..."
                >
                <button type="submit" class="btn btn-outline-secondary">Cari</button>
                @if(request()->filled('q'))
                    <a href="{{ route('complaints.index') }}" class="btn btn-outline-danger">Reset</a>
                @endif
            </div>
        </form>
    </div>

    <div class="user-page-stats">
        <div class="user-page-stat-card total">
            <div class="user-page-stat-label">Total Pengaduan</div>
            <div class="user-page-stat-value">{{ number_format($summary['total'] ?? 0, 0, ',', '.') }}</div>
            <div class="user-page-stat-meta">Semua laporan yang pernah Anda kirim.</div>
        </div>
        <div class="user-page-stat-card process">
            <div class="user-page-stat-label">Sedang Diproses</div>
            <div class="user-page-stat-value">{{ number_format($summary['process'] ?? 0, 0, ',', '.') }}</div>
            <div class="user-page-stat-meta">Termasuk status diproses dan disetujui.</div>
        </div>
        <div class="user-page-stat-card done">
            <div class="user-page-stat-label">Selesai</div>
            <div class="user-page-stat-value">{{ number_format($summary['done'] ?? 0, 0, ',', '.') }}</div>
            <div class="user-page-stat-meta">Laporan yang sudah ditindaklanjuti tuntas.</div>
        </div>
        <div class="user-page-stat-card pending">
            <div class="user-page-stat-label">Menunggu Tinjauan</div>
            <div class="user-page-stat-value">{{ number_format($summary['pending'] ?? 0, 0, ',', '.') }}</div>
            <div class="user-page-stat-meta">
                {{ ($summary['rejected'] ?? 0) > 0 ? number_format($summary['rejected'], 0, ',', '.') . ' ditolak' : 'Belum termasuk laporan yang ditolak.' }}
            </div>
        </div>
    </div>

    <div class="user-page-card p-3 p-md-4">
        @if(session('status'))
            <div class="alert alert-success">{{ session('status') }}</div>
        @endif
        <div class="user-page-toolbar">
            <div>
                <h4 class="user-page-toolbar-title">Daftar Pengaduan</h4>
                <p class="user-page-toolbar-copy">
                    {{ $complaints->total() }} laporan
                    @if(!empty($keyword))
                        ditemukan untuk kata kunci "{{ $keyword }}"
                    @else
                        tersusun dari yang terbaru.
                    @endif
                </p>
            </div>
            <span class="user-page-chip">
                {{ $complaints->count() }} tampil di halaman ini
            </span>
        </div>
        <div class="table-responsive user-page-table">
            <table class="table align-middle mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Judul</th>
                        <th>Kategori</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($complaints as $complaint)
                    @php
                        $statusClass = match($complaint->status) {
                            'approved', 'process' => 'process',
                            'rejected' => 'rejected',
                            'done' => 'done',
                            default => 'pending'
                        };
                        $statusLabel = match($complaint->status) {
                            'approved', 'process' => 'Diproses',
                            'rejected' => 'Ditolak',
                            'done' => 'Selesai',
                            default => 'Menunggu'
                        };
                    @endphp
                    <tr>
                        <td>{{ $complaints->firstItem() + $loop->index }}</td>
                        <td class="user-page-title-cell">
                            <div class="user-page-item-title">{{ $complaint->title }}</div>
                            <div class="user-page-item-subtitle">{{ \Illuminate\Support\Str::limit($complaint->description, 72) }}</div>
                            <div class="user-page-item-meta">
                                <span class="user-page-item-pill">{{ $complaint->category->name ?? 'Kategori belum dipilih' }}</span>
                                <span class="user-page-item-pill">{{ $complaint->created_at->diffForHumans() }}</span>
                            </div>
                        </td>
                        <td>{{ $complaint->category->name ?? '-' }}</td>
                        <td>
                            <span class="user-page-status {{ $statusClass }}">{{ $statusLabel }}</span>
                        </td>
                        <td>{{ $complaint->created_at->translatedFormat('d M Y') }}</td>
                        <td>
                            <div class="user-page-actions">
                                <a href="{{ route('complaints.show', $complaint) }}" class="btn btn-sm btn-primary">Detail</a>
                                <a href="{{ route('complaints.edit', $complaint) }}" class="btn btn-sm btn-outline-secondary">Perbarui</a>
                                <form action="{{ route('complaints.destroy', $complaint) }}" method="POST" onsubmit="return confirm('Hapus pengaduan ini?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-outline-danger">Hapus</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="user-page-empty">
                            <div class="user-page-empty-title">Belum ada pengaduan yang cocok</div>
                            <div>
                                @if(!empty($keyword))
                                    Coba gunakan kata kunci lain atau reset pencarian untuk melihat semua laporan Anda.
                                @else
                                    Buat laporan pertama Anda agar proses pemantauan pengaduan bisa dimulai dari sini.
                                @endif
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($complaints->hasPages())
            <div class="user-page-pagination">
                {{ $complaints->links() }}
            </div>
        @endif
    </div>
</div>
@endsection
