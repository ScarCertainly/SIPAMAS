<?php

namespace App\Support;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Str;

class PublicImageUpload
{
    public static function store(UploadedFile $file, string $folder, string $prefix, int $maxDimension = 1600): string
    {
        $folder = trim(str_replace('\\', '/', $folder), '/');
        $directory = PublicWebPath::path('uploads/' . $folder);

        if (!is_dir($directory)) {
            mkdir($directory, 0755, true);
        }

        $extension = self::resolveExtension($file);
        $filename = $prefix . '_' . now()->format('Ymd_His') . '_' . Str::random(8) . '.' . $extension;
        $targetPath = $directory . DIRECTORY_SEPARATOR . $filename;

        if (!self::optimize($file, $targetPath, $extension, $maxDimension)) {
            $file->move($directory, $filename);
        }

        return 'uploads/' . ($folder !== '' ? $folder . '/' : '') . $filename;
    }

    private static function resolveExtension(UploadedFile $file): string
    {
        return match ($file->getMimeType()) {
            'image/jpeg', 'image/jpg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp',
            'image/gif' => 'gif',
            default => strtolower($file->getClientOriginalExtension() ?: 'jpg'),
        };
    }

    private static function optimize(UploadedFile $file, string $targetPath, string $extension, int $maxDimension): bool
    {
        if (!function_exists('getimagesize') || !function_exists('imagecreatetruecolor')) {
            return false;
        }

        $sourcePath = $file->getRealPath();
        if (!$sourcePath) {
            return false;
        }

        $imageInfo = @getimagesize($sourcePath);
        if (!$imageInfo) {
            return false;
        }

        [$width, $height] = $imageInfo;
        if (!$width || !$height) {
            return false;
        }

        $mime = $imageInfo['mime'] ?? null;
        $source = match ($mime) {
            'image/jpeg' => function_exists('imagecreatefromjpeg') ? @imagecreatefromjpeg($sourcePath) : false,
            'image/png' => function_exists('imagecreatefrompng') ? @imagecreatefrompng($sourcePath) : false,
            'image/webp' => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($sourcePath) : false,
            default => false,
        };

        if (!$source) {
            return false;
        }

        $ratio = min(1, $maxDimension / $width, $maxDimension / $height);
        $targetWidth = max(1, (int) round($width * $ratio));
        $targetHeight = max(1, (int) round($height * $ratio));

        $canvas = imagecreatetruecolor($targetWidth, $targetHeight);

        if (in_array($mime, ['image/png', 'image/webp'], true)) {
            imagealphablending($canvas, false);
            imagesavealpha($canvas, true);
            $transparent = imagecolorallocatealpha($canvas, 0, 0, 0, 127);
            imagefilledrectangle($canvas, 0, 0, $targetWidth, $targetHeight, $transparent);
        }

        imagecopyresampled($canvas, $source, 0, 0, 0, 0, $targetWidth, $targetHeight, $width, $height);

        $saved = match ($extension) {
            'jpg', 'jpeg' => function_exists('imagejpeg') ? @imagejpeg($canvas, $targetPath, 82) : false,
            'png' => function_exists('imagepng') ? @imagepng($canvas, $targetPath, 7) : false,
            'webp' => function_exists('imagewebp') ? @imagewebp($canvas, $targetPath, 80) : false,
            default => false,
        };

        imagedestroy($source);
        imagedestroy($canvas);

        return (bool) $saved;
    }
}
