@extends('layouts.app')

@section('title', 'Tentang SIPAMAS')

@push('styles')
<style>
    .sipamas-hero {
        text-align: center;
        margin-bottom: 2.5rem;
    }
    .sipamas-hero h2 {
        font-size: clamp(2rem, 3.2vw, 2.8rem);
        font-weight: 800;
        color: #0f172a;
        margin-bottom: 0.5rem;
    }
    .sipamas-hero p {
        color: #64748b;
        max-width: 720px;
        margin: 0 auto;
        font-size: 1.05rem;
    }
    .sipamas-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 18px;
        margin-bottom: 28px;
    }
    .sipamas-card {
        background: #ffffff;
        border: 1px solid rgba(148, 163, 184, 0.2);
        border-radius: 18px;
        padding: 22px;
        box-shadow: 0 12px 26px rgba(15, 23, 42, 0.06);
        transition: 0.2s ease;
    }
    .sipamas-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 18px 32px rgba(15, 23, 42, 0.08);
    }
    .sipamas-icon {
        width: 54px;
        height: 54px;
        border-radius: 14px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
        margin-bottom: 12px;
        color: #0f766e;
        background: #ecfeff;
    }
    .sipamas-banner {
        background: linear-gradient(90deg, #14b8a6 0%, #0ea5e9 100%);
        color: #ffffff;
        border-radius: 22px;
        padding: 28px;
        box-shadow: 0 20px 36px rgba(14, 165, 233, 0.2);
    }
    .sipamas-banner p {
        opacity: 0.9;
    }
    .sipamas-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 16px;
        margin-top: 20px;
    }
    .sipamas-stat strong {
        display: block;
        font-size: 2rem;
    }
</style>
@endpush

@section('content')
<div class="app-card p-4 p-md-5">
    <div class="sipamas-hero">
        <h2>Tentang SIPAMAS</h2>
        <p>
            Sistem Informasi Pengaduan Masyarakat yang membantu pelaporan, pemantauan, dan tindak lanjut isu
            lingkungan secara transparan dan terstruktur.
        </p>
    </div>

    <div class="sipamas-grid">
        <div class="sipamas-card">
            <div class="sipamas-icon">📣</div>
            <h5 class="mb-2">Pelaporan Cepat</h5>
            <p class="text-muted mb-0">
                Warga dapat membuat laporan lingkungan dengan cepat, jelas, dan terdokumentasi.
            </p>
        </div>
        <div class="sipamas-card">
            <div class="sipamas-icon">🧭</div>
            <h5 class="mb-2">Pemantauan Status</h5>
            <p class="text-muted mb-0">
                Pantau progres laporan dari masuk, diproses, hingga selesai secara real-time.
            </p>
        </div>
        <div class="sipamas-card">
            <div class="sipamas-icon">✅</div>
            <h5 class="mb-2">Transparansi</h5>
            <p class="text-muted mb-0">
                Riwayat penanganan tercatat agar keputusan lebih akuntabel dan terbuka.
            </p>
        </div>
    </div>

    <div class="sipamas-banner">
        <h3 class="mb-3">Visi & Misi SIPAMAS</h3>
        <p class="mb-3">
            Mewujudkan kolaborasi pemerintah dan masyarakat dalam menangani masalah lingkungan secara cepat,
            terukur, dan transparan melalui sistem informasi terintegrasi.
        </p>
        <div class="sipamas-stats">
            <div class="sipamas-stat">
                <strong>120+</strong>
                <div>Pengaduan Tertangani</div>
            </div>
            <div class="sipamas-stat">
                <strong>35+</strong>
                <div>Wilayah Aktif</div>
            </div>
            <div class="sipamas-stat">
                <strong>24/7</strong>
                <div>Monitoring</div>
            </div>
        </div>
    </div>
</div>
@endsection
