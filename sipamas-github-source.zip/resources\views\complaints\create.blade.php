@extends('layouts.app')

@section('title', 'Buat Pengaduan')

@push('styles')
<style>
    .create-complaint-shell {
        max-width: 1120px;
        margin: 0 auto;
    }
    .create-hero {
        border: 1px solid rgba(15, 118, 110, 0.2);
        background: linear-gradient(135deg, rgba(15, 118, 110, 0.08) 0%, rgba(8, 145, 178, 0.08) 100%);
        border-radius: 18px;
        padding: 20px;
    }
    .create-title {
        color: #0f3f42;
        font-size: clamp(1.35rem, 3vw, 2rem);
        font-weight: 800;
        margin-bottom: 4px;
    }
    .create-subtitle {
        color: #336066;
        margin-bottom: 0;
    }
    .create-grid {
        display: grid;
        grid-template-columns: minmax(0, 1.55fr) minmax(290px, 0.85fr);
        gap: 24px;
    }
    .create-form-card,
    .create-side-card {
        border-radius: 22px;
        border: 1px solid rgba(15, 118, 110, 0.16);
        background: linear-gradient(180deg, rgba(255, 255, 255, 0.96) 0%, rgba(249, 253, 252, 0.96) 100%);
        box-shadow: 0 20px 35px rgba(15, 23, 42, 0.08);
        overflow: hidden;
    }
    .create-form-header,
    .create-side-header {
        border-bottom: 1px solid rgba(15, 118, 110, 0.14);
        background: rgba(240, 253, 250, 0.8);
        padding: 20px 24px;
    }
    .create-form-body,
    .create-side-body {
        padding: 24px;
    }
    .create-form-label {
        font-weight: 700;
        color: #164e52;
        margin-bottom: 8px;
    }
    .create-form-hint {
        color: #0f766e;
        font-size: 0.83rem;
        margin-top: 6px;
    }
    .create-input,
    .create-input:focus,
    .create-select,
    .create-select:focus {
        border-color: rgba(13, 148, 136, 0.28);
        box-shadow: none;
    }
    .create-input:focus,
    .create-select:focus {
        border-color: rgba(13, 148, 136, 0.65);
        box-shadow: 0 0 0 0.2rem rgba(13, 148, 136, 0.12);
    }
    .location-box {
        border: 1px solid rgba(15, 118, 110, 0.16);
        border-radius: 16px;
        background: rgba(240, 253, 250, 0.42);
        padding: 16px;
    }
    .section-label {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        font-size: 0.78rem;
        letter-spacing: 0.35px;
        text-transform: uppercase;
        font-weight: 800;
        color: #0f766e;
        margin-bottom: 8px;
    }
    .create-side-item + .create-side-item {
        border-top: 1px solid rgba(15, 118, 110, 0.12);
        margin-top: 16px;
        padding-top: 16px;
    }
    .create-side-title {
        font-weight: 700;
        color: #0f3f42;
        margin-bottom: 4px;
    }
    .create-side-copy,
    .create-checklist {
        color: #475569;
        font-size: 0.92rem;
        line-height: 1.7;
    }
    .create-checklist {
        margin: 0;
        padding-left: 18px;
    }
    .create-checklist li + li {
        margin-top: 8px;
    }
    .file-chip {
        font-size: 0.86rem;
        color: #475569;
    }
    .image-preview-box {
        margin-top: 14px;
        border: 1px solid rgba(15, 118, 110, 0.16);
        border-radius: 18px;
        background: rgba(240, 253, 250, 0.52);
        overflow: hidden;
        max-width: 360px;
        aspect-ratio: 4 / 3;
        display: none;
    }
    .image-preview-box.is-visible {
        display: block;
    }
    .image-preview-box img {
        width: 100%;
        height: 100%;
        object-fit: contain;
        display: block;
    }
    @media (max-width: 991.98px) {
        .create-grid {
            grid-template-columns: 1fr;
        }
    }
    body.app-theme-dark .create-hero {
        border-color: rgba(45, 212, 191, 0.24);
        background: linear-gradient(135deg, rgba(20, 184, 166, 0.12) 0%, rgba(14, 116, 144, 0.14) 100%);
    }
    body.app-theme-dark .create-title,
    body.app-theme-dark .create-form-label,
    body.app-theme-dark .create-side-title,
    body.app-theme-dark .create-form-header .fw-semibold,
    body.app-theme-dark .create-side-header .fw-semibold {
        color: #ecfeff;
    }
    body.app-theme-dark .create-subtitle,
    body.app-theme-dark .section-label {
        color: #99f6e4;
    }
    body.app-theme-dark .create-form-card,
    body.app-theme-dark .create-side-card {
        border-color: rgba(148, 163, 184, 0.28);
        background: linear-gradient(180deg, rgba(15, 23, 42, 0.96) 0%, rgba(17, 24, 39, 0.96) 100%);
        box-shadow: 0 24px 35px rgba(2, 6, 23, 0.45);
    }
    body.app-theme-dark .create-form-header,
    body.app-theme-dark .create-side-header {
        border-bottom-color: rgba(45, 212, 191, 0.22);
        background: rgba(15, 60, 56, 0.22);
    }
    body.app-theme-dark .create-form-hint,
    body.app-theme-dark .file-chip,
    body.app-theme-dark .create-side-copy,
    body.app-theme-dark .create-checklist,
    body.app-theme-dark .create-form-header .small,
    body.app-theme-dark .create-side-header .small,
    body.app-theme-dark .text-muted {
        color: #94a3b8 !important;
    }
    body.app-theme-dark .create-input,
    body.app-theme-dark .create-select {
        background-color: #0b1220;
        border-color: rgba(148, 163, 184, 0.35);
        color: #e2e8f0;
    }
    body.app-theme-dark .create-input::placeholder {
        color: #64748b;
    }
    body.app-theme-dark .create-select option {
        background: #0b1220;
        color: #e2e8f0;
    }
    body.app-theme-dark .location-box,
    body.app-theme-dark .image-preview-box {
        border-color: rgba(45, 212, 191, 0.24);
        background: rgba(15, 60, 56, 0.16);
    }
    body.app-theme-dark .location-box .form-label,
    body.app-theme-dark .location-box .text-danger,
    body.app-theme-dark .create-form-body,
    body.app-theme-dark .create-side-body {
        color: #dbeafe;
    }
    body.app-theme-dark .badge.bg-info {
        background: rgba(59, 130, 246, 0.2) !important;
        color: #bfdbfe !important;
    }
    body.app-theme-dark .btn-light {
        background: #162132;
        border-color: rgba(148, 163, 184, 0.24);
        color: #e2e8f0;
    }
    body.app-theme-dark .btn-light:hover {
        background: #1e293b;
        color: #f8fafc;
    }
</style>
@endpush

@section('content')
<div class="create-complaint-shell">
    <div class="create-hero mb-4">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
            <div>
                <div class="section-label">SIPAMAS | Form Pengaduan</div>
                <h3 class="create-title">Buat Pengaduan Lingkungan</h3>
                <p class="create-subtitle">Sampaikan laporan kondisi lingkungan secara jelas dan akurat.</p>
            </div>
            <a href="{{ route('complaints.index') }}" class="btn btn-outline-secondary btn-sm">Lihat Pengaduan</a>
        </div>
    </div>

    <div class="create-grid">
        <div class="create-form-card">
            <div class="create-form-header d-flex justify-content-between align-items-center flex-wrap gap-2">
                <div>
                    <div class="fw-semibold">Detail Laporan</div>
                    <div class="small text-muted">Isi data berikut agar tim bisa menindaklanjuti lebih cepat.</div>
                </div>
                <span class="badge bg-info">Form Pelapor</span>
            </div>
            <div class="create-form-body">
                <form method="POST" action="{{ route('complaints.store') }}" enctype="multipart/form-data">
                    @csrf

                    <div class="mb-3">
                        <label for="title" class="form-label create-form-label">Judul</label>
                        <input id="title" name="title" type="text" class="form-control create-input @error('title') is-invalid @enderror" placeholder="Masukkan judul pengaduan" value="{{ old('title') }}" required>
                        @error('title')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="category_id" class="form-label create-form-label">Kategori Lingkungan</label>
                        <select id="category_id" name="category_id" class="form-select create-select @error('category_id') is-invalid @enderror" required>
                            <option value="" disabled {{ old('category_id') ? '' : 'selected' }}>Pilih kategori laporan</option>
                            @foreach($categories as $category)
                                <option value="{{ $category->id }}" {{ old('category_id') == $category->id ? 'selected' : '' }}>
                                    {{ $category->name }}
                                </option>
                            @endforeach
                        </select>
                        @error('category_id')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label create-form-label">Deskripsi</label>
                        <textarea id="description" name="description" rows="5" class="form-control create-input @error('description') is-invalid @enderror" placeholder="Jelaskan lokasi, waktu kejadian, dan dampak lingkungan" required>{{ old('description') }}</textarea>
                        @error('description')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label class="form-label create-form-label">Lokasi Kejadian</label>
                        <div class="location-box">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="province" class="form-label">Provinsi (opsional)</label>
                                    <input id="province" name="province" type="text" class="form-control create-input @error('province') is-invalid @enderror" value="{{ old('province') }}" placeholder="Contoh: Jawa Barat">
                                    @error('province')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="col-md-6">
                                    <label for="city" class="form-label">Kota/Kabupaten (opsional)</label>
                                    <input id="city" name="city" type="text" class="form-control create-input @error('city') is-invalid @enderror" value="{{ old('city') }}" placeholder="Contoh: Kota Bandung">
                                    @error('city')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="col-md-6">
                                    <label for="district" class="form-label">Kecamatan (opsional)</label>
                                    <input id="district" name="district" type="text" class="form-control create-input @error('district') is-invalid @enderror" value="{{ old('district') }}" placeholder="Contoh: Coblong">
                                    @error('district')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="col-md-6">
                                    <label for="village" class="form-label">Desa/Kelurahan (opsional)</label>
                                    <input id="village" name="village" type="text" class="form-control create-input @error('village') is-invalid @enderror" value="{{ old('village') }}" placeholder="Contoh: Dago">
                                    @error('village')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="col-12">
                                    <label for="street_address" class="form-label">Jalan / Detail Alamat</label>
                                    <textarea id="street_address" name="street_address" rows="2" class="form-control create-input @error('street_address') is-invalid @enderror" placeholder="Contoh: Jl. Ir. H. Juanda No. 120">{{ old('street_address') }}</textarea>
                                    @error('street_address')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="col-12">
                                    <input type="hidden" id="latitude" name="latitude" value="{{ old('latitude') }}">
                                    <input type="hidden" id="longitude" name="longitude" value="{{ old('longitude') }}">
                                    <button type="button" id="use-current-location" class="btn btn-outline-secondary btn-sm">Gunakan Lokasi Aktif (GPS)</button>
                                    <div id="gps-status" class="create-form-hint">
                                        @if(old('latitude') && old('longitude'))
                                            Lokasi GPS terisi: {{ old('latitude') }}, {{ old('longitude') }}
                                        @else
                                            Belum mengambil lokasi GPS.
                                        @endif
                                    </div>
                                    @error('latitude')
                                        <div class="text-danger small mt-1">{{ $message }}</div>
                                    @enderror
                                    @error('longitude')
                                        <div class="text-danger small mt-1">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="image_evidence" class="form-label create-form-label">Foto Bukti (opsional)</label>
                        <input id="image_evidence" name="image_evidence" type="file" class="form-control create-input @error('image_evidence') is-invalid @enderror" accept="image/*">
                        <div id="image-evidence-name" class="file-chip mt-2">Belum ada file dipilih.</div>
                        <div id="image-evidence-preview-box" class="image-preview-box">
                            <img id="image-evidence-preview" src="" alt="Preview foto bukti">
                        </div>
                        @error('image_evidence')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="d-flex justify-content-end gap-2">
                        <a href="{{ route('complaints.index') }}" class="btn btn-light">Batal</a>
                        <button type="submit" id="submit-complaint-btn" class="btn btn-primary px-4">
                            <span class="btn-label">Kirim</span>
                            <span class="btn-loading d-none">Mengirim...</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <div class="d-flex flex-column gap-4">
            <div class="create-side-card">
                <div class="create-side-header">
                    <div class="fw-semibold">Panduan Singkat</div>
                    <div class="small text-muted">Bantu admin memahami kondisi lapangan sejak awal.</div>
                </div>
                <div class="create-side-body">
                    <div class="create-side-item">
                        <div class="create-side-title">Jelaskan masalah secara spesifik</div>
                        <div class="create-side-copy">Sebutkan jenis gangguan, dampak, dan kondisi lokasi agar laporan tidak terlalu umum.</div>
                    </div>
                    <div class="create-side-item">
                        <div class="create-side-title">Lengkapi alamat dan GPS</div>
                        <div class="create-side-copy">Alamat manual wajib diisi. Titik GPS akan sangat membantu petugas saat verifikasi lapangan.</div>
                    </div>
                    <div class="create-side-item">
                        <div class="create-side-title">Tambahkan foto bila tersedia</div>
                        <div class="create-side-copy">Foto bukti mempermudah pengecekan awal dan mempercepat penanganan laporan.</div>
                    </div>
                </div>
            </div>

            <div class="create-side-card">
                <div class="create-side-header">
                    <div class="fw-semibold">Sebelum Mengirim</div>
                    <div class="small text-muted">Periksa kualitas isi laporan Anda.</div>
                </div>
                <div class="create-side-body">
                    <ul class="create-checklist">
                        <li>Pastikan judul mewakili masalah utama di lokasi.</li>
                        <li>Gunakan deskripsi yang singkat, padat, dan mudah diverifikasi.</li>
                        <li>Hindari foto buram atau tidak relevan dengan pengaduan.</li>
                        <li>Status laporan bisa dipantau kembali dari halaman detail pengaduan.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    (function () {
        const gpsButton = document.getElementById('use-current-location');
        const latInput = document.getElementById('latitude');
        const lngInput = document.getElementById('longitude');
        const statusText = document.getElementById('gps-status');
        const complaintForm = document.querySelector('form[action="{{ route('complaints.store') }}"]');
        const submitBtn = document.getElementById('submit-complaint-btn');
        const submitLabel = submitBtn ? submitBtn.querySelector('.btn-label') : null;
        const submitLoading = submitBtn ? submitBtn.querySelector('.btn-loading') : null;
        const imageEvidenceInput = document.getElementById('image_evidence');
        const imageEvidenceName = document.getElementById('image-evidence-name');
        const imageEvidencePreviewBox = document.getElementById('image-evidence-preview-box');
        const imageEvidencePreview = document.getElementById('image-evidence-preview');

        if (imageEvidenceInput && imageEvidenceName && imageEvidencePreviewBox && imageEvidencePreview) {
            imageEvidenceInput.addEventListener('change', function () {
                const hasFile = this.files && this.files.length;
                imageEvidenceName.textContent = hasFile ? this.files[0].name : 'Belum ada file dipilih.';

                if (!hasFile) {
                    imageEvidencePreview.setAttribute('src', '');
                    imageEvidencePreviewBox.classList.remove('is-visible');
                    return;
                }

                const objectUrl = URL.createObjectURL(this.files[0]);
                imageEvidencePreview.setAttribute('src', objectUrl);
                imageEvidencePreviewBox.classList.add('is-visible');
            });
        }

        if (complaintForm && submitBtn && submitLabel && submitLoading) {
            complaintForm.addEventListener('submit', function () {
                submitBtn.setAttribute('disabled', 'disabled');
                submitLabel.classList.add('d-none');
                submitLoading.classList.remove('d-none');
            });
        }

        if (!gpsButton || !latInput || !lngInput || !statusText) {
            return;
        }

        gpsButton.addEventListener('click', function () {
            if (!navigator.geolocation) {
                statusText.textContent = 'Browser tidak mendukung geolocation.';
                return;
            }

            statusText.textContent = 'Mengambil lokasi aktif...';
            navigator.geolocation.getCurrentPosition(function (position) {
                const lat = position.coords.latitude.toFixed(7);
                const lng = position.coords.longitude.toFixed(7);
                latInput.value = lat;
                lngInput.value = lng;
                statusText.textContent = 'Lokasi GPS berhasil diambil: ' + lat + ', ' + lng;
            }, function () {
                statusText.textContent = 'Gagal mengambil lokasi. Pastikan izin lokasi di browser diaktifkan.';
            }, {
                enableHighAccuracy: true,
                timeout: 12000,
                maximumAge: 0
            });
        });
    })();
</script>
@endpush
