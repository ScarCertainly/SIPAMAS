@extends('layouts.app')

@section('title', 'Pengaduan')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-3">
    <div>
        <h3 class="mb-1">Pengaduan</h3>
        <p class="text-muted mb-0">Kelola seluruh pengaduan lingkungan yang masuk.</p>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <a href="{{ route('admin.complaints.export.csv', request()->query()) }}" class="btn btn-outline-success">
            Export CSV
        </a>
        <button type="button" id="export-pdf-btn" class="btn btn-primary">Export PDF</button>
        <a href="{{ route('dashboard') }}" class="btn btn-outline-secondary">Dashboard</a>
    </div>
</div>

<div class="app-card p-3 p-md-4 mb-3">
    <form method="GET" action="{{ route('admin.complaints.index') }}" class="row g-3">
        <div class="col-12 col-lg-4">
            <label class="form-label mb-1">Cari</label>
            <input type="text" name="q" value="{{ request('q') }}" class="form-control" placeholder="Judul, deskripsi, nama, email">
        </div>
        <div class="col-6 col-lg-2">
            <label class="form-label mb-1">Status</label>
            <select name="status" class="form-select">
                <option value="">Semua</option>
                <option value="pending" {{ request('status') === 'pending' ? 'selected' : '' }}>Pending</option>
                <option value="process" {{ request('status') === 'process' ? 'selected' : '' }}>In Process</option>
                <option value="rejected" {{ request('status') === 'rejected' ? 'selected' : '' }}>Ditolak</option>
                <option value="done" {{ request('status') === 'done' ? 'selected' : '' }}>Selesai</option>
            </select>
        </div>
        <div class="col-6 col-lg-3">
            <label class="form-label mb-1">Kategori</label>
            <select name="category_id" class="form-select">
                <option value="">Semua</option>
                @foreach($categories as $category)
                    <option value="{{ $category->id }}" {{ (string) request('category_id') === (string) $category->id ? 'selected' : '' }}>
                        {{ $category->name }}
                    </option>
                @endforeach
            </select>
        </div>
        <div class="col-6 col-lg-1">
            <label class="form-label mb-1">Dari</label>
            <input type="date" name="date_from" value="{{ request('date_from') }}" class="form-control">
        </div>
        <div class="col-6 col-lg-1">
            <label class="form-label mb-1">Sampai</label>
            <input type="date" name="date_to" value="{{ request('date_to') }}" class="form-control">
        </div>
        <div class="col-12 d-flex gap-2">
            <button type="submit" class="btn btn-primary">Terapkan</button>
            <a href="{{ route('admin.complaints.index') }}" class="btn btn-outline-secondary">Reset</a>
        </div>
    </form>
</div>

<div class="app-card p-3 p-md-4">
    <div class="table-responsive">
        <table class="table align-middle mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Pelapor</th>
                    <th>Judul</th>
                    <th>Kategori</th>
                    <th>Status</th>
                    <th>Aksi</th>
                    <th>Tanggal</th>
                </tr>
            </thead>
            <tbody>
                @forelse($complaints as $complaint)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $complaint->user->name ?? '-' }}</td>
                    <td>{{ $complaint->title }}</td>
                    <td>{{ $complaint->category->name ?? '-' }}</td>
                    <td>
                        @php
                            $statusClass = match($complaint->status) {
                                'approved' => 'bg-info',
                                'rejected' => 'bg-danger',
                                'done' => 'bg-success',
                                'process' => 'bg-info',
                                default => 'bg-warning'
                            };
                        @endphp
                        @php
                            $statusLabel = match($complaint->status) {
                                'approved' => 'In Process',
                                'rejected' => 'Ditolak',
                                'process' => 'In Process',
                                'done' => 'Selesai',
                                default => 'Pending'
                            };
                        @endphp
                        <span class="badge {{ $statusClass }}">{{ $statusLabel }}</span>
                    </td>
                    <td class="d-flex gap-2">
                        <a href="{{ route('admin.complaints.show', $complaint) }}" class="btn btn-sm btn-outline-secondary">Detail</a>
                        <a href="{{ route('admin.complaints.edit', $complaint) }}" class="btn btn-sm btn-primary">Tindak Lanjut</a>
                    </td>
                    <td>{{ $complaint->created_at->format('d M Y') }}</td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" class="text-center text-muted">Belum ada pengaduan lingkungan masuk.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="mt-3">
        {{ $complaints->links() }}
    </div>
</div>
@endsection

@push('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js"></script>
    <script>
        (function () {
            const exportBtn = document.getElementById('export-pdf-btn');
            if (!exportBtn) {
                return;
            }

            const filters = {
                q: @json(request('q')),
                status: @json(request('status')),
                category: @json(optional($categories->firstWhere('id', (int) request('category_id')))->name),
                dateFrom: @json(request('date_from')),
                dateTo: @json(request('date_to')),
            };

            const filterSummary = [
                filters.q ? `Kata kunci: ${filters.q}` : null,
                filters.status ? `Status: ${filters.status}` : null,
                filters.category ? `Kategori: ${filters.category}` : null,
                filters.dateFrom ? `Dari: ${filters.dateFrom}` : null,
                filters.dateTo ? `Sampai: ${filters.dateTo}` : null
            ].filter(Boolean).join(' | ') || 'Tanpa filter';

            exportBtn.addEventListener('click', function () {
                const jsPDFNS = window.jspdf;
                if (!jsPDFNS || typeof jsPDFNS.jsPDF === 'undefined') {
                    alert('Library PDF belum termuat. Coba refresh halaman.');
                    return;
                }

                const rows = Array.from(document.querySelectorAll('table tbody tr'))
                    .map((row) => Array.from(row.querySelectorAll('td')).map((cell) => (cell.textContent || '').trim()))
                    .filter((cells) => cells.length >= 7);

                if (!rows.length) {
                    alert('Tidak ada data pengaduan untuk diekspor.');
                    return;
                }

                const { jsPDF } = jsPDFNS;
                const doc = new jsPDF({ orientation: 'landscape', unit: 'pt', format: 'a4' });

                doc.setFontSize(15);
                doc.text('Laporan Pengaduan Lingkungan', 40, 40);
                doc.setFontSize(10);
                doc.text(`Filter: ${filterSummary}`, 40, 60, { maxWidth: 760 });
                doc.text(`Dicetak: ${new Date().toLocaleString('id-ID')}`, 40, 76);

                doc.autoTable({
                    startY: 92,
                    head: [['#', 'Pelapor', 'Judul', 'Kategori', 'Status', 'Aksi', 'Tanggal']],
                    body: rows.map((cells) => [cells[0], cells[1], cells[2], cells[3], cells[4], '-', cells[6]]),
                    styles: { fontSize: 9, cellPadding: 5 },
                    headStyles: { fillColor: [15, 118, 110] },
                    alternateRowStyles: { fillColor: [245, 252, 249] }
                });

                const now = new Date();
                const stamp = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
                doc.save(`laporan-pengaduan-${stamp}.pdf`);
            });
        })();
    </script>
@endpush
