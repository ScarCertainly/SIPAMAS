<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProfileUpdateRequest;
use App\Models\Complaint;
use App\Support\PublicImageUpload;
use App\Support\PublicUploadedMedia;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\UploadedFile;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\View\View;

class ProfileController extends Controller
{
    /**
     * Display the user's profile form.
     */
    public function edit(Request $request): View
    {
        $user = $request->user();

        $complaints = Complaint::query()->where('user_id', $user->id);

        return view('profile.edit', [
            'user' => $user,
            'stats' => [
                'total' => (clone $complaints)->count(),
                'pending' => (clone $complaints)->where('status', 'pending')->count(),
                'process' => (clone $complaints)->whereIn('status', ['process', 'approved'])->count(),
                'rejected' => (clone $complaints)->where('status', 'rejected')->count(),
            ],
            'recentComplaints' => Complaint::query()
                ->where('user_id', $user->id)
                ->latest()
                ->take(3)
                ->get(['title', 'status', 'created_at']),
        ]);
    }

    /**
     * Update the user's profile information.
     */
    public function update(ProfileUpdateRequest $request): RedirectResponse
    {
        $user = $request->user();
        $validated = $request->validated();
        $user->fill(Arr::except($validated, ['profile_photo']));

        if ($request->hasFile('profile_photo')) {
            $this->deleteProfilePhoto($user->profile_photo_path);
            $user->profile_photo_path = $this->storeProfilePhoto($request->file('profile_photo'));
        }

        if ($user->isDirty('email')) {
            $user->email_verified_at = null;
        }

        $user->save();

        return Redirect::route('profile.edit')->with('status', 'profile-updated');
    }

    /**
     * Delete the user's account.
     */
    public function destroy(Request $request): RedirectResponse
    {
        $request->validateWithBag('userDeletion', [
            'password' => ['required', 'current_password'],
        ]);

        $user = $request->user();

        Auth::logout();

        $user->delete();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return Redirect::to('/');
    }

    private function storeProfilePhoto(UploadedFile $file): string
    {
        return PublicImageUpload::store($file, 'profile-photos', 'profile', 1200);
    }

    private function deleteProfilePhoto(?string $relativePath): void
    {
        PublicUploadedMedia::delete($relativePath);
    }
}
