import React from 'react';
import { Menu, X } from 'lucide-react';

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  const links = [
    { href: '#login', label: 'Login' },
    { href: '#fitur', label: 'Fitur' },
    { href: '#testimoni', label: 'Testimoni' },
    { href: '#pameran', label: 'Pameran' },
  ];

  const go = (href: string) => {
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
    setIsMenuOpen(false);
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-slate-900/80 backdrop-blur-md border-b border-slate-700/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <span className="text-white font-semibold text-xl">SIPAMAS • PORTAL</span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            {links.map((item) => (
              <button
                key={item.label}
                onClick={() => go(item.href)}
                className="text-gray-300 hover:text-white transition-colors"
              >
                {item.label}
              </button>
            ))}
            <button
              onClick={() => go('#login')}
              className="bg-gradient-to-r from-cyan-500 to-purple-500 text-white px-6 py-2 rounded-lg hover:opacity-90 transition-opacity"
            >
              Masuk
            </button>
          </div>

          <button className="md:hidden text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden py-4 space-y-3">
            {links.map((item) => (
              <button
                key={item.label}
                onClick={() => go(item.href)}
                className="block w-full text-left text-gray-300 hover:text-white transition-colors py-2"
              >
                {item.label}
              </button>
            ))}
            <button
              onClick={() => go('#login')}
              className="block w-full bg-gradient-to-r from-cyan-500 to-purple-500 text-white px-6 py-2 rounded-lg hover:opacity-90 transition-opacity"
            >
              Masuk
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}
