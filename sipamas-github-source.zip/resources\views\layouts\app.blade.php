<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', 'SIPAMAS')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="color-scheme" content="light dark">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Merriweather:wght@700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        (function () {
            var storedTheme = null;

            try {
                storedTheme = localStorage.getItem('sipamas-theme');
            } catch (error) {
                storedTheme = null;
            }

            var theme = storedTheme === 'dark' ? 'dark' : 'light';
            document.documentElement.setAttribute('data-theme', theme);
        })();
    </script>
    @stack('styles')
    <style>
        :root {
            --app-bg: #ecfeff;
            --app-bg-soft: #f0fdfa;
            --app-ink: #0f172a;
            --app-card: #ffffff;
            --app-accent: #0f766e;
            --app-accent-dark: #0f5f65;
            --app-muted: #475569;
            --app-border: rgba(15, 23, 42, 0.09);
            --app-soft: #e6fffb;
        }
        body.app-body {
            font-family: "Plus Jakarta Sans", system-ui, -apple-system, "Segoe UI", sans-serif;
            background:
                radial-gradient(1100px 560px at 100% -10%, rgba(20, 184, 166, 0.16), transparent 60%),
                radial-gradient(900px 500px at -10% -10%, rgba(6, 182, 212, 0.18), transparent 60%),
                linear-gradient(135deg, var(--app-bg-soft) 0%, var(--app-bg) 45%, #eff6ff 100%);
            color: var(--app-ink);
            min-height: 100vh;
        }
        body.app-user-theme {
            --app-bg: #f8fafc;
            --app-bg-soft: #f1f5f9;
            --app-ink: #0f172a;
            --app-card: #ffffff;
            --app-accent: #16a34a;
            --app-accent-dark: #0f766e;
            --app-muted: #64748b;
            --app-border: rgba(148, 163, 184, 0.28);
            --app-soft: #ecfeff;
            background:
                radial-gradient(1000px 480px at 100% -10%, rgba(22, 163, 74, 0.12), transparent 60%),
                radial-gradient(900px 520px at -10% -10%, rgba(20, 184, 166, 0.12), transparent 60%),
                linear-gradient(135deg, #f8fafc 0%, #eef7f2 40%, #ecfdf5 100%);
        }
        body.app-admin-dashboard {
            --app-bg: #f8fafc;
            --app-bg-soft: #f8fafc;
            --app-card: #ffffff;
            --app-border: rgba(148, 163, 184, 0.22);
            background:
                radial-gradient(900px 400px at 100% -10%, rgba(20, 184, 166, 0.06), transparent 55%),
                linear-gradient(180deg, #f8fafc 0%, #f1f5f9 100%);
        }
        .app-shell {
            width: 100%;
            max-width: none;
            margin: 0;
            padding: 22px 32px 64px;
        }
        .app-nav {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            padding: 12px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            box-shadow: 0 4px 14px rgba(15, 23, 42, 0.06);
            position: relative;
            z-index: 1200;
            overflow: visible;
        }
        .app-brand-wrap {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .app-brand-mark {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            background: linear-gradient(135deg, #0f766e 0%, #16a34a 100%);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            box-shadow: 0 10px 20px rgba(22, 163, 74, 0.24);
            flex: 0 0 auto;
        }
        .app-brand-mark svg {
            width: 24px;
            height: 24px;
        }
        .app-brand {
            font-weight: 800;
            letter-spacing: 0.2px;
            color: #0f766e;
            text-decoration: none;
            font-size: 1.6rem;
            line-height: 1.2;
        }
        .app-brand small {
            display: block;
            font-family: "Plus Jakarta Sans", sans-serif;
            font-size: 0.72rem;
            font-weight: 700;
            letter-spacing: 0.4px;
            color: var(--app-muted);
            text-transform: uppercase;
        }
        .user-chip {
            display: inline-flex;
            align-items: center;
            gap: 12px;
            min-height: 56px;
            padding: 8px 12px;
            border-radius: 16px;
            border: 1px solid #e5e7eb;
            background: #ffffff;
            box-shadow: 0 2px 8px rgba(15, 23, 42, 0.04);
        }
        .user-chip-trigger {
            display: inline-flex;
            align-items: center;
            gap: 12px;
            padding: 0;
            border: 0;
            background: transparent;
            color: inherit;
            min-width: 0;
        }
        .user-chip-trigger::after {
            display: none;
        }
        .user-chip-trigger:hover,
        .user-chip-trigger:focus,
        .user-chip-trigger:active {
            background: transparent !important;
            color: inherit !important;
            box-shadow: none !important;
        }
        .user-chip:hover,
        .user-chip:has(.user-chip-trigger.show) {
            background: #f8fafc;
            border-color: #dbe3ee;
        }
        .profile-menu {
            min-width: 280px;
            border: 1px solid #e5e7eb;
            border-radius: 16px;
            padding: 8px;
            box-shadow: 0 18px 34px rgba(15, 23, 42, 0.12);
        }
        .profile-menu .dropdown-item {
            border-radius: 12px;
            padding: 10px 12px;
            font-weight: 600;
            color: #334155;
        }
        .profile-menu .dropdown-item:hover,
        .profile-menu .dropdown-item:focus {
            background: #f8fafc;
            color: #0f172a;
        }
        .profile-menu .dropdown-item-danger {
            color: #dc2626;
        }
        .profile-menu .dropdown-item-danger:hover,
        .profile-menu .dropdown-item-danger:focus {
            background: #fef2f2;
            color: #b91c1c;
        }
        .profile-menu form {
            margin: 0;
        }
        .theme-toggle-item {
            display: grid;
            gap: 10px;
            padding: 10px 12px;
            border-radius: 12px;
            margin-bottom: 6px;
            background: linear-gradient(135deg, rgba(15, 118, 110, 0.08), rgba(22, 163, 74, 0.06));
            border: 1px solid rgba(15, 118, 110, 0.12);
        }
        .theme-toggle-head {
            display: grid;
            grid-template-columns: minmax(0, 1fr) auto;
            align-items: center;
            gap: 12px;
        }
        .theme-toggle-copy {
            min-width: 0;
        }
        .theme-toggle-title {
            display: block;
            color: #0f172a;
            font-size: 0.9rem;
            font-weight: 700;
            line-height: 1.2;
        }
        .theme-toggle-subtitle {
            display: block;
            color: #64748b;
            font-size: 0.76rem;
            margin-top: 2px;
        }
        .theme-switch {
            position: relative;
            width: 58px;
            height: 32px;
            border: 0;
            border-radius: 999px;
            padding: 0;
            flex: 0 0 auto;
            background: linear-gradient(90deg, #cbd5e1 0%, #94a3b8 100%);
            box-shadow: inset 0 0 0 1px rgba(15, 23, 42, 0.08);
            transition: 0.22s ease;
        }
        .theme-switch::before {
            content: "";
            position: absolute;
            top: 4px;
            left: 4px;
            width: 24px;
            height: 24px;
            border-radius: 999px;
            background: #ffffff;
            box-shadow: 0 6px 14px rgba(15, 23, 42, 0.18);
            transition: transform 0.22s ease;
        }
        .theme-switch.is-dark {
            background: linear-gradient(90deg, #0f766e 0%, #16a34a 100%);
        }
        .theme-switch.is-dark::before {
            transform: translateX(26px);
        }
        .theme-mode-pills {
            display: flex;
            gap: 8px;
        }
        .theme-mode-pill {
            flex: 1 1 0;
            border-radius: 999px;
            border: 1px solid rgba(15, 23, 42, 0.08);
            background: rgba(255, 255, 255, 0.8);
            color: #475569;
            font-size: 0.76rem;
            font-weight: 700;
            padding: 6px 10px;
            text-align: center;
            transition: 0.18s ease;
        }
        .theme-mode-pill.is-active {
            background: #ffffff;
            color: #0f766e;
            border-color: rgba(15, 118, 110, 0.25);
            box-shadow: 0 6px 16px rgba(15, 118, 110, 0.1);
        }
        .user-avatar {
            width: 42px;
            height: 42px;
            border-radius: 14px;
            object-fit: cover;
            border: 0;
            box-shadow: none;
            background: linear-gradient(135deg,#dcfce7 0%,#bbf7d0 100%);
        }
        .user-avatar-fallback {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 0.95rem;
            color: #15803d;
            background: linear-gradient(135deg,#dcfce7 0%,#bbf7d0 100%);
            text-transform: uppercase;
        }
        .user-chip-meta {
            min-width: 0;
            display: grid;
            gap: 2px;
            text-align: left;
        }
        .user-chip-label {
            display: block;
            color: #64748b;
            font-size: 0.78rem;
            line-height: 1;
            font-weight: 600;
        }
        .user-chip-name {
            display: block;
            color: #0f172a;
            font-size: 0.94rem;
            font-weight: 700;
            line-height: 1.2;
            max-width: 140px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .app-card {
            background: var(--app-card);
            border: 1px solid var(--app-border);
            border-radius: 20px;
            box-shadow: 0 16px 30px rgba(15, 23, 42, 0.07);
            animation: fadeInUp .4s ease-out both;
        }
        body.app-user-theme .app-nav {
            border-radius: 18px;
            border-color: rgba(148, 163, 184, 0.25);
            box-shadow: 0 16px 34px rgba(15, 23, 42, 0.08);
        }
        body.app-user-theme .app-card {
            border-radius: 22px;
            border-color: rgba(148, 163, 184, 0.24);
            box-shadow: 0 20px 36px rgba(15, 23, 42, 0.08);
        }
        body.app-user-theme .btn-primary {
            background: linear-gradient(90deg, #0f766e 0%, #16a34a 100%);
            box-shadow: 0 12px 24px rgba(22, 163, 74, 0.24);
        }
        body.app-user-theme .btn-primary:hover {
            background: linear-gradient(90deg, #0b5d56 0%, #15803d 100%);
        }
        body.app-user-theme .btn-outline-secondary {
            color: #0f5f65;
            border-color: rgba(22, 163, 74, 0.25);
            background: #ffffff;
        }
        body.app-user-theme .btn-outline-secondary:hover {
            background: #f1f5f9;
            border-color: rgba(22, 163, 74, 0.4);
        }
        body.app-user-theme .form-control,
        body.app-user-theme .form-select {
            border-color: rgba(148, 163, 184, 0.35);
            background: #ffffff;
        }
        body.app-user-theme .table thead th {
            background: linear-gradient(180deg, #f8fafc 0%, #e2e8f0 100%);
        }
        .app-layout {
            display: grid;
            grid-template-columns: 220px minmax(0, 1fr);
            gap: 20px;
            align-items: start;
        }
        .app-main {
            grid-column: 2;
            min-width: 0;
        }
        .app-main-full {
            grid-column: 1 / -1;
        }
        .app-sidebar {
            background: var(--app-card);
            border: 1px solid var(--app-border);
            border-radius: 16px;
            padding: 12px;
            position: sticky;
            top: 18px;
            box-shadow: 0 10px 24px rgba(15, 23, 42, 0.06);
            overflow: hidden;
        }
        body.app-admin-dashboard .app-layout {
            grid-template-columns: 252px minmax(0, 1fr);
            gap: 24px;
        }
        body.app-admin-dashboard .app-sidebar {
            border-radius: 22px;
            border-color: #e2e8f0;
            box-shadow: 0 18px 34px rgba(15, 23, 42, 0.06);
            padding: 14px;
        }
        body.app-admin-dashboard .sidebar-accent {
            display: none;
        }
        body.app-admin-dashboard .sidebar-header {
            padding: 8px 10px 18px;
            margin-bottom: 10px;
            border-bottom: 1px solid #e2e8f0;
        }
        body.app-admin-dashboard .sidebar-logo {
            width: 42px;
            height: 42px;
            border-radius: 14px;
            background: #16a34a;
            box-shadow: none;
        }
        body.app-admin-dashboard .sidebar-brand {
            font-size: 1.1rem;
        }
        body.app-admin-dashboard .sidebar-subtitle {
            font-size: 0.76rem;
        }
        body.app-admin-dashboard .sidebar-title {
            margin: 8px 12px 10px;
            color: #94a3b8;
        }
        body.app-admin-dashboard .sidebar-link {
            border-radius: 14px;
            padding: 12px 14px;
            color: #334155;
            border: 1px solid transparent;
        }
        body.app-admin-dashboard .sidebar-link:hover {
            background: #f8fafc;
            border-color: #e2e8f0;
            color: #0f172a;
        }
        body.app-admin-dashboard .sidebar-link.active {
            background: #ecfdf5;
            color: #16a34a;
            border-color: #bbf7d0;
            box-shadow: none;
        }
        body.app-admin-dashboard .sidebar-link.active svg {
            stroke: #16a34a;
        }
        body.app-admin-dashboard .sidebar-divider {
            background: #e2e8f0;
        }
        .sidebar-accent {
            height: 4px;
            border-radius: 999px;
            background: linear-gradient(90deg, #0f766e 0%, #14b8a6 55%, #16a34a 100%);
            margin: 4px 8px 10px;
        }
        .sidebar-header {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 10px 12px;
        }
        .sidebar-header.sidebar-header-centered {
            justify-content: center;
            text-align: center;
        }
        .sidebar-logo {
            width: 44px;
            height: 44px;
            border-radius: 14px;
            background: linear-gradient(135deg, #0f766e 0%, #16a34a 100%);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            box-shadow: 0 10px 20px rgba(22, 163, 74, 0.22);
            flex: 0 0 auto;
        }
        .sidebar-logo img {
            width: 24px;
            height: 24px;
            display: block;
        }
        .sidebar-brand {
            font-weight: 800;
            color: #0f172a;
            font-size: 1rem;
        }
        .sidebar-header.sidebar-header-centered .sidebar-brand,
        .sidebar-header.sidebar-header-centered .sidebar-subtitle {
            text-align: center;
        }
        .sidebar-subtitle {
            font-size: 0.72rem;
            font-weight: 600;
            color: var(--app-muted);
        }
        .sidebar-title {
            font-size: 0.72rem;
            text-transform: uppercase;
            letter-spacing: 0.4px;
            font-weight: 800;
            color: #94a3b8;
            margin: 6px 14px 8px;
        }
        .sidebar-divider {
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(148, 163, 184, 0.5), transparent);
            margin: 12px 10px;
        }
        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 12px;
            border-radius: 12px;
            color: #0f172a;
            text-decoration: none;
            font-weight: 600;
            border: 1px solid transparent;
            transition: 0.2s ease;
        }
        .sidebar-link + .sidebar-link {
            margin-top: 8px;
        }
        .sidebar-link:hover {
            background: #f1f5f9;
            color: #0f5f65;
        }
        .sidebar-link.active {
            background: linear-gradient(90deg, #0f766e 0%, #16a34a 100%);
            color: #fff;
            box-shadow: 0 8px 20px rgba(22, 163, 74, 0.22);
        }
        .sidebar-link svg {
            width: 18px;
            height: 18px;
        }
        .sidebar-link.active svg {
            stroke: #fff;
        }
        .sidebar-link.button-link {
            width: 100%;
            background: transparent;
            border: 1px solid transparent;
        }
        .text-muted,
        .text-secondary {
            color: var(--app-muted) !important;
        }
        .btn-primary {
            background: linear-gradient(135deg, #0f766e 0%, #16a34a 100%);
            border: none;
            color: #fff;
            font-weight: 600;
            border-radius: 12px;
            box-shadow: 0 8px 18px rgba(22, 163, 74, 0.22);
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #0b5d56 0%, #15803d 100%);
            color: #fff;
            transform: translateY(-1px);
        }
        .btn-outline-primary {
            color: #0f766e;
            border-color: rgba(15, 118, 110, 0.3);
            background: #fff;
            border-radius: 12px;
        }
        .btn-outline-primary:hover {
            color: #0b4e50;
            border-color: rgba(15, 118, 110, 0.5);
            background: #effcf8;
        }
        .btn-outline-secondary {
            color: #0f4f57;
            border-color: rgba(15, 118, 110, 0.35);
            background: #fff;
            border-radius: 12px;
        }
        .btn-outline-secondary:hover {
            background: #effcfb;
            color: #0d4f54;
            border-color: rgba(15, 118, 110, 0.5);
        }
        .btn-outline-danger {
            border-radius: 12px;
        }
        .btn {
            transition: 0.22s ease;
        }
        .btn-sm {
            border-radius: 10px;
        }
        .table {
            color: #0f172a;
            border-color: rgba(15, 23, 42, 0.08);
        }
        .table thead th {
            color: #475569;
            font-weight: 700;
            text-transform: uppercase;
            font-size: 0.74rem;
            letter-spacing: 0.55px;
            padding-top: 1rem;
            padding-bottom: 1rem;
            background: linear-gradient(180deg, #f8fafc 0%, #f1f5f9 100%);
        }
        .table tbody tr {
            background: #ffffff;
        }
        .table tbody tr:hover {
            background: #f8fffe;
        }
        .table tbody tr + tr {
            border-top: 1px solid rgba(15, 23, 42, 0.06);
        }
        .table-responsive {
            border-radius: 16px;
            overflow: hidden;
        }
        .form-control, .form-select {
            background: #fff;
            border: 1px solid rgba(15, 23, 42, 0.15);
            color: #0f172a;
            border-radius: 12px;
            min-height: 44px;
        }
        .form-control:focus, .form-select:focus {
            border-color: rgba(22, 163, 74, 0.55);
            box-shadow: 0 0 0 0.2rem rgba(22, 163, 74, 0.12);
        }
        .form-control::placeholder {
            color: #94a3b8;
        }
        .hero-title {
            font-family: "Merriweather", serif;
            font-size: clamp(2rem, 4.2vw, 3.4rem);
            line-height: 1.15;
        }
        .pill {
            background: #f0faf7;
            border: 1px solid rgba(15, 118, 110, 0.20);
            color: #165344;
            padding: 8px 12px;
            border-radius: 999px;
            font-size: 0.84rem;
            font-weight: 600;
        }
        .hero-actions {
            min-width: 220px;
        }
        .dropdown-menu {
            border: 1px solid rgba(15, 118, 110, 0.20);
            box-shadow: 0 16px 35px rgba(15, 23, 42, 0.12);
            border-radius: 12px;
            z-index: 1300;
        }
        .notif-menu {
            width: min(92vw, 420px);
            max-height: 72vh;
            overflow-y: auto;
        }
        .notif-title {
            font-size: 0.8rem;
            font-weight: 800;
            color: #2f4f46;
            text-transform: uppercase;
            letter-spacing: 0.35px;
        }
        .notif-card {
            border: 1px solid rgba(15, 118, 110, 0.16);
            border-radius: 12px;
            background: linear-gradient(180deg, #ffffff 0%, #f8fcfa 100%);
            padding: 10px 12px;
            margin-bottom: 10px;
            transition: 0.18s ease;
        }
        .notif-card:hover {
            transform: translateY(-1px);
            border-color: rgba(15, 118, 110, 0.28);
            box-shadow: 0 8px 20px rgba(15, 118, 110, 0.08);
        }
        .notif-card.unread {
            border-left: 4px solid #0f766e;
            padding-left: 9px;
            background: linear-gradient(180deg, #f8fffc 0%, #f2fbf7 100%);
        }
        .notif-headline {
            font-size: 0.93rem;
            font-weight: 700;
            line-height: 1.3;
            margin-bottom: 4px;
            color: #143a31;
        }
        .notif-preview {
            font-size: 0.84rem;
            color: #375148;
            line-height: 1.35;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        .notif-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 8px;
            gap: 8px;
            font-size: 0.75rem;
            color: #557169;
        }
        .notif-pill {
            display: inline-flex;
            align-items: center;
            padding: 2px 8px;
            border-radius: 999px;
            background: #e6f7f0;
            color: #0f6a59;
            font-weight: 700;
            font-size: 0.7rem;
            border: 1px solid rgba(15, 118, 110, 0.24);
        }
        .notif-empty {
            border: 1px dashed rgba(15, 118, 110, 0.26);
            border-radius: 12px;
            padding: 14px;
            font-size: 0.86rem;
            color: #557169;
            background: #f8fcfa;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .badge.bg-warning {
            background-color: #fef3c7 !important;
            color: #92400e !important;
            font-weight: 700;
        }
        .badge.bg-info {
            background-color: #dbeafe !important;
            color: #1e40af !important;
            font-weight: 700;
        }
        .badge.bg-success {
            background-color: #dcfce7 !important;
            color: #166534 !important;
            font-weight: 700;
        }
        .badge.bg-danger {
            background-color: #fee2e2 !important;
            color: #991b1b !important;
            font-weight: 700;
        }
        .alert.alert-success {
            border: 1px solid #99f6e4;
            background: #f0fdfa;
            color: #0f766e;
        }
        .icon-btn {
            width: 38px;
            height: 38px;
            border-radius: 999px !important;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0;
            border: 0 !important;
            background: transparent !important;
            color: #374151 !important;
        }
        .icon-btn svg {
            width: 18px;
            height: 18px;
        }
        @media (max-width: 992px) {
            .app-shell {
                padding: 18px 18px 48px;
            }
            .app-nav {
                padding: 12px 14px;
            }
            .profile-menu {
                min-width: 260px;
            }
            .app-layout {
                grid-template-columns: 1fr;
            }
            .app-sidebar {
                position: static;
            }
            .app-main,
            .app-main-full {
                grid-column: 1;
            }
            .hero-actions {
                width: 100%;
            }
            .hero-actions .btn {
                width: 100%;
            }
            .hero-title {
                font-size: clamp(1.7rem, 8vw, 2.3rem);
            }
        }
        @media (max-width: 576px) {
            .app-nav {
                flex-wrap: wrap;
            }
            .user-chip {
                width: 100%;
            }
            .user-chip-name {
                max-width: none;
            }
            .profile-menu {
                min-width: min(88vw, 280px);
            }
            .theme-toggle-head {
                grid-template-columns: 1fr;
            }
            .theme-switch {
                justify-self: start;
            }
            .app-card {
                border-radius: 16px;
            }
            .table-responsive {
                border-radius: 12px;
            }
        }
        body.app-theme-dark {
            --app-bg: #020617;
            --app-bg-soft: #0f172a;
            --app-ink: #e2e8f0;
            --app-card: #111827;
            --app-accent: #16a34a;
            --app-accent-dark: #0f766e;
            --app-muted: #94a3b8;
            --app-border: rgba(148, 163, 184, 0.22);
            --app-soft: #0f2e2f;
            color-scheme: dark;
            background:
                radial-gradient(1100px 560px at 100% -10%, rgba(20, 184, 166, 0.14), transparent 60%),
                radial-gradient(900px 500px at -10% -10%, rgba(8, 145, 178, 0.18), transparent 60%),
                linear-gradient(135deg, #020617 0%, #0b1120 45%, #111827 100%);
        }
        body.app-theme-dark.app-user-theme {
            background:
                radial-gradient(1000px 480px at 100% -10%, rgba(22, 163, 74, 0.14), transparent 60%),
                radial-gradient(900px 520px at -10% -10%, rgba(20, 184, 166, 0.14), transparent 60%),
                linear-gradient(135deg, #020617 0%, #0b1120 42%, #0f172a 100%);
        }
        body.app-theme-dark.app-admin-dashboard {
            background:
                radial-gradient(900px 400px at 100% -10%, rgba(20, 184, 166, 0.08), transparent 55%),
                linear-gradient(180deg, #020617 0%, #0f172a 100%);
        }
        body.app-theme-dark .app-nav {
            background: #0f172a;
            border-color: rgba(148, 163, 184, 0.22);
            box-shadow: 0 4px 14px rgba(2, 6, 23, 0.55);
        }
        body.app-theme-dark .app-brand {
            color: #2dd4bf;
        }
        body.app-theme-dark .app-sidebar {
            background: #0f172a;
            border-color: rgba(148, 163, 184, 0.22);
        }
        body.app-theme-dark .sidebar-brand {
            color: #e2e8f0;
        }
        body.app-theme-dark .sidebar-title {
            color: #94a3b8;
        }
        body.app-theme-dark .sidebar-link {
            color: #e2e8f0;
        }
        body.app-theme-dark .sidebar-link:hover {
            background: #162132;
            border-color: rgba(45, 212, 191, 0.28);
            color: #ecfeff;
        }
        body.app-theme-dark .sidebar-link.active {
            background: linear-gradient(90deg, #0f766e 0%, #16a34a 100%);
            color: #ecfeff;
        }
        body.app-theme-dark .sidebar-link.active svg {
            stroke: #ecfeff;
        }
        body.app-theme-dark .app-badge,
        body.app-theme-dark .notif-meta,
        body.app-theme-dark .notif-empty,
        body.app-theme-dark .dropdown-item-text,
        body.app-theme-dark .small.text-muted,
        body.app-theme-dark .text-muted,
        body.app-theme-dark .text-secondary {
            color: #94a3b8 !important;
        }
        body.app-theme-dark .user-chip {
            border-color: rgba(45, 212, 191, 0.35);
            background: rgba(15, 23, 42, 0.6);
        }
        body.app-theme-dark .user-chip-label {
            color: #94a3b8;
        }
        body.app-theme-dark .user-chip-name {
            color: #e2e8f0;
        }
        body.app-theme-dark .user-chip:hover,
        body.app-theme-dark .user-chip:has(.user-chip-trigger.show) {
            background: #162132;
            border-color: rgba(45, 212, 191, 0.28);
        }
        body.app-theme-dark .profile-menu .dropdown-item {
            color: #e2e8f0;
        }
        body.app-theme-dark .profile-menu .dropdown-item:hover,
        body.app-theme-dark .profile-menu .dropdown-item:focus {
            background: #162132;
            color: #ecfeff;
        }
        body.app-theme-dark .theme-toggle-item {
            background: linear-gradient(135deg, rgba(20, 184, 166, 0.15), rgba(15, 23, 42, 0.2));
            border-color: rgba(45, 212, 191, 0.2);
        }
        body.app-theme-dark .theme-toggle-title {
            color: #e2e8f0;
        }
        body.app-theme-dark .theme-toggle-subtitle {
            color: #94a3b8;
        }
        body.app-theme-dark .theme-mode-pill {
            background: rgba(15, 23, 42, 0.86);
            color: #94a3b8;
            border-color: rgba(148, 163, 184, 0.22);
        }
        body.app-theme-dark .theme-mode-pill.is-active {
            background: rgba(20, 184, 166, 0.12);
            color: #99f6e4;
            border-color: rgba(45, 212, 191, 0.3);
        }
        body.app-theme-dark .user-avatar {
            border-color: rgba(15, 23, 42, 0.9);
        }
        body.app-theme-dark .user-avatar-fallback {
            color: #99f6e4;
            background: rgba(15, 118, 110, 0.35);
        }
        body.app-theme-dark .table {
            color: #e2e8f0;
            border-color: rgba(148, 163, 184, 0.2);
        }
        body.app-theme-dark .table thead th {
            color: #94a3b8;
            background: linear-gradient(180deg, #111827 0%, #0f172a 100%);
        }
        body.app-theme-dark .table tbody tr {
            background: #0f172a;
        }
        body.app-theme-dark .table tbody tr:hover {
            background: #162132;
        }
        body.app-theme-dark .form-control,
        body.app-theme-dark .form-select {
            background: #0b1220;
            border-color: rgba(148, 163, 184, 0.3);
            color: #e2e8f0;
        }
        body.app-theme-dark .form-control::placeholder {
            color: #64748b;
        }
        body.app-theme-dark .dropdown-menu {
            background: #0f172a;
            border-color: rgba(148, 163, 184, 0.25);
        }
        body.app-theme-dark .notif-menu {
            background: linear-gradient(180deg, #0f172a 0%, #111827 100%);
            border-color: rgba(45, 212, 191, 0.24);
            box-shadow: 0 18px 34px rgba(2, 6, 23, 0.55);
        }
        body.app-theme-dark .notif-card {
            background: linear-gradient(180deg, #0f172a 0%, #111827 100%);
            border-color: rgba(45, 212, 191, 0.22);
        }
        body.app-theme-dark .notif-card.unread {
            background: linear-gradient(180deg, #102127 0%, #0f172a 100%);
            border-left-color: #2dd4bf;
        }
        body.app-theme-dark .notif-headline {
            color: #e2e8f0;
        }
        body.app-theme-dark .notif-preview {
            color: #cbd5e1;
        }
        body.app-theme-dark .notif-pill {
            background: rgba(20, 184, 166, 0.15);
            color: #99f6e4;
            border-color: rgba(45, 212, 191, 0.3);
        }
        body.app-theme-dark .btn-outline-primary,
        body.app-theme-dark .btn-outline-secondary {
            color: #d1fae5;
            border-color: rgba(45, 212, 191, 0.38);
            background: #0f172a;
        }
        body.app-theme-dark .btn-outline-primary:hover,
        body.app-theme-dark .btn-outline-secondary:hover {
            color: #ecfeff;
            border-color: rgba(45, 212, 191, 0.52);
            background: #162132;
        }
        body.app-theme-dark .icon-btn {
            color: #cbd5e1 !important;
        }
    </style>
</head>
<body class="app-body {{ auth()->check() && auth()->user()->role === 'user' ? 'app-user-theme' : '' }} {{ auth()->check() && auth()->user()->role === 'admin' && request()->routeIs('dashboard') ? 'app-admin-dashboard' : '' }}" data-theme-ready="false">
    @php
        $user = auth()->user();
        $canReadNotifications = \Illuminate\Support\Facades\Schema::hasTable('notifications');
        $notificationsEnabled = $user ? (bool) ($user->show_notifications ?? true) : false;
        $unreadCount = ($notificationsEnabled && $user && $canReadNotifications) ? $user->unreadNotifications()->count() : 0;
        $latestNotifications = ($notificationsEnabled && $user && $canReadNotifications) ? $user->notifications()->latest()->limit(6)->get() : collect();
    @endphp
    <div class="app-shell">
        <nav class="app-nav">
            <div class="app-brand-wrap">
                <span class="app-brand-mark">
                    <x-application-logo class="h-6 w-6 text-white" />
                </span>
                <a class="app-brand" href="/">
                    SIPAMAS
                    <small>Dinas Lingkungan</small>
                </a>
            </div>
            <div class="d-flex align-items-center gap-3">
                @auth
                    <div class="dropdown">
                        <button class="user-chip user-chip-trigger dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            @if($user && $user->profile_photo_url)
                                <img src="{{ $user->profile_photo_url }}" alt="Foto {{ $user->name }}" class="user-avatar">
                            @elseif($user)
                                <span class="user-avatar user-avatar-fallback">
                                    {{ strtoupper(mb_substr($user->name, 0, 1)) }}
                                </span>
                            @else
                                <span class="user-avatar user-avatar-fallback">G</span>
                            @endif
                            <span class="user-chip-meta">
                                <span class="user-chip-label">{{ $user?->role === 'admin' ? 'Admin' : 'User' }}</span>
                                <span class="user-chip-name">{{ $user->name ?? 'Guest' }}</span>
                            </span>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end profile-menu">
                            <div class="theme-toggle-item">
                                <div class="theme-toggle-head">
                                    <div class="theme-toggle-copy">
                                        <span class="theme-toggle-title">Mode Tampilan</span>
                                        <span class="theme-toggle-subtitle">Ganti cepat ke terang atau gelap.</span>
                                    </div>
                                    <button type="button" class="theme-switch" data-theme-toggle aria-label="Ganti mode tampilan" aria-pressed="false"></button>
                                </div>
                                <div class="theme-mode-pills" aria-hidden="true">
                                    <span class="theme-mode-pill" data-theme-pill="light">Terang</span>
                                    <span class="theme-mode-pill" data-theme-pill="dark">Gelap</span>
                                </div>
                            </div>
                            <a class="dropdown-item" href="{{ route('profil.edit') }}">Edit Profile</a>
                            <a class="dropdown-item" href="{{ route('setting') }}">Pengaturan Tampilan</a>
                            <form method="POST" action="{{ route('logout') }}">
                                @csrf
                                <button type="submit" class="dropdown-item dropdown-item-danger">Logout</button>
                            </form>
                        </div>
                    </div>
                @else
                    <div class="user-chip">
                        <span class="user-avatar user-avatar-fallback">G</span>
                        <span class="user-chip-meta">
                            <span class="user-chip-label">Guest</span>
                            <span class="user-chip-name">Belum login</span>
                        </span>
                    </div>
                @endauth
                @auth
                    @if($notificationsEnabled)
                        <div class="dropdown">
                            <button class="btn btn-outline-secondary btn-sm position-relative icon-btn" type="button" data-bs-toggle="dropdown" aria-expanded="false" title="Notifikasi">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                    <path d="M15 17h5l-1.4-1.4A2 2 0 0 1 18 14.2V11a6 6 0 0 0-12 0v3.2a2 2 0 0 1-.6 1.4L4 17h5"/>
                                    <path d="M9 17a3 3 0 0 0 6 0"/>
                                </svg>
                                @if($unreadCount > 0)
                                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">{{ $unreadCount }}</span>
                                @endif
                            </button>
                            <div class="dropdown-menu dropdown-menu-end p-3 notif-menu">
                                <div class="dropdown-item-text small text-muted px-0">Notifikasi baru ({{ $unreadCount }})</div>
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <strong class="notif-title">Notifikasi Admin</strong>
                                    <div class="d-flex align-items-center gap-2">
                                        <a href="{{ route('notifications.index') }}" class="btn btn-sm btn-outline-secondary py-0 px-2">Lihat semua</a>
                                        @if($unreadCount > 0)
                                            <form method="POST" action="{{ route('notifications.readAll') }}">
                                                @csrf
                                                <button type="submit" class="btn btn-link btn-sm p-0">Tandai dibaca</button>
                                            </form>
                                        @endif
                                    </div>
                                </div>
                                @forelse($latestNotifications as $notification)
                                    @php
                                        $data = $notification->data;
                                        $notificationTitle = $data['title'] ?? $data['complaint_title'] ?? 'Pengaduan Lingkungan';
                                        $notificationPreview = $data['message'] ?? $data['comment'] ?? '-';
                                        $notificationSender = $data['sender_name'] ?? $data['admin_name'] ?? 'Admin';
                                        $notificationActionUrl = $data['action_url'] ?? route('complaints.index');
                                        $notificationActionLabel = $data['action_label'] ?? 'Lihat Pengaduan';
                                    @endphp
                                    <div class="notif-card {{ is_null($notification->read_at) ? 'unread' : '' }}">
                                        <div class="notif-headline">{{ $notificationTitle }}</div>
                                        <div class="notif-preview">{{ $notificationPreview }}</div>
                                        <div class="notif-meta">
                                            <span>{{ $notificationSender }}</span>
                                            <span>{{ $notification->created_at->diffForHumans() }}</span>
                                        </div>
                                        <div class="d-flex justify-content-between align-items-center mt-2">
                                            @if(is_null($notification->read_at))
                                                <span class="notif-pill">Baru</span>
                                            @else
                                                <span class="small text-muted">Sudah dibaca</span>
                                            @endif
                                            <a href="{{ $notificationActionUrl }}" class="btn btn-sm btn-outline-secondary py-0 px-2">{{ $notificationActionLabel }}</a>
                                        </div>
                                    </div>
                                @empty
                                    <div class="notif-empty">Belum ada notifikasi dari admin.</div>
                                @endforelse
                            </div>
                        </div>
                    @endif
                @endauth
            </div>
        </nav>

        <div class="mt-4 app-layout">
            @php
                $hideSidebar = auth()->check()
                    && auth()->user()->role === 'admin'
                    && request()->routeIs('admin.complaints.show', 'admin.complaints.edit');
                $isUserSidebar = auth()->check()
                    && auth()->user()->role === 'user';
            @endphp
            @auth
                @if(!$hideSidebar)
                <aside class="app-sidebar">
                    <div class="sidebar-accent"></div>
                    <div class="sidebar-header {{ $isUserSidebar ? 'sidebar-header-centered' : '' }}">
                        @unless($isUserSidebar)
                        <div class="sidebar-logo" aria-hidden="true">
                            <x-application-logo class="h-6 w-6 text-white" />
                        </div>
                        @endunless
                        <div>
                            <div class="sidebar-brand">SIPAMAS</div>
                            <div class="sidebar-subtitle">Dinas Lingkungan</div>
                        </div>
                    </div>
                    <div class="sidebar-title">Menu</div>
                    @if(auth()->user()->role === 'admin')
                        <a class="sidebar-link {{ request()->routeIs('dashboard') && request('section', 'dashboard') === 'dashboard' ? 'active' : '' }}" href="{{ route('dashboard', ['section' => 'dashboard']) }}">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                <path d="M3 13h7v8H3z"/>
                                <path d="M14 3h7v18h-7z"/>
                                <path d="M3 3h7v7H3z"/>
                            </svg>
                            <span>Dashboard</span>
                        </a>
                        <a class="sidebar-link {{ request()->routeIs('dashboard') && request('section') === 'pengaduan' ? 'active' : '' }}" href="{{ route('dashboard', ['section' => 'pengaduan']) }}">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                <path d="M3 3h18v6H3z"/>
                                <path d="M3 9h18v12H3z"/>
                                <path d="M7 13h10"/>
                                <path d="M7 17h6"/>
                            </svg>
                            <span>Pengaduan</span>
                        </a>
                        <a class="sidebar-link {{ request()->routeIs('dashboard') && request('section') === 'petugas' ? 'active' : '' }}" href="{{ route('dashboard', ['section' => 'petugas']) }}">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                                <circle cx="9" cy="7" r="4"/>
                                <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                                <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                            </svg>
                            <span>Petugas</span>
                        </a>
                        <a class="sidebar-link {{ request()->routeIs('dashboard') && request('section') === 'laporan' ? 'active' : '' }}" href="{{ route('dashboard', ['section' => 'laporan']) }}">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                                <path d="M14 2v6h6"/>
                                <path d="M16 13H8"/>
                                <path d="M16 17H8"/>
                                <path d="M10 9H8"/>
                            </svg>
                            <span>Laporan</span>
                        </a>
                    @endif
                    @if(auth()->user()->role === 'user')
                        <a class="sidebar-link {{ request()->routeIs('complaints.index') ? 'active' : '' }}" href="{{ route('complaints.index') }}">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                <path d="M4 4h16v16H4z"/>
                                <path d="M8 8h8"/>
                                <path d="M8 12h8"/>
                                <path d="M8 16h6"/>
                            </svg>
                            <span>Pengaduan Saya</span>
                        </a>
                        <a class="sidebar-link {{ request()->routeIs('complaints.create') ? 'active' : '' }}" href="{{ route('complaints.create') }}">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                <path d="M12 5v14"/>
                                <path d="M5 12h14"/>
                            </svg>
                            <span>Buat Pengaduan</span>
                        </a>
                        @if($notificationsEnabled)
                            <a class="sidebar-link {{ request()->routeIs('notifications.*') ? 'active' : '' }}" href="{{ route('notifications.index') }}">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                                    <path d="M18 8a6 6 0 0 0-12 0v5l-2 2h16l-2-2z"/>
                                    <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
                                </svg>
                                <span>Notifikasi</span>
                            </a>
                        @endif
                    @endif
                    <div class="sidebar-divider"></div>
                    <a class="sidebar-link {{ request()->is('setting') ? 'active' : '' }}" href="/setting">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <circle cx="12" cy="12" r="3"/>
                            <path d="M19 12a7 7 0 0 0-.07-1l2.02-1.57-2-3.46-2.45 1a7 7 0 0 0-1.73-1l-.37-2.61h-4l-.37 2.61a7 7 0 0 0-1.73 1l-2.45-1-2 3.46L5.07 11a7 7 0 0 0 0 2l-2.02 1.57 2 3.46 2.45-1a7 7 0 0 0 1.73 1l.37 2.61h4l.37-2.61a7 7 0 0 0 1.73-1l2.45 1 2-3.46L18.93 13c.05-.33.07-.66.07-1z"/>
                        </svg>
                        <span>Pengaturan</span>
                    </a>
                    <a class="sidebar-link {{ request()->routeIs('about') ? 'active' : '' }}" href="{{ route('about') }}">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                            <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/>
                            <path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/>
                        </svg>
                        <span>Tentang SIPAMAS</span>
                    </a>
                    <a class="sidebar-link {{ request()->routeIs('contact') ? 'active' : '' }}" href="{{ route('contact') }}">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                            <path d="M4 4h16v12H4z"/>
                            <path d="M22 6l-10 7L2 6"/>
                            <path d="M8 20h8"/>
                        </svg>
                        <span>Kontak</span>
                    </a>
                    <a class="sidebar-link {{ request()->routeIs('faq') ? 'active' : '' }}" href="{{ route('faq') }}">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                            <circle cx="12" cy="12" r="10"/>
                            <path d="M10 10.2a2 2 0 1 1 3.46 1.36c-.58.6-1.21 1.02-1.46 1.94"/>
                            <path d="M12 17h.01"/>
                        </svg>
                        <span>FAQ</span>
                    </a>
                </aside>
                @endif
            @endauth

            <main class="{{ auth()->check() && !$hideSidebar ? 'app-main' : 'app-main app-main-full' }}">
                @if(isset($header))
                    <div class="mb-3">{{ $header }}</div>
                @endif

                @hasSection('content')
                    @yield('content')
                @elseif(isset($slot))
                    {{ $slot }}
                @endif
            </main>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        (function () {
            var storageKey = 'sipamas-theme';
            var root = document.documentElement;
            var body = document.body;

            function getTheme() {
                return root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
            }

            function persistTheme(theme) {
                try {
                    localStorage.setItem(storageKey, theme);
                } catch (error) {
                    // Ignore storage errors and keep the UI responsive.
                }
            }

            function syncControls(theme) {
                document.querySelectorAll('[data-theme-toggle]').forEach(function (button) {
                    var isDark = theme === 'dark';
                    button.classList.toggle('is-dark', isDark);
                    button.setAttribute('aria-pressed', isDark ? 'true' : 'false');
                });

                document.querySelectorAll('[data-theme-pill]').forEach(function (pill) {
                    pill.classList.toggle('is-active', pill.getAttribute('data-theme-pill') === theme);
                });

                document.querySelectorAll('[data-theme-radio]').forEach(function (radio) {
                    radio.checked = radio.value === theme;
                });
            }

            function applyTheme(theme) {
                var nextTheme = theme === 'dark' ? 'dark' : 'light';
                root.setAttribute('data-theme', nextTheme);
                body.classList.toggle('app-theme-dark', nextTheme === 'dark');
                body.classList.toggle('app-theme-light', nextTheme === 'light');
                body.setAttribute('data-theme-ready', 'true');
                persistTheme(nextTheme);
                syncControls(nextTheme);
            }

            document.querySelectorAll('[data-theme-toggle]').forEach(function (button) {
                button.addEventListener('click', function () {
                    applyTheme(getTheme() === 'dark' ? 'light' : 'dark');
                });
            });

            document.querySelectorAll('[data-theme-radio]').forEach(function (radio) {
                radio.addEventListener('change', function (event) {
                    if (event.target.checked) {
                        applyTheme(event.target.value);
                    }
                });
            });

            applyTheme(getTheme());
        })();
    </script>
    @stack('scripts')
</body>
</html>
