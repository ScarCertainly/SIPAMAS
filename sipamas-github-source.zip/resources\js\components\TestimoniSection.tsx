import React from 'react';

export function TestimoniSection() {
  const testimonials = [
    { name: 'Siti Nurhaliza', role: 'Warga Jakarta Selatan', quote: 'SIPAMAS memudahkan pelaporan sampah dan statusnya jelas.' },
    { name: 'Ahmad Fauzi', role: 'Ketua RT 05', quote: 'Transparan dan cepat, warga jadi aktif melapor.' },
    { name: 'Dewi Lestari', role: 'Aktivis Lingkungan', quote: 'Koordinasi lebih cepat, lampiran foto langsung diverifikasi.' },
  ];

  return (
    <section id="testimoni" className="py-16 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-serif text-slate-900 mb-4">Apa kata warga?</h2>
          <p className="text-slate-600">Pengalaman mereka setelah memakai SIPAMAS.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div key={i} className="p-6 rounded-xl bg-slate-50 border border-slate-200 shadow-sm">
              <div className="mb-3 text-amber-500">★★★★★</div>
              <p className="text-slate-700 italic mb-4">"{t.quote}"</p>
              <div className="font-semibold text-slate-900">{t.name}</div>
              <div className="text-sm text-slate-500">{t.role}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
