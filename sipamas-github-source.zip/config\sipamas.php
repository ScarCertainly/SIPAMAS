<?php

return [
    'email' => 'alifreinhartabdullah@gmail.com',
    'phone' => '085895600320',
    'phone_label' => '085895600320 (24/7)',
    'address_line_1' => 'Dinas Lingkungan Hidup',
    'address_line_2' => 'Indonesia',
    'facebook_url' => 'https://www.facebook.com/share/18fG4nmnD8/',
    'instagram_url' => 'https://www.instagram.com/alifreinharts?igsh=MTQ3a3FkczZja3UyNg==',
    'youtube_url' => 'https://youtube.com/@scarsstudiohd?si=9v8-_hp9lyi6RBQW',
];
