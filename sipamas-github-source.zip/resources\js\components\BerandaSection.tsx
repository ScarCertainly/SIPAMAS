import React from 'react';

export function BerandaSection() {
  return (
    <section className="min-h-screen bg-white text-slate-900 flex items-center justify-center">
      <div className="max-w-4xl text-center space-y-4 px-6">
        <h2 className="text-4xl font-bold">Beranda</h2>
        <p className="text-lg text-slate-600">
          Ini adalah placeholder Beranda. Gunakan tombol navbar untuk berpindah ke Pameran, Testimoni, atau Login.
        </p>
      </div>
    </section>
  );
}
