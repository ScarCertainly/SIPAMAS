@extends('layouts.app')

@section('title', 'FAQ SIPAMAS')

@push('styles')
<style>
    .sipamas-hero {
        text-align: center;
        margin-bottom: 2rem;
    }
    .sipamas-hero h2 {
        font-size: clamp(2rem, 3.2vw, 2.8rem);
        font-weight: 800;
        color: #0f172a;
        margin-bottom: 0.5rem;
    }
    .sipamas-hero p {
        color: #64748b;
        max-width: 720px;
        margin: 0 auto;
        font-size: 1.05rem;
    }
    .faq-card {
        background: #ffffff;
        border: 1px solid rgba(148, 163, 184, 0.2);
        border-radius: 18px;
        padding: 18px;
        box-shadow: 0 12px 26px rgba(15, 23, 42, 0.06);
    }
    .accordion-item {
        border: 0;
        background: transparent;
        margin-bottom: 12px;
    }
    .accordion-button {
        border-radius: 14px !important;
        background: #ffffff;
        box-shadow: 0 10px 20px rgba(15, 23, 42, 0.06);
        font-weight: 600;
    }
    .accordion-button:not(.collapsed) {
        color: #0f766e;
        background: #ecfeff;
        box-shadow: 0 12px 26px rgba(15, 23, 42, 0.08);
    }
    .accordion-body {
        color: #64748b;
        background: #ffffff;
        border-radius: 0 0 14px 14px;
        box-shadow: 0 8px 18px rgba(15, 23, 42, 0.04);
    }
    body.app-theme-dark .sipamas-hero h2 {
        color: #f8fafc;
    }
    body.app-theme-dark .sipamas-hero p {
        color: #cbd5e1;
    }
    body.app-theme-dark .faq-card {
        background: linear-gradient(180deg, rgba(15, 23, 42, 0.96) 0%, rgba(17, 24, 39, 0.96) 100%);
        border-color: rgba(148, 163, 184, 0.24);
    }
    body.app-theme-dark .accordion-button {
        color: #f8fafc;
        background: rgba(15, 23, 42, 0.86);
        box-shadow: 0 10px 20px rgba(2, 6, 23, 0.24);
    }
    body.app-theme-dark .accordion-button::after {
        filter: invert(1) brightness(1.4);
    }
    body.app-theme-dark .accordion-button:not(.collapsed) {
        color: #5eead4;
        background: rgba(15, 118, 110, 0.18);
        box-shadow: 0 12px 26px rgba(2, 6, 23, 0.32);
    }
    body.app-theme-dark .accordion-body {
        color: #cbd5e1;
        background: rgba(15, 23, 42, 0.82);
        box-shadow: 0 8px 18px rgba(2, 6, 23, 0.22);
    }
</style>
@endpush

@section('content')
<div class="app-card p-4 p-md-5">
    <div class="sipamas-hero">
        <h2>Pertanyaan yang Sering Diajukan</h2>
        <p>Temukan jawaban untuk pertanyaan umum tentang layanan SIPAMAS.</p>
    </div>

    <div class="faq-card">
        <div class="accordion" id="sipamasFaq">
            <div class="accordion-item">
                <h2 class="accordion-header" id="faqOne">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faqCollapseOne" aria-expanded="true" aria-controls="faqCollapseOne">
                        Apa itu SIPAMAS?
                    </button>
                </h2>
                <div id="faqCollapseOne" class="accordion-collapse collapse show" aria-labelledby="faqOne" data-bs-parent="#sipamasFaq">
                    <div class="accordion-body">
                        SIPAMAS adalah platform pengaduan lingkungan yang membantu warga melaporkan masalah,
                        memantau status, dan memastikan tindak lanjut dilakukan secara transparan.
                    </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header" id="faqTwo">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faqCollapseTwo" aria-expanded="false" aria-controls="faqCollapseTwo">
                        Bagaimana cara membuat pengaduan?
                    </button>
                </h2>
                <div id="faqCollapseTwo" class="accordion-collapse collapse" aria-labelledby="faqTwo" data-bs-parent="#sipamasFaq">
                    <div class="accordion-body">
                        Masuk ke menu Pengaduan lalu klik tombol "Buat Pengaduan", lengkapi detail dan lokasi, lalu kirim.
                    </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header" id="faqThree">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faqCollapseThree" aria-expanded="false" aria-controls="faqCollapseThree">
                        Siapa saja yang dapat menggunakan SIPAMAS?
                    </button>
                </h2>
                <div id="faqCollapseThree" class="accordion-collapse collapse" aria-labelledby="faqThree" data-bs-parent="#sipamasFaq">
                    <div class="accordion-body">
                        SIPAMAS dapat diakses oleh masyarakat sebagai pelapor dan admin sebagai pihak penindak lanjut.
                    </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header" id="faqFour">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faqCollapseFour" aria-expanded="false" aria-controls="faqCollapseFour">
                        Bagaimana memantau status laporan?
                    </button>
                </h2>
                <div id="faqCollapseFour" class="accordion-collapse collapse" aria-labelledby="faqFour" data-bs-parent="#sipamasFaq">
                    <div class="accordion-body">
                        Buka daftar pengaduan Anda, status akan tampil pada setiap laporan: pending, diproses, atau selesai.
                    </div>
                </div>
            </div>

            <div class="accordion-item">
                <h2 class="accordion-header" id="faqFive">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faqCollapseFive" aria-expanded="false" aria-controls="faqCollapseFive">
                        Bagaimana menghubungi admin jika ada kendala?
                    </button>
                </h2>
                <div id="faqCollapseFive" class="accordion-collapse collapse" aria-labelledby="faqFive" data-bs-parent="#sipamasFaq">
                    <div class="accordion-body">
                        Gunakan halaman Kontak untuk mengirim pesan atau hubungi nomor yang tersedia pada jam layanan.
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
