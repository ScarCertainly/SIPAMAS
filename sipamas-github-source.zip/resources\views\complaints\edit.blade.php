@extends('layouts.app')

@section('title', 'Edit Pengaduan')

@push('styles')
<style>
    .edit-complaint-shell {
        max-width: 1120px;
        margin: 0 auto;
    }
    .edit-hero {
        border: 1px solid rgba(15, 118, 110, 0.2);
        background: linear-gradient(135deg, rgba(15, 118, 110, 0.08) 0%, rgba(8, 145, 178, 0.08) 100%);
        border-radius: 18px;
        padding: 20px;
    }
    .edit-title {
        color: #0f3f42;
        font-size: clamp(1.35rem, 3vw, 2rem);
        font-weight: 800;
        margin-bottom: 4px;
    }
    .edit-subtitle {
        color: #336066;
        margin-bottom: 0;
    }
    .edit-grid {
        display: grid;
        grid-template-columns: minmax(0, 1.55fr) minmax(290px, 0.85fr);
        gap: 24px;
    }
    .edit-form-card,
    .edit-side-card {
        border-radius: 22px;
        border: 1px solid rgba(15, 118, 110, 0.16);
        background: linear-gradient(180deg, rgba(255, 255, 255, 0.96) 0%, rgba(249, 253, 252, 0.96) 100%);
        box-shadow: 0 20px 35px rgba(15, 23, 42, 0.08);
        overflow: hidden;
    }
    .edit-form-header,
    .edit-side-header {
        border-bottom: 1px solid rgba(15, 118, 110, 0.14);
        background: rgba(240, 253, 250, 0.8);
        padding: 20px 24px;
    }
    .edit-form-body,
    .edit-side-body {
        padding: 24px;
    }
    .edit-form-label {
        font-weight: 700;
        color: #164e52;
        margin-bottom: 8px;
    }
    .edit-input,
    .edit-input:focus,
    .edit-select,
    .edit-select:focus {
        border-color: rgba(13, 148, 136, 0.28);
        box-shadow: none;
    }
    .edit-input:focus,
    .edit-select:focus {
        border-color: rgba(13, 148, 136, 0.65);
        box-shadow: 0 0 0 0.2rem rgba(13, 148, 136, 0.12);
    }
    .edit-location-box,
    .edit-image-preview-box,
    .edit-side-panel {
        border: 1px solid rgba(15, 118, 110, 0.16);
        border-radius: 16px;
        background: rgba(240, 253, 250, 0.42);
    }
    .edit-location-box {
        padding: 16px;
    }
    .edit-file-chip,
    .edit-location-hint,
    .edit-side-copy {
        color: #475569;
        font-size: 0.9rem;
    }
    .edit-image-preview-box {
        margin-top: 14px;
        overflow: hidden;
        max-width: 360px;
        aspect-ratio: 4 / 3;
        display: none;
    }
    .edit-image-preview-box.is-visible {
        display: block;
    }
    .edit-image-preview-box img {
        width: 100%;
        height: 100%;
        object-fit: contain;
        display: block;
    }
    .edit-side-title {
        font-weight: 700;
        color: #0f3f42;
        margin-bottom: 4px;
    }
    .edit-side-item + .edit-side-item {
        border-top: 1px solid rgba(15, 118, 110, 0.12);
        margin-top: 16px;
        padding-top: 16px;
    }
    .edit-status-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 8px 12px;
        border-radius: 999px;
        font-size: 0.82rem;
        font-weight: 700;
    }
    .edit-status-badge.pending {
        background: #fef3c7;
        color: #92400e;
    }
    .edit-status-badge.process {
        background: #dbeafe;
        color: #1d4ed8;
    }
    .edit-status-badge.done {
        background: #dcfce7;
        color: #166534;
    }
    .edit-status-badge.rejected {
        background: #fee2e2;
        color: #b91c1c;
    }
    @media (max-width: 991.98px) {
        .edit-grid {
            grid-template-columns: 1fr;
        }
    }
    body.app-theme-dark .edit-hero {
        border-color: rgba(45, 212, 191, 0.24);
        background: linear-gradient(135deg, rgba(20, 184, 166, 0.12) 0%, rgba(14, 116, 144, 0.14) 100%);
    }
    body.app-theme-dark .edit-title,
    body.app-theme-dark .edit-form-label,
    body.app-theme-dark .edit-side-title {
        color: #ccfbf1;
    }
    body.app-theme-dark .edit-subtitle,
    body.app-theme-dark .edit-file-chip,
    body.app-theme-dark .edit-location-hint,
    body.app-theme-dark .edit-side-copy,
    body.app-theme-dark .text-muted {
        color: #94a3b8 !important;
    }
    body.app-theme-dark .edit-form-card,
    body.app-theme-dark .edit-side-card {
        border-color: rgba(148, 163, 184, 0.28);
        background: linear-gradient(180deg, rgba(15, 23, 42, 0.96) 0%, rgba(17, 24, 39, 0.96) 100%);
        box-shadow: 0 24px 35px rgba(2, 6, 23, 0.45);
    }
    body.app-theme-dark .edit-form-header,
    body.app-theme-dark .edit-side-header {
        border-bottom-color: rgba(45, 212, 191, 0.22);
        background: rgba(15, 60, 56, 0.22);
    }
    body.app-theme-dark .edit-input,
    body.app-theme-dark .edit-select {
        background-color: #0b1220;
        border-color: rgba(148, 163, 184, 0.35);
        color: #e2e8f0;
    }
    body.app-theme-dark .edit-input::placeholder {
        color: #64748b;
    }
    body.app-theme-dark .edit-location-box,
    body.app-theme-dark .edit-image-preview-box,
    body.app-theme-dark .edit-side-panel {
        border-color: rgba(45, 212, 191, 0.24);
        background: rgba(15, 60, 56, 0.16);
    }
</style>
@endpush

@section('content')
@php
    $statusTheme = match($complaint->status) {
        'approved', 'process' => 'process',
        'rejected' => 'rejected',
        'done' => 'done',
        default => 'pending'
    };
    $statusLabel = match($complaint->status) {
        'approved' => 'Diproses',
        'rejected' => 'Ditolak',
        'process' => 'Diproses',
        'done' => 'Selesai',
        default => 'Pending'
    };
@endphp

<div class="edit-complaint-shell">
    <div class="edit-hero mb-4">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
            <div>
                <h3 class="edit-title">Edit Pengaduan Lingkungan</h3>
                <p class="edit-subtitle">Perbarui detail laporan agar mudah ditindaklanjuti.</p>
            </div>
            <a href="{{ route('complaints.show', $complaint) }}" class="btn btn-outline-secondary btn-sm">Lihat Detail</a>
        </div>
    </div>

    <div class="edit-grid">
        <div class="edit-form-card">
            <div class="edit-form-header d-flex justify-content-between align-items-center flex-wrap gap-2">
                <div>
                    <div class="fw-semibold">Perbarui Detail Laporan</div>
                    <div class="small text-muted">Sesuaikan isi laporan agar tim bisa memproses dengan akurat.</div>
                </div>
                <span class="badge bg-info">Edit Laporan</span>
            </div>
            <div class="edit-form-body">
                <form method="POST" action="{{ route('complaints.update', $complaint) }}" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')

                    <div class="mb-3">
                        <label for="title" class="form-label edit-form-label">Judul</label>
                        <input id="title" name="title" type="text" class="form-control edit-input @error('title') is-invalid @enderror" placeholder="Masukkan judul pengaduan" value="{{ old('title', $complaint->title) }}" required>
                        @error('title')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="category_id" class="form-label edit-form-label">Kategori Lingkungan</label>
                        <select id="category_id" name="category_id" class="form-select edit-select @error('category_id') is-invalid @enderror" required>
                            @foreach($categories as $category)
                                <option value="{{ $category->id }}" {{ (int) old('category_id', $complaint->category_id) === $category->id ? 'selected' : '' }}>
                                    {{ $category->name }}
                                </option>
                            @endforeach
                        </select>
                        @error('category_id')
                            <div class="invalid-feedback d-block">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label edit-form-label">Deskripsi</label>
                        <textarea id="description" name="description" rows="5" class="form-control edit-input @error('description') is-invalid @enderror" placeholder="Jelaskan lokasi, waktu kejadian, dan dampak lingkungan" required>{{ old('description', $complaint->description) }}</textarea>
                        @error('description')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label class="form-label edit-form-label">Lokasi Kejadian</label>
                        <div class="edit-location-box">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label for="province" class="form-label">Provinsi (opsional)</label>
                                    <input id="province" name="province" type="text" class="form-control edit-input @error('province') is-invalid @enderror" value="{{ old('province', $complaint->province) }}" placeholder="Contoh: Jawa Barat">
                                    @error('province')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="col-md-6">
                                    <label for="city" class="form-label">Kota/Kabupaten (opsional)</label>
                                    <input id="city" name="city" type="text" class="form-control edit-input @error('city') is-invalid @enderror" value="{{ old('city', $complaint->city) }}" placeholder="Contoh: Kota Bandung">
                                    @error('city')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="col-md-6">
                                    <label for="district" class="form-label">Kecamatan (opsional)</label>
                                    <input id="district" name="district" type="text" class="form-control edit-input @error('district') is-invalid @enderror" value="{{ old('district', $complaint->district) }}" placeholder="Contoh: Coblong">
                                    @error('district')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="col-md-6">
                                    <label for="village" class="form-label">Desa/Kelurahan (opsional)</label>
                                    <input id="village" name="village" type="text" class="form-control edit-input @error('village') is-invalid @enderror" value="{{ old('village', $complaint->village) }}" placeholder="Contoh: Dago">
                                    @error('village')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="col-12">
                                    <label for="street_address" class="form-label">Jalan / Detail Alamat</label>
                                    <textarea id="street_address" name="street_address" rows="2" class="form-control edit-input @error('street_address') is-invalid @enderror" placeholder="Contoh: Jl. Ir. H. Juanda No. 120">{{ old('street_address', $complaint->street_address) }}</textarea>
                                    @error('street_address')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="col-12">
                                    <input type="hidden" id="latitude" name="latitude" value="{{ old('latitude', $complaint->latitude) }}">
                                    <input type="hidden" id="longitude" name="longitude" value="{{ old('longitude', $complaint->longitude) }}">
                                    <div class="d-flex gap-2 flex-wrap">
                                        <button type="button" id="use-current-location" class="btn btn-outline-secondary btn-sm">Perbarui Lokasi GPS</button>
                                        <button type="button" id="clear-current-location" class="btn btn-outline-danger btn-sm">Hapus Titik GPS</button>
                                    </div>
                                    <div id="gps-status" class="edit-location-hint mt-2">
                                        @if(old('latitude', $complaint->latitude) && old('longitude', $complaint->longitude))
                                            Lokasi GPS aktif: {{ old('latitude', $complaint->latitude) }}, {{ old('longitude', $complaint->longitude) }}
                                        @else
                                            Belum ada titik GPS tersimpan.
                                        @endif
                                    </div>
                                    @error('latitude')
                                        <div class="text-danger small mt-1">{{ $message }}</div>
                                    @enderror
                                    @error('longitude')
                                        <div class="text-danger small mt-1">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="image_evidence" class="form-label edit-form-label">Foto Bukti (opsional)</label>
                        <input id="image_evidence" name="image_evidence" type="file" class="form-control edit-input @error('image_evidence') is-invalid @enderror" accept="image/*">
                        <div id="edit-image-evidence-preview-box" class="edit-image-preview-box {{ $complaint->image_evidence_url ? 'is-visible' : '' }}">
                            <img id="edit-image-evidence-preview" src="{{ $complaint->image_evidence_url ?? '' }}" alt="Preview foto bukti">
                        </div>
                        @error('image_evidence')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                        @if($complaint->image_evidence_url)
                            <small class="edit-file-chip d-block mt-2">
                                Lampiran saat ini: <a href="{{ $complaint->image_evidence_url }}" target="_blank" rel="noreferrer noopener" class="text-decoration-underline">Lihat file</a>
                            </small>
                        @elseif($complaint->image_evidence)
                            <small class="edit-file-chip d-block mt-2">Lampiran saat ini: {{ $complaint->image_evidence }}</small>
                        @endif
                    </div>

                    <div class="d-flex justify-content-end gap-2">
                        <a href="{{ route('complaints.show', $complaint) }}" class="btn btn-light">Batal</a>
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="d-flex flex-column gap-4">
            <div class="edit-side-card">
                <div class="edit-side-header">
                    <div class="fw-semibold">Ringkasan Laporan</div>
                    <div class="small text-muted">Gunakan panel ini untuk memastikan data tetap akurat.</div>
                </div>
                <div class="edit-side-body">
                    <div class="edit-side-item">
                        <div class="small text-muted mb-1">Status Saat Ini</div>
                        <span class="edit-status-badge {{ $statusTheme }}">{{ $statusLabel }}</span>
                    </div>
                    <div class="edit-side-item">
                        <div class="small text-muted mb-1">Kategori</div>
                        <div class="edit-side-title">{{ $complaint->category->name ?? '-' }}</div>
                        <div class="edit-side-copy">Kategori membantu tim mengarahkan laporan ke tindak lanjut yang tepat.</div>
                    </div>
                    <div class="edit-side-item">
                        <div class="small text-muted mb-1">Dibuat</div>
                        <div class="edit-side-title">{{ $complaint->created_at->format('d M Y, H:i') }}</div>
                        <div class="edit-side-copy">Perubahan yang Anda simpan akan memperbarui isi laporan, bukan membuat laporan baru.</div>
                    </div>
                </div>
            </div>

            <div class="edit-side-card">
                <div class="edit-side-header">
                    <div class="fw-semibold">Catatan Perubahan</div>
                    <div class="small text-muted">Hal yang sebaiknya dijaga saat mengedit.</div>
                </div>
                <div class="edit-side-body">
                    <div class="edit-side-panel p-3">
                        <div class="edit-side-copy">
                            Pastikan judul, deskripsi, dan lokasi tetap merujuk pada kejadian yang sama. Jika masalah sudah berubah total, lebih baik buat laporan baru agar riwayat tetap jelas.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    (function () {
        const gpsButton = document.getElementById('use-current-location');
        const clearGpsButton = document.getElementById('clear-current-location');
        const latInput = document.getElementById('latitude');
        const lngInput = document.getElementById('longitude');
        const gpsStatus = document.getElementById('gps-status');
        const imageEvidenceInput = document.getElementById('image_evidence');
        const imageEvidencePreviewBox = document.getElementById('edit-image-evidence-preview-box');
        const imageEvidencePreview = document.getElementById('edit-image-evidence-preview');

        if (gpsButton && clearGpsButton && latInput && lngInput && gpsStatus) {
            gpsButton.addEventListener('click', function () {
                if (!navigator.geolocation) {
                    gpsStatus.textContent = 'Browser tidak mendukung geolocation.';
                    return;
                }

                gpsStatus.textContent = 'Mengambil lokasi aktif...';
                navigator.geolocation.getCurrentPosition(function (position) {
                    const lat = position.coords.latitude.toFixed(7);
                    const lng = position.coords.longitude.toFixed(7);
                    latInput.value = lat;
                    lngInput.value = lng;
                    gpsStatus.textContent = 'Lokasi GPS diperbarui: ' + lat + ', ' + lng;
                }, function () {
                    gpsStatus.textContent = 'Gagal mengambil lokasi. Pastikan izin lokasi browser aktif.';
                }, {
                    enableHighAccuracy: true,
                    timeout: 12000,
                    maximumAge: 0
                });
            });

            clearGpsButton.addEventListener('click', function () {
                latInput.value = '';
                lngInput.value = '';
                gpsStatus.textContent = 'Titik GPS dihapus. Sistem akan memakai alamat manual.';
            });
        }

        if (!imageEvidenceInput || !imageEvidencePreviewBox || !imageEvidencePreview) {
            return;
        }

        imageEvidenceInput.addEventListener('change', function () {
            const hasFile = this.files && this.files.length;

            if (!hasFile) {
                const currentSrc = imageEvidencePreview.getAttribute('src');
                if (currentSrc) {
                    imageEvidencePreviewBox.classList.add('is-visible');
                    return;
                }

                imageEvidencePreviewBox.classList.remove('is-visible');
                return;
            }

            const objectUrl = URL.createObjectURL(this.files[0]);
            imageEvidencePreview.setAttribute('src', objectUrl);
            imageEvidencePreviewBox.classList.add('is-visible');
        });
    })();
</script>
@endpush
