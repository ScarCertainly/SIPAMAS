import React, { useState } from 'react';
import { Mail, Lock, User, MessageCircle, Eye, EyeOff, Leaf } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const getCsrf = () => {
  const el = document.querySelector('meta[name="csrf-token"]') as HTMLMetaElement | null;
  return el?.content ?? '';
};

export function LoginPage() {
  const [activeTab, setActiveTab] = useState<'login' | 'guest'>('login');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);

  return (
    <section id="login" className="min-h-screen flex bg-gray-50">
      {/* Left Side - Image */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden bg-gradient-to-br from-emerald-600 to-teal-700">
        <div className="absolute inset-0">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1668900016730-75a72135f96d?auto=format&fit=crop&w=1600&q=80"
            alt="Environmental Background"
            className="w-full h-full object-cover opacity-30"
          />
        </div>
        <div className="relative z-10 flex flex-col justify-center px-12 text-white space-y-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
              <Leaf className="w-10 h-10" />
            </div>
            <div>
              <div className="text-sm font-medium opacity-90">PORTAL DINAS LINGKUNGAN</div>
              <div className="text-3xl font-bold">SIPAMAS</div>
            </div>
          </div>
          <h1 className="text-4xl font-bold">Sistem Pengaduan Lingkungan Hidup Masyarakat</h1>
          <p className="text-lg opacity-90 leading-relaxed">
            Kelola pengaduan lingkungan hidup masyarakat secara cepat, transparan, dan terdokumentasi.
          </p>
        </div>
      </div>

      {/* Right Side - Login Form */}
      <div className="flex-1 flex items-center justify-center p-6 lg:p-12">
        <div className="w-full max-w-md">
          {/* Mobile Header */}
          <div className="lg:hidden mb-8 text-center">
            <div className="inline-flex items-center gap-2 mb-3">
              <div className="w-12 h-12 bg-gradient-to-br from-emerald-600 to-teal-700 rounded-xl flex items-center justify-center">
                <Leaf className="w-7 h-7 text-white" />
              </div>
            </div>
            <div className="text-xs text-emerald-700 font-semibold mb-1">PORTAL DINAS LINGKUNGAN</div>
            <div className="text-2xl font-bold text-gray-900">SIPAMAS</div>
            <p className="text-sm text-gray-600 mt-2">Sistem Pengaduan Lingkungan Hidup Masyarakat</p>
          </div>

          <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
            <div className="mb-6">
              <div className="inline-block px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-xs font-semibold mb-3">
                PORTAL RESMI PENGADUAN
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Masuk ke SIPAMAS</h2>
              <p className="text-sm text-gray-600">Pilih cara masuk yang sesuai dengan kebutuhan Anda</p>
            </div>

            <div className="grid w-full grid-cols-2 mb-6 rounded-xl overflow-hidden border border-gray-200">
              <button
                onClick={() => setActiveTab('login')}
                className={`py-3 font-semibold transition ${
                  activeTab === 'login' ? 'bg-emerald-600 text-white' : 'bg-white text-gray-600'
                }`}
              >
                Login
              </button>
              <button
                onClick={() => setActiveTab('guest')}
                className={`py-3 font-semibold transition ${
                  activeTab === 'guest' ? 'bg-emerald-600 text-white' : 'bg-white text-gray-600'
                }`}
              >
                Guest
              </button>
            </div>

            {activeTab === 'login' ? (
              <UserForm
                showPassword={showPassword}
                setShowPassword={setShowPassword}
                rememberMe={rememberMe}
                setRememberMe={setRememberMe}
              />
            ) : (
              <GuestForm />
            )}
          </div>

          <p className="text-center text-xs text-gray-500 mt-6">© 2026 Dinas Lingkungan. Semua hak dilindungi.</p>
        </div>
      </div>
    </section>
  );
}

type UserFormProps = {
  showPassword: boolean;
  setShowPassword: (v: boolean) => void;
  rememberMe: boolean;
  setRememberMe: (v: boolean) => void;
};

function UserForm({ showPassword, setShowPassword, rememberMe, setRememberMe }: UserFormProps) {
  return (
    <form className="space-y-4" method="POST" action="/login">
      <input type="hidden" name="_token" value={getCsrf()} />

      <div className="space-y-2">
        <label htmlFor="email" className="text-sm font-medium text-gray-700">
          Email
        </label>
        <div className="relative">
          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            id="email"
            name="email"
            type="email"
            placeholder="nama@email.com"
            required
            className="w-full h-11 pl-10 rounded-lg border border-gray-200 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
          />
        </div>
      </div>

      <div className="space-y-2">
        <label htmlFor="password" className="text-sm font-medium text-gray-700">
          Password
        </label>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            id="password"
            name="password"
            type={showPassword ? 'text' : 'password'}
            placeholder="••••••••"
            required
            autoComplete="current-password"
            className="w-full h-11 pl-10 pr-10 rounded-lg border border-gray-200 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
          >
            {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
          </button>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <label className="flex items-center gap-2 text-sm text-gray-600 cursor-pointer select-none">
          <input
            type="checkbox"
            name="remember"
            checked={rememberMe}
            onChange={(e) => setRememberMe(e.target.checked)}
            className="w-4 h-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
          />
          Remember me
        </label>
        <a href="#" className="text-sm font-medium text-emerald-600 hover:text-emerald-700 transition-colors">
          Lupa password?
        </a>
      </div>

      <button
        type="submit"
        className="w-full h-11 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-semibold hover:from-emerald-700 hover:to-teal-700 transition-all"
      >
        LOG IN
      </button>

      <div className="text-center text-sm text-gray-600">
        Belum punya akun?{' '}
        <a href="/register" className="font-medium text-emerald-600 hover:text-emerald-700 transition-colors">
          Daftar di sini
        </a>
      </div>
    </form>
  );
}

function GuestForm() {
  return (
    <form className="space-y-4" method="POST" action="/guest/login">
      <input type="hidden" name="_token" value={getCsrf()} />

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-sm text-blue-800">Akun guest akan dibuat otomatis dan memiliki akses seperti user biasa.</p>
      </div>

      <div className="space-y-2">
        <label htmlFor="guest_name" className="text-sm font-medium text-gray-700">
          Nama <span className="text-gray-400 font-normal">(opsional)</span>
        </label>
        <div className="relative">
          <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            id="guest_name"
            name="guest_name"
            type="text"
            placeholder="Nama lengkap Anda"
            className="w-full h-11 pl-10 rounded-lg border border-gray-200 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
          />
        </div>
      </div>

      <div className="space-y-2">
        <label htmlFor="guest_whatsapp" className="text-sm font-medium text-gray-700">
          Nomor WhatsApp
        </label>
        <div className="relative">
          <MessageCircle className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            id="guest_whatsapp"
            name="guest_whatsapp"
            type="tel"
            placeholder="contoh: 081234567890 / 6281234567890"
            required
            className="w-full h-11 pl-10 rounded-lg border border-gray-200 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
          />
        </div>
      </div>

      <button
        type="submit"
        className="w-full h-11 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-semibold hover:from-emerald-700 hover:to-teal-700 transition-all"
      >
        MASUK SEBAGAI GUEST VIA WHATSAPP
      </button>
    </form>
  );
}
