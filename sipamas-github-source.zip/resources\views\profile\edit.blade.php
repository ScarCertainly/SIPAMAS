@extends('layouts.app')

@section('title', 'Profil')

@php
    $fullName = $user->name ?? 'User SIPAMAS';
    $email = $user->email ?? '-';
    $phone = $user->whatsapp_number ? ('+' . ltrim((string) $user->whatsapp_number, '+')) : '-';
    $role = ucfirst($user->role ?? 'user');
    $joinedAt = $user->created_at ? $user->created_at->translatedFormat('d F Y') : '-';
    $photoUrl = $user->profile_photo_url;
    $initials = collect(explode(' ', trim((string) $fullName)))
        ->filter()
        ->take(2)
        ->map(fn ($part) => strtoupper(substr($part, 0, 1)))
        ->join('');

    $profileInfo = [
        ['label' => 'Nama Lengkap', 'value' => $fullName, 'icon' => 'user'],
        ['label' => 'Email', 'value' => $email, 'icon' => 'mail'],
        ['label' => 'No. WhatsApp', 'value' => $phone, 'icon' => 'phone'],
        ['label' => 'Role', 'value' => $role, 'icon' => 'briefcase'],
        ['label' => 'Bergabung', 'value' => $joinedAt, 'icon' => 'calendar'],
    ];
@endphp

@push('styles')
<style>
    .profile-page {
        max-width: 980px;
        margin: 0 auto;
    }
    .profile-main-card {
        background: #fff;
        border-radius: 24px;
        overflow: hidden;
        border: 1px solid rgba(15, 23, 42, 0.07);
        box-shadow: 0 18px 38px rgba(15, 23, 42, 0.08);
    }
    .profile-cover {
        height: 160px;
        background: linear-gradient(90deg, #0f766e, #14b8a6, #10b981);
        position: relative;
    }
    .profile-cover::before {
        content: "";
        position: absolute;
        inset: 0;
        background: linear-gradient(to top, rgba(0,0,0,0.25), transparent);
    }
    .profile-body {
        padding: 0 28px 28px;
    }
    .profile-head {
        display: flex;
        justify-content: space-between;
        align-items: flex-end;
        flex-wrap: wrap;
        gap: 16px;
        margin-top: -56px;
        position: relative;
        z-index: 1;
    }
    .profile-avatar {
        width: 124px;
        height: 124px;
        border-radius: 28px;
        background: linear-gradient(135deg, #0f766e, #10b981);
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 40px;
        font-weight: 800;
        border: 4px solid #fff;
        box-shadow: 0 18px 28px rgba(15, 118, 110, 0.25);
        overflow: hidden;
    }
    .profile-avatar img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    .profile-name {
        font-size: 30px;
        font-weight: 800;
        margin: 0 0 2px;
        color: #0f172a;
    }
    .profile-role {
        color: #0f766e;
        font-weight: 600;
        margin-bottom: 8px;
    }
    .profile-chip {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 6px 12px;
        border-radius: 999px;
        font-size: .82rem;
        font-weight: 600;
        margin-right: 8px;
    }
    .profile-chip.teal {
        background: #ecfdf5;
        color: #0f766e;
    }
    .profile-chip.green {
        background: #f0fdf4;
        color: #15803d;
    }
    .profile-stat-grid {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        border-top: 1px solid #f1f5f9;
        margin-top: 22px;
        padding-top: 22px;
    }
    .profile-stat {
        text-align: center;
    }
    .profile-stat + .profile-stat {
        border-left: 1px solid #f1f5f9;
    }
    .profile-stat strong {
        display: block;
        font-size: 28px;
        color: #0f172a;
    }
    .profile-tab-card {
        margin-top: 18px;
        background: #fff;
        border-radius: 18px;
        border: 1px solid rgba(15, 23, 42, 0.07);
        box-shadow: 0 12px 30px rgba(15, 23, 42, 0.07);
        overflow: hidden;
    }
    .profile-tabs {
        display: flex;
        border-bottom: 1px solid #f1f5f9;
    }
    .profile-tab-btn {
        flex: 1;
        border: 0;
        background: transparent;
        padding: 14px;
        font-weight: 600;
        color: #64748b;
    }
    .profile-tab-btn.active {
        color: #0f766e;
        border-bottom: 2px solid #10b981;
    }
    .profile-tab-panel {
        display: none;
        padding: 24px;
    }
    .profile-tab-panel.active {
        display: block;
    }
    .profile-info-item {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 12px;
        border-radius: 12px;
    }
    .profile-info-item:hover {
        background: #f8fafc;
    }
    .profile-icon {
        width: 40px;
        height: 40px;
        border-radius: 12px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #ecfeff, #ecfdf5);
        color: #0f766e;
        flex: 0 0 auto;
    }
    .dialog-backdrop {
        position: fixed;
        inset: 0;
        z-index: 1050;
        display: none;
        align-items: center;
        justify-content: center;
        padding: 1rem;
        background: rgba(15, 23, 42, 0.55);
        backdrop-filter: blur(4px);
    }
    .dialog-backdrop.show {
        display: flex;
    }
    .dialog-card {
        width: 100%;
        max-width: 760px;
        max-height: 90vh;
        overflow-y: auto;
        background: #fff;
        border-radius: 24px;
        box-shadow: 0 25px 55px rgba(2, 6, 23, 0.25);
    }
    .dialog-header {
        position: sticky;
        top: 0;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 1.5rem 2rem;
        border-radius: 24px 24px 0 0;
        color: #fff;
        background: linear-gradient(90deg, #0f766e, #06b6d4);
    }
    .dialog-body {
        padding: 1.75rem 2rem 2rem;
    }
    .avatar-picker {
        width: 96px;
        height: 96px;
        border-radius: 20px;
        overflow: hidden;
        border: 4px solid #f1f5f9;
        background: linear-gradient(135deg, #0f766e, #10b981);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #fff;
        font-size: 2rem;
        font-weight: 700;
    }
    .avatar-picker img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    @media (max-width: 767px) {
        .profile-stat-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            row-gap: 1rem;
        }
        .profile-stat + .profile-stat {
            border-left: 0;
        }
        .dialog-header, .dialog-body {
            padding-left: 1rem;
            padding-right: 1rem;
        }
    }
</style>
@endpush

@section('content')
<div class="profile-page">
    @if (session('status') === 'profile-updated')
        <div class="alert alert-success d-flex align-items-center gap-2 mb-3">
            <i data-lucide="check-circle" style="width:18px;height:18px;"></i>
            Profil berhasil diperbarui.
        </div>
    @endif

    @if ($errors->any())
        <div class="alert alert-danger mb-3">
            <div class="fw-semibold mb-1">Periksa kembali form:</div>
            <ul class="mb-0 ps-3">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="profile-main-card">
        <div class="profile-cover"></div>
        <div class="profile-body">
            <div class="profile-head">
                <div class="d-flex flex-wrap align-items-end gap-4">
                    <div class="profile-avatar">
                        @if ($photoUrl)
                            <img src="{{ $photoUrl }}" alt="Foto Profil">
                        @else
                            {{ $initials ?: 'U' }}
                        @endif
                    </div>
                    <div>
                        <h2 class="profile-name">{{ $fullName }}</h2>
                        <div class="profile-role">{{ $role }}</div>
                        <span class="profile-chip teal">
                            <i data-lucide="mail" style="width:14px;height:14px"></i>
                            {{ $email }}
                        </span>
                        <span class="profile-chip green">
                            <span style="width:8px;height:8px;border-radius:50%;background:#22c55e;display:inline-block"></span>
                            Aktif
                        </span>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <a href="{{ route('complaints.index') }}" class="btn btn-outline-secondary">
                        <i data-lucide="arrow-left" style="width:16px;height:16px"></i>
                        Kembali ke Komplain
                    </a>
                    <button type="button" class="btn btn-primary" id="openEditProfileDialog">Edit Profil</button>
                </div>
            </div>

            <div class="profile-stat-grid">
                <div class="profile-stat">
                    <strong>{{ $stats['total'] ?? 0 }}</strong>
                    <small class="text-muted">Total Komplain</small>
                </div>
                <div class="profile-stat">
                    <strong>{{ $stats['process'] ?? 0 }}</strong>
                    <small class="text-muted">Diproses</small>
                </div>
                <div class="profile-stat">
                    <strong>{{ $stats['pending'] ?? 0 }}</strong>
                    <small class="text-muted">Pending</small>
                </div>
                <div class="profile-stat">
                    <strong>{{ $stats['rejected'] ?? 0 }}</strong>
                    <small class="text-muted">Ditolak</small>
                </div>
            </div>
        </div>
    </div>

    <div class="profile-tab-card">
        <div class="profile-tabs">
            <button type="button" class="profile-tab-btn active" data-tab-target="informasi" id="tab-informasi">
                <i data-lucide="user" style="width:16px;height:16px"></i> Informasi
            </button>
            <button type="button" class="profile-tab-btn" data-tab-target="aktivitas" id="tab-aktivitas">
                <i data-lucide="activity" style="width:16px;height:16px"></i> Aktivitas
            </button>
        </div>

        <div class="profile-tab-panel active" data-tab-panel="informasi" id="panel-informasi">
            <h5 class="mb-3">Informasi Pribadi</h5>
            @foreach($profileInfo as $info)
                <div class="profile-info-item">
                    <span class="profile-icon">
                        <i data-lucide="{{ $info['icon'] }}" style="width:18px;height:18px"></i>
                    </span>
                    <div class="flex-grow-1">
                        <div class="small text-muted">{{ $info['label'] }}</div>
                        <div class="fw-semibold">{{ $info['value'] }}</div>
                    </div>
                    <i data-lucide="chevron-right" style="width:18px;height:18px;color:#94a3b8"></i>
                </div>
            @endforeach
        </div>

        <div class="profile-tab-panel" data-tab-panel="aktivitas" id="panel-aktivitas">
            <h5 class="mb-3">Komplain Terbaru</h5>
            @forelse ($recentComplaints as $complaint)
                <div class="d-flex align-items-start gap-3 p-3 rounded-3 mb-2" style="background:#f8fafc">
                    <div class="rounded-circle d-inline-flex align-items-center justify-content-center bg-info-subtle text-info" style="width:40px;height:40px;">
                        <i data-lucide="file-text" style="width:18px;height:18px"></i>
                    </div>
                    <div class="flex-grow-1">
                        <div class="fw-semibold">{{ $complaint->title }}</div>
                        <div class="small text-muted text-capitalize">
                            Status: {{ $complaint->status }} • {{ $complaint->created_at?->diffForHumans() }}
                        </div>
                    </div>
                </div>
            @empty
                <p class="text-muted mb-0">Belum ada komplain yang tercatat.</p>
            @endforelse
        </div>

    </div>
</div>

<div class="dialog-backdrop" id="editProfileDialog" aria-hidden="true">
    <div class="dialog-card">
        <div class="dialog-header">
            <h2 class="h4 mb-0">Edit Profil</h2>
            <button type="button" class="btn btn-light btn-sm" id="closeEditProfileDialog">
                <i data-lucide="x" style="width:16px;height:16px;"></i>
            </button>
        </div>
        <div class="dialog-body">
            <form method="POST" action="{{ route('profile.update') }}" enctype="multipart/form-data">
                @csrf
                @method('PATCH')

                <div class="mb-4">
                    <label class="form-label fw-semibold d-block">Foto Profil</label>
                    <div class="d-flex align-items-center gap-3 flex-wrap">
                        <div class="avatar-picker" id="profilePhotoPreview">
                            @if ($photoUrl)
                                <img src="{{ $photoUrl }}" alt="Foto Profil">
                            @else
                                {{ $initials ?: 'U' }}
                            @endif
                        </div>
                        <div>
                            <input type="file" name="profile_photo" id="profilePhotoInput" class="form-control" accept="image/*">
                            <div class="form-text">JPG, PNG, GIF, WEBP. Maks 5MB.</div>
                        </div>
                    </div>
                    @error('profile_photo')
                        <div class="text-danger small mt-1">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-3">
                    <label for="profileName" class="form-label">Nama Lengkap</label>
                    <input
                        id="profileName"
                        type="text"
                        name="name"
                        value="{{ old('name', $user->name) }}"
                        class="form-control @error('name') is-invalid @enderror"
                        required
                    >
                    @error('name')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-3">
                    <label for="profileEmail" class="form-label">Email</label>
                    <input
                        id="profileEmail"
                        type="email"
                        name="email"
                        value="{{ old('email', $user->email) }}"
                        class="form-control @error('email') is-invalid @enderror"
                        required
                    >
                    @error('email')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="profileWhatsapp" class="form-label">No. WhatsApp</label>
                    <input
                        id="profileWhatsapp"
                        type="text"
                        name="whatsapp_number"
                        value="{{ old('whatsapp_number', $user->whatsapp_number) }}"
                        class="form-control @error('whatsapp_number') is-invalid @enderror"
                        placeholder="62812xxxxxx"
                    >
                    @error('whatsapp_number')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-light w-100" id="cancelEditProfileDialog">Batal</button>
                    <button type="submit" class="btn btn-primary w-100">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script src="https://unpkg.com/lucide@latest"></script>
<script>
    (function () {
        const tabButtons = document.querySelectorAll('[data-tab-target]');
        const tabPanels = document.querySelectorAll('[data-tab-panel]');
        const dialog = document.getElementById('editProfileDialog');
        const openButtons = [document.getElementById('openEditProfileDialog'), document.getElementById('openEditProfileDialog2')];
        const closeButtons = [document.getElementById('closeEditProfileDialog'), document.getElementById('cancelEditProfileDialog')];
        const photoInput = document.getElementById('profilePhotoInput');
        const photoPreview = document.getElementById('profilePhotoPreview');

        function activateTab(target) {
            if (!target) return;
            tabButtons.forEach((b) => b.classList.remove('active'));
            tabPanels.forEach((panel) => panel.classList.remove('active'));

            const activeButton = document.querySelector('[data-tab-target="' + target + '"]');
            const activePanel = document.querySelector('[data-tab-panel="' + target + '"]');
            if (activeButton) {
                activeButton.classList.add('active');
            }
            if (activePanel) {
                activePanel.classList.add('active');
            }
        }

        tabButtons.forEach((button) => {
            button.addEventListener('click', () => {
                const target = button.getAttribute('data-tab-target');
                activateTab(target);
                if (target) {
                    history.replaceState(null, '', '#' + target);
                }
            });
        });

        if (window.location.hash) {
            const initialTarget = window.location.hash.replace('#', '');
            activateTab(initialTarget);
        }

        function openDialog() {
            if (!dialog) return;
            dialog.classList.add('show');
            dialog.setAttribute('aria-hidden', 'false');
        }

        function closeDialog() {
            if (!dialog) return;
            dialog.classList.remove('show');
            dialog.setAttribute('aria-hidden', 'true');
        }

        openButtons.forEach((button) => {
            if (!button) return;
            button.addEventListener('click', openDialog);
        });

        closeButtons.forEach((button) => {
            if (!button) return;
            button.addEventListener('click', closeDialog);
        });

        if (dialog) {
            dialog.addEventListener('click', (event) => {
                if (event.target === dialog) {
                    closeDialog();
                }
            });
        }

        if (photoInput && photoPreview) {
            photoInput.addEventListener('change', (event) => {
                const file = event.target.files && event.target.files[0];
                if (!file) return;

                const reader = new FileReader();
                reader.onload = function (e) {
                    if (!e.target || !e.target.result) return;
                    photoPreview.innerHTML = '<img src="' + e.target.result + '" alt="Preview Foto Profil">';
                };
                reader.readAsDataURL(file);
            });
        }

        if (window.lucide) {
            window.lucide.createIcons();
        }

        @if ($errors->has('name') || $errors->has('email') || $errors->has('whatsapp_number') || $errors->has('profile_photo'))
            openDialog();
        @endif
    })();
</script>
@endpush
