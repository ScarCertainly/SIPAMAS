<?php

namespace App\Models;

use App\Support\PublicUploadedMedia;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Complaint extends Model
{
    use HasFactory;

    // WAJIB biar Complaint::create() bisa jalan
    protected $fillable = [
        'user_id',
        'category_id',
        'title',
        'description',
        'image_evidence',
        'admin_response_message',
        'admin_action_taken',
        'admin_response_image',
        'admin_responded_by',
        'admin_responded_at',
        'allow_user_chat',
        'status',
        'location_source',
        'latitude',
        'longitude',
        'province',
        'city',
        'district',
        'village',
        'street_address',
    ];

    protected $casts = [
        'admin_responded_at' => 'datetime',
        'allow_user_chat' => 'boolean',
    ];

    // Relasi ke User
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // Relasi ke Category
    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function adminResponder()
    {
        return $this->belongsTo(User::class, 'admin_responded_by');
    }

    public function comments()
    {
        return $this->hasMany(ComplaintComment::class)->oldest();
    }

    public function statusHistories()
    {
        return $this->hasMany(ComplaintStatusHistory::class)->latest();
    }

    public function getImageEvidenceUrlAttribute(): ?string
    {
        return $this->resolveStoredImageUrl($this->image_evidence);
    }

    public function getAdminResponseImageUrlAttribute(): ?string
    {
        return $this->resolveStoredImageUrl($this->admin_response_image);
    }

    private function resolveStoredImageUrl(?string $value): ?string
    {
        return PublicUploadedMedia::url($value);
    }
}
