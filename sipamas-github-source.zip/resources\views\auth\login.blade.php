<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="color-scheme" content="light dark">
    <title>SIPAMAS - Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Plus Jakarta Sans', 'Inter', 'system-ui', 'sans-serif'] },
                }
            }
        };
    </script>
    <script>
        (function () {
            var storedTheme = null;
            try {
                storedTheme = localStorage.getItem('sipamas-theme');
            } catch (error) {
                storedTheme = null;
            }

            var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
            var useDark = storedTheme ? storedTheme === 'dark' : prefersDark;
            document.documentElement.classList.toggle('dark', useDark);
        })();
    </script>
    <style>
        .dark body {
            background: linear-gradient(135deg, #020617 0%, #0f172a 48%, #111827 100%);
            color: #e2e8f0;
        }
        .dark .bg-gray-50,
        .dark .bg-white {
            background-color: #0f172a !important;
        }
        .dark .border-gray-100,
        .dark .border-gray-200,
        .dark .border-gray-300 {
            border-color: rgba(148, 163, 184, 0.22) !important;
        }
        .dark .text-gray-900 {
            color: #f8fafc !important;
        }
        .dark .text-gray-800,
        .dark .text-gray-700 {
            color: #cbd5e1 !important;
        }
        .dark .text-gray-600,
        .dark .text-gray-500,
        .dark .text-gray-400 {
            color: #94a3b8 !important;
        }
        .dark input {
            background: #020617 !important;
            color: #e2e8f0 !important;
        }
        .dark input::placeholder {
            color: #64748b !important;
        }
        .dark #panel-guest > div,
        .dark #panel-login .grid,
        .dark .rounded-2xl.shadow-xl {
            box-shadow: 0 18px 34px rgba(2, 6, 23, 0.45) !important;
        }
        .dark #panel-guest > div {
            background: rgba(30, 64, 175, 0.18) !important;
            border-color: rgba(96, 165, 250, 0.28) !important;
        }
    </style>
</head>
<body class="min-h-screen flex bg-gray-50 font-sans text-gray-900">
    {{-- Left hero --}}
    <div class="hidden lg:flex lg:w-1/2 relative overflow-hidden bg-gradient-to-br from-emerald-600 to-teal-700">
        <img src="https://images.unsplash.com/photo-1760876037623-86ec37f6595b?auto=format&fit=crop&w=1500&q=80"
             alt="Environmental Background"
             class="absolute inset-0 w-full h-full object-cover opacity-30">
        <div class="relative z-10 flex flex-col justify-start px-12 pt-16 pb-12 text-white backdrop-blur-[1px]">
            <div class="flex items-center gap-3 mb-6">
                <div class="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center">
                    <i data-lucide="leaf" class="w-10 h-10"></i>
                </div>
                <div>
                    <div class="text-sm font-medium opacity-90">PORTAL DINAS LINGKUNGAN</div>
                    <div class="text-3xl font-bold">SIPAMAS</div>
                </div>
            </div>
            <h1 class="text-4xl font-bold mb-4 leading-tight">Sistem Pengaduan Lingkungan Hidup Masyarakat</h1>
            <p class="text-lg opacity-90 leading-relaxed">
                Kelola pengaduan lingkungan hidup masyarakat secara cepat, transparan, dan terdokumentasi.
            </p>
        </div>
    </div>

    {{-- Right column --}}
    <div class="flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-12">
        <div class="w-full max-w-md">
            {{-- Mobile header --}}
            <div class="lg:hidden mb-6 text-center">
                <div class="inline-flex items-center gap-2 mb-2">
                    <div class="w-10 h-10 bg-gradient-to-br from-emerald-600 to-teal-700 rounded-xl flex items-center justify-center">
                        <i data-lucide="leaf" class="w-6 h-6 text-white"></i>
                    </div>
                </div>
                <div class="text-xs text-emerald-700 font-semibold mb-1">PORTAL DINAS LINGKUNGAN</div>
                <div class="text-xl font-bold text-gray-900">SIPAMAS</div>
                <p class="text-xs text-gray-600 mt-1">Sistem Pengaduan Lingkungan Hidup Masyarakat</p>
            </div>

            <div class="bg-white rounded-2xl shadow-xl p-5 sm:p-8 border border-gray-100">
                <div class="mb-5">
                    <div class="inline-block px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-xs font-semibold mb-3">
                        PORTAL RESMI PENGADUAN
                    </div>
                    <h2 class="text-xl sm:text-2xl font-bold text-gray-900 mb-2">Masuk ke SIPAMAS</h2>
                    <p class="text-sm text-gray-600">Pilih cara masuk yang sesuai dengan kebutuhan Anda</p>
                </div>

                {{-- Tabs --}}
                <div>
                    <div class="grid grid-cols-2 mb-6 rounded-xl border border-gray-200 overflow-hidden text-sm font-semibold">
                        <button id="tab-login" type="button" class="py-2 bg-emerald-50 text-emerald-700">Login</button>
                        <button id="tab-guest" type="button" class="py-2 text-gray-500 hover:text-emerald-700">Guest</button>
                    </div>

                    {{-- Login form --}}
                    <div id="panel-login" class="space-y-4">
                        <form method="POST" action="{{ route('login') }}" class="space-y-4">
                            @csrf
                            <div class="space-y-2">
                                <label for="email" class="text-sm font-medium text-gray-700">Email</label>
                                <div class="relative">
                                    <i data-lucide="mail" class="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"></i>
                                    <input
                                        id="email"
                                        name="email"
                                        type="email"
                                        value="{{ old('email') }}"
                                        class="pl-10 h-11 w-full rounded-lg border border-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 transition"
                                        placeholder="nama@email.com"
                                        required
                                        autofocus>
                                    @error('email') <div class="text-rose-500 text-xs mt-1">{{ $message }}</div> @enderror
                                </div>
                            </div>

                            <div class="space-y-2">
                                <label for="password" class="text-sm font-medium text-gray-700">Password</label>
                                <div class="relative">
                                    <i data-lucide="lock" class="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"></i>
                                    <input
                                        id="password"
                                        name="password"
                                        type="password"
                                        class="pl-10 pr-10 h-11 w-full rounded-lg border border-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 transition"
                                        placeholder="••••••••"
                                        required
                                        autocomplete="current-password">
                                    <button type="button" id="pw-toggle" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                                        <i data-lucide="eye" class="w-5 h-5"></i>
                                    </button>
                                    @error('password') <div class="text-rose-500 text-xs mt-1">{{ $message }}</div> @enderror
                                </div>
                            </div>

                            <div class="flex items-center justify-between">
                                <label class="flex items-center gap-2 text-sm text-gray-600 cursor-pointer select-none">
                                    <input type="checkbox" name="remember" class="w-4 h-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500"
                                        {{ old('remember') ? 'checked' : '' }}>
                                    <span>Remember me</span>
                                </label>
                                <a href="{{ route('password.request') }}" class="text-sm font-medium text-emerald-600 hover:text-emerald-700">Lupa password?</a>
                            </div>

                            <button type="submit" class="w-full h-11 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-semibold hover:from-emerald-700 hover:to-teal-700 transition">
                                LOG IN
                            </button>

                            <a href="{{ route('auth.google.redirect') }}"
                               class="w-full h-11 rounded-lg border border-gray-200 text-gray-800 font-semibold hover:border-emerald-300 hover:bg-emerald-50 transition flex items-center justify-center gap-2">
                                <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" class="w-5 h-5">
                                    <path fill="#4285F4" d="M23.49 12.27c0-.79-.07-1.54-.2-2.27H12v4.3h6.46a5.52 5.52 0 0 1-2.4 3.62v3h3.88c2.27-2.09 3.55-5.17 3.55-8.65z"/>
                                    <path fill="#34A853" d="M12 24c3.24 0 5.95-1.07 7.93-2.91l-3.88-3c-1.08.72-2.47 1.15-4.05 1.15-3.12 0-5.76-2.1-6.71-4.93H1.28v3.09A12 12 0 0 0 12 24z"/>
                                    <path fill="#FBBC05" d="M5.29 14.31A7.2 7.2 0 0 1 4.91 12c0-.8.14-1.58.38-2.31V6.6H1.28A12 12 0 0 0 0 12c0 1.94.46 3.77 1.28 5.4l4.01-3.09z"/>
                                    <path fill="#EA4335" d="M12 4.77c1.76 0 3.35.61 4.59 1.8l3.44-3.44C17.94 1.18 15.24 0 12 0A12 12 0 0 0 1.28 6.6l4.01 3.09c.95-2.83 3.59-4.92 6.71-4.92z"/>
                                </svg>
                                Masuk dengan Google
                            </a>

                            <div class="text-center text-sm text-gray-600">
                                Belum punya akun?
                                <a href="{{ route('register') }}" class="font-medium text-emerald-600 hover:text-emerald-700">Daftar di sini</a>
                            </div>
                        </form>
                    </div>

                    {{-- Guest form --}}
                    <div id="panel-guest" class="space-y-4 hidden">
                        <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                            <p class="text-sm text-blue-800">
                                Akun guest akan dibuat otomatis dan memiliki akses seperti user biasa.
                            </p>
                        </div>

                        <form method="POST" action="{{ route('guest.login') }}" class="space-y-4">
                            @csrf
                            <div class="space-y-2">
                                <label for="guest_name" class="text-sm font-medium text-gray-700">
                                    Nama <span class="text-gray-400 font-normal">(opsional)</span>
                                </label>
                                <div class="relative">
                                    <i data-lucide="user" class="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"></i>
                                    <input
                                        id="guest_name"
                                        name="guest_name"
                                        type="text"
                                        value="{{ old('guest_name') }}"
                                        class="pl-10 h-11 w-full rounded-lg border border-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 transition"
                                        placeholder="Nama lengkap Anda">
                                </div>
                            </div>

                            <div class="space-y-2">
                                <label for="guest_whatsapp" class="text-sm font-medium text-gray-700">
                                    Nomor WhatsApp
                                </label>
                                <div class="relative">
                                    <i data-lucide="message-circle" class="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"></i>
                                    <input
                                        id="guest_whatsapp"
                                        name="guest_whatsapp"
                                        type="tel"
                                        value="{{ old('guest_whatsapp') }}"
                                        class="pl-10 h-11 w-full rounded-lg border border-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 transition"
                                        placeholder="081234567890 / 6281234567890"
                                        required>
                                    @error('guest_whatsapp') <div class="text-rose-500 text-xs mt-1">{{ $message }}</div> @enderror
                                </div>
                            </div>

                            <button type="submit" class="w-full h-11 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-semibold hover:from-emerald-700 hover:to-teal-700 transition">
                                MASUK SEBAGAI GUEST VIA WHATSAPP
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <p class="text-center text-xs text-gray-500 mt-6">© {{ date('Y') }} Dinas Lingkungan. Semua hak dilindungi.</p>
        </div>
    </div>

    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
        const loginBtn = document.getElementById('tab-login');
        const guestBtn = document.getElementById('tab-guest');
        const panelLogin = document.getElementById('panel-login');
        const panelGuest = document.getElementById('panel-guest');
        function activate(tab) {
            const isLogin = tab === 'login';
            loginBtn.className = `py-2 ${isLogin ? 'bg-emerald-50 text-emerald-700' : 'text-gray-500 hover:text-emerald-700'}`;
            guestBtn.className = `py-2 ${!isLogin ? 'bg-emerald-50 text-emerald-700' : 'text-gray-500 hover:text-emerald-700'}`;
            panelLogin.classList.toggle('hidden', !isLogin);
            panelGuest.classList.toggle('hidden', isLogin);
        }
        loginBtn?.addEventListener('click', () => activate('login'));
        guestBtn?.addEventListener('click', () => activate('guest'));

        const pwToggle = document.getElementById('pw-toggle');
        const pwInput = document.getElementById('password');
        pwToggle?.addEventListener('click', () => {
            const showing = pwInput.type === 'text';
            pwInput.type = showing ? 'password' : 'text';
            pwToggle.innerHTML = '';
            const icon = document.createElement('i');
            icon.setAttribute('data-lucide', showing ? 'eye' : 'eye-off');
            icon.className = 'w-5 h-5';
            pwToggle.appendChild(icon);
            window.lucide.createIcons();
        });

        window.addEventListener('DOMContentLoaded', () => {
            window.lucide.createIcons();
            // Open guest tab if validation errors from guest form
            const hasGuestError = {{ ($errors->has('guest_whatsapp') || $errors->has('guest_name')) ? 'true' : 'false' }};
            if (hasGuestError) activate('guest');
        });
    </script>
</body>
</html>
