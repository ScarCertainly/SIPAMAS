<?php

namespace App\Support;

use Illuminate\Contracts\Auth\Authenticatable;

class AuthRedirect
{
    public static function pathFor(?Authenticatable $user): string
    {
        if (($user->role ?? null) === 'admin') {
            return '/dashboard';
        }

        return '/complaints';
    }
}
