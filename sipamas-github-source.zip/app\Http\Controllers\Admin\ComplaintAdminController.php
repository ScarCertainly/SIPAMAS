<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Complaint;
use App\Models\ComplaintComment;
use App\Models\ComplaintStatusHistory;
use App\Notifications\AdminCommentedComplaint;
use App\Support\PublicImageUpload;
use App\Support\PublicUploadedMedia;
use Illuminate\Http\Request;

class ComplaintAdminController extends Controller
{
    private function applyFilters(Request $request, $query)
    {
        if ($request->filled('q')) {
            $keyword = trim((string) $request->q);
            $query->where(function ($builder) use ($keyword) {
                $builder->where('title', 'like', '%' . $keyword . '%')
                    ->orWhere('description', 'like', '%' . $keyword . '%')
                    ->orWhereHas('user', function ($userQuery) use ($keyword) {
                        $userQuery->where('name', 'like', '%' . $keyword . '%')
                            ->orWhere('email', 'like', '%' . $keyword . '%');
                    });
            });
        }

        if ($request->filled('status')) {
            if ($request->status === 'process') {
                $query->whereIn('status', ['process', 'approved']);
            } else {
                $query->where('status', $request->status);
            }
        }

        if ($request->filled('category_id')) {
            $query->where('category_id', $request->category_id);
        }

        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        return $query;
    }

    public function index(Request $request)
    {
        $query = Complaint::with(['user', 'category']);
        $this->applyFilters($request, $query);

        $complaints = $query->latest()->paginate(12)->withQueryString();
        $categories = Category::orderBy('name')->get();
        $mapQuery = Complaint::query()
            ->select([
                'id',
                'title',
                'status',
                'latitude',
                'longitude',
                'street_address',
                'village',
                'district',
                'city',
                'province',
            ])
            ->whereIn('status', ['pending', 'process', 'approved'])
            ->whereNotNull('latitude')
            ->whereNotNull('longitude');

        $this->applyFilters($request, $mapQuery);

        $activeComplaintLocations = $mapQuery->latest()->get();

        return view('admin.complaints.index', compact('complaints', 'categories', 'activeComplaintLocations'));
    }

    public function show(Complaint $complaint)
    {
        $complaint->load(['user', 'category', 'adminResponder', 'comments.admin', 'comments.user', 'statusHistories.admin']);

        return view('admin.complaints.show', compact('complaint'));
    }

    public function edit(Complaint $complaint)
    {
        $complaint->load(['user', 'category', 'adminResponder', 'comments.admin', 'comments.user', 'statusHistories.admin']);

        return view('admin.complaints.edit', compact('complaint'));
    }

    public function update(Request $request, Complaint $complaint)
    {
        $validated = $request->validate([
            'status' => 'required|in:pending,process,rejected,done',
            'admin_comment' => 'nullable|string|max:2000',
            'admin_response_message' => 'nullable|string|max:3000',
            'admin_action_taken' => 'nullable|string|max:2000',
            'admin_response_image' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:3072',
            'allow_user_chat' => 'nullable|boolean',
            'remove_admin_response_image' => 'nullable|boolean',
        ]);

        $oldStatus = $complaint->status;
        $responseImagePath = $complaint->admin_response_image;
        $removeResponseImage = (bool) ($validated['remove_admin_response_image'] ?? false);

        if ($request->hasFile('admin_response_image')) {
            $responseImagePath = $this->storeAdminResponseImage($request->file('admin_response_image'));

            if ($complaint->admin_response_image) {
                $this->deleteStoredImage($complaint->admin_response_image);
            }
        } elseif ($removeResponseImage) {
            if ($complaint->admin_response_image) {
                $this->deleteStoredImage($complaint->admin_response_image);
            }

            $responseImagePath = null;
        }

        $hasStructuredResponse = filled($validated['admin_response_message'] ?? null)
            || filled($validated['admin_action_taken'] ?? null)
            || !empty($responseImagePath);

        $complaint->update([
            'status' => $validated['status'],
            'admin_response_message' => $validated['admin_response_message'] ?? null,
            'admin_action_taken' => $validated['admin_action_taken'] ?? null,
            'admin_response_image' => $responseImagePath,
            'admin_responded_by' => $hasStructuredResponse ? auth()->id() : null,
            'admin_responded_at' => $hasStructuredResponse ? now() : null,
            'allow_user_chat' => (bool) ($validated['allow_user_chat'] ?? false),
        ]);

        if ($oldStatus !== $validated['status']) {
            ComplaintStatusHistory::create([
                'complaint_id' => $complaint->id,
                'admin_id' => auth()->id(),
                'old_status' => $oldStatus,
                'new_status' => $validated['status'],
                'note' => $validated['admin_comment'] ?? null,
            ]);
        }

        if (!empty($validated['admin_comment'])) {
            $comment = ComplaintComment::create([
                'complaint_id' => $complaint->id,
                'admin_id' => auth()->id(),
                'comment' => $validated['admin_comment'],
            ]);

            $comment->load('admin');
            $complaint->user->notify(new AdminCommentedComplaint($complaint, $comment));
        }

        return redirect()->route('dashboard', ['section' => 'pengaduan']);
    }

    private function storeAdminResponseImage($file): string
    {
        return PublicImageUpload::store($file, 'admin-responses', 'admin_response');
    }

    private function deleteStoredImage(?string $path): void
    {
        PublicUploadedMedia::delete($path);
    }

    public function exportCsv(Request $request)
    {
        $query = Complaint::with(['user', 'category']);
        $this->applyFilters($request, $query);
        $complaints = $query->latest()->get();

        $filename = 'laporan-pengaduan-' . now()->format('Ymd_His') . '.csv';

        return response()->streamDownload(function () use ($complaints) {
            $handle = fopen('php://output', 'w');
            fwrite($handle, "\xEF\xBB\xBF");

            fputcsv($handle, ['No', 'Pelapor', 'Email', 'Judul', 'Kategori', 'Status', 'Tanggal']);

            $statusLabels = [
                'pending' => 'Pending',
                'process' => 'In Process',
                'approved' => 'In Process',
                'rejected' => 'Ditolak',
                'done' => 'Selesai',
            ];

            foreach ($complaints as $index => $complaint) {
                fputcsv($handle, [
                    $index + 1,
                    $complaint->user->name ?? '-',
                    $complaint->user->email ?? '-',
                    $complaint->title,
                    $complaint->category->name ?? '-',
                    $statusLabels[$complaint->status] ?? $complaint->status,
                    optional($complaint->created_at)->format('Y-m-d H:i:s'),
                ]);
            }

            fclose($handle);
        }, $filename, [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }
}
