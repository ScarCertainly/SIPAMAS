<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasColumn('complaints', 'image_evidence')) {
            Schema::table('complaints', function (Blueprint $table) {
                $table->string('image_evidence')->nullable()->after('description');
            });
        }

        if (Schema::hasColumn('complaints', 'photo')) {
            DB::statement("UPDATE complaints SET image_evidence = photo WHERE image_evidence IS NULL AND photo IS NOT NULL");
            Schema::table('complaints', function (Blueprint $table) {
                $table->dropColumn('photo');
            });
        }
    }

    public function down(): void
    {
        if (!Schema::hasColumn('complaints', 'photo')) {
            Schema::table('complaints', function (Blueprint $table) {
                $table->string('photo')->nullable()->after('description');
            });
        }

        if (Schema::hasColumn('complaints', 'image_evidence')) {
            DB::statement("UPDATE complaints SET photo = image_evidence WHERE photo IS NULL AND image_evidence IS NOT NULL");
            Schema::table('complaints', function (Blueprint $table) {
                $table->dropColumn('image_evidence');
            });
        }
    }
};
