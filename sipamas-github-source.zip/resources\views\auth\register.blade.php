<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>SIPAMAS - Daftar</title>
    @vite(['resources/css/app.css', 'resources/js/app.jsx'])
    <style>
        :root {
            --glass-bg: rgba(9, 20, 40, 0.55);
            --glass-stroke: rgba(255, 255, 255, 0.12);
            --accent: #22d3ee;
            --accent-2: #a78bfa;
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            font-family: "DM Sans", "Inter", -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            color: #e2e8f0;
            min-height: 100vh;
            background: #020617;
        }
        .bg-video {
            position: fixed;
            inset: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            filter: saturate(1.05) contrast(1.05) brightness(0.82);
            z-index: -2;
        }
        .bg-overlay {
            position: fixed;
            inset: 0;
            background: radial-gradient(circle at 20% 20%, rgba(34, 211, 238, 0.28), transparent 30%),
                        radial-gradient(circle at 80% 10%, rgba(167, 139, 250, 0.25), transparent 32%),
                        linear-gradient(145deg, rgba(2, 6, 23, 0.75), rgba(2, 6, 23, 0.45));
            z-index: -1;
        }
        .top-nav {
            position: fixed;
            inset: 0 0 auto 0;
            z-index: 50;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            padding: 0.9rem clamp(1rem, 4vw, 2.25rem);
            background: linear-gradient(90deg, rgba(2, 6, 23, 0.8), rgba(4, 12, 30, 0.6));
            border-bottom: 1px solid rgba(255, 255, 255, 0.06);
            backdrop-filter: blur(12px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.25);
        }
        .brand {
            display: inline-flex;
            align-items: center;
            gap: 0.75rem;
            text-decoration: none;
            color: #e2e8f0;
        }
        .brand-mark {
            width: 38px;
            height: 38px;
            border-radius: 12px;
            background: linear-gradient(135deg, #22d3ee, #a78bfa);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            color: #0b172a;
            letter-spacing: -0.02em;
        }
        .brand-text { display: grid; gap: 2px; line-height: 1.1; }
        .brand-title { font-weight: 800; letter-spacing: -0.02em; }
        .brand-sub { font-size: 0.85rem; color: rgba(226, 232, 240, 0.75); }
        .nav-links {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            flex-wrap: wrap;
        }
        .nav-link {
            color: #e2e8f0;
            text-decoration: none;
            font-weight: 700;
            padding: 0.45rem 0.8rem;
            border-radius: 12px;
            border: 1px solid transparent;
            transition: all 0.18s ease;
        }
        .nav-link:hover {
            border-color: rgba(34, 211, 238, 0.55);
            background: rgba(34, 211, 238, 0.12);
        }
        .nav-cta {
            border-color: rgba(167, 139, 250, 0.55);
            background: rgba(167, 139, 250, 0.12);
        }
        .page-shell {
            display: grid;
            place-items: center;
            padding: clamp(1rem, 3vw, 2rem);
            min-height: 100vh;
        }
        .auth-card {
            width: min(960px, 100%);
            border-radius: 26px;
            padding: clamp(1.4rem, 3vw, 2.2rem);
            background: var(--glass-bg);
            border: 1px solid var(--glass-stroke);
            box-shadow:
                0 24px 70px rgba(0, 0, 0, 0.45),
                inset 0 1px 0 rgba(255, 255, 255, 0.06);
            backdrop-filter: blur(16px);
        }
        .auth-grid {
            display: grid;
            gap: clamp(1rem, 3vw, 2rem);
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            align-items: start;
        }
        .hero-copy { display: grid; gap: 0.9rem; }
        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.35rem 0.9rem;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid var(--glass-stroke);
            font-weight: 700;
            letter-spacing: 0.04em;
            text-transform: uppercase;
            font-size: 0.8rem;
        }
        .hero-title {
            font-family: "Playfair Display", serif;
            font-size: clamp(1.9rem, 4vw, 2.8rem);
            margin: 0;
            color: #f8fafc;
        }
        .hero-subtitle {
            margin: 0;
            color: rgba(226, 232, 240, 0.8);
            line-height: 1.6;
        }
        .stat-row { display: flex; gap: 1rem; flex-wrap: wrap; }
        .stat-chip {
            padding: 0.65rem 0.9rem;
            border-radius: 14px;
            background: rgba(15, 23, 42, 0.5);
            border: 1px solid var(--glass-stroke);
            font-weight: 700;
            color: #cbd5e1;
        }
        .form-card {
            background: rgba(2, 6, 23, 0.65);
            border-radius: 18px;
            border: 1px solid rgba(255, 255, 255, 0.08);
            padding: 1.1rem;
        }
        label {
            display: block;
            font-weight: 700;
            margin-bottom: 0.35rem;
            color: #e2e8f0;
        }
        .form-input {
            width: 100%;
            border-radius: 12px;
            border: 1px solid rgba(148, 163, 184, 0.35);
            background: rgba(15, 23, 42, 0.7);
            color: #e2e8f0;
            padding: 0.75rem 0.9rem;
            transition: border 0.2s ease, box-shadow 0.2s ease;
        }
        .form-input:focus {
            outline: none;
            border-color: rgba(34, 211, 238, 0.6);
            box-shadow: 0 0 0 3px rgba(34, 211, 238, 0.2);
        }
        .btn-primary {
            width: 100%;
            border: 0;
            border-radius: 12px;
            padding: 0.85rem 1rem;
            font-weight: 800;
            letter-spacing: 0.01em;
            color: #0b172a;
            background: linear-gradient(135deg, #22d3ee, #a78bfa);
            box-shadow: 0 16px 32px rgba(34, 211, 238, 0.25);
            cursor: pointer;
        }
        .helper {
            margin-top: 0.8rem;
            color: rgba(226, 232, 240, 0.75);
            font-size: 0.9rem;
        }
        .invalid-feedback {
            color: #fca5a5;
            font-size: 0.85rem;
            margin-top: 0.35rem;
        }
        @media (max-width: 640px) { .auth-card { padding: 1.1rem; } }
    </style>
</head>
<body>
    <video class="bg-video" autoplay muted loop playsinline poster="https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1600&q=80">
        <source src="https://cdn.coverr.co/videos/coverr-sunrise-in-the-forest-1570/1080p.mp4" type="video/mp4">
        <source src="https://cdn.coverr.co/videos/coverr-sunrise-in-the-forest-1570/720p.mp4" type="video/mp4">
    </video>
    <div class="bg-overlay"></div>

    <nav class="top-nav">
        <a href="{{ url('/') }}" class="brand">
            <span class="brand-mark">E</span>
            <span class="brand-text">
                <span class="brand-title">SIPAMAS</span>
                <span class="brand-sub">Sistem Pengaduan Masyarakat</span>
            </span>
        </a>
        <div class="nav-links">
            <a class="nav-link" href="{{ url('/') }}">Beranda</a>
            <a class="nav-link" href="#testimoni">Testimoni</a>
            <a class="nav-link" href="#galeri">Pameran</a>
            <a class="nav-link nav-cta" href="{{ route('login') }}">Login</a>
        </div>
    </nav>

    <div class="page-shell">
        <div class="auth-card">
            <div class="auth-grid">
                <div class="hero-copy">
                    <span class="eyebrow">SIPAMAS • Daftar</span>
                    <h1 class="hero-title">Buat akun untuk melaporkan dan memantau lingkungan.</h1>
                    <p class="hero-subtitle">
                        Registrasi cepat untuk mengirim pengaduan, unggah bukti foto, dan terima update status lewat dashboard serta notifikasi.
                    </p>
                    <div class="stat-row">
                        <span class="stat-chip">Validasi WhatsApp</span>
                        <span class="stat-chip">Unggah bukti pencemaran</span>
                        <span class="stat-chip">Tracking status real-time</span>
                    </div>
                </div>

                <div class="form-card">
                    <form method="POST" action="{{ route('register') }}">
                        @csrf
                        <div class="mb-3">
                            <label for="name">Nama Lengkap</label>
                            <input id="name" name="name" type="text" class="form-input @error('name') is-invalid @enderror" value="{{ old('name') }}" required autofocus autocomplete="name">
                            @if($errors->has('name'))
                                <div class="invalid-feedback">{{ $errors->first('name') }}</div>
                            @endif
                        </div>
                        <div class="mb-3">
                            <label for="email">Email</label>
                            <input id="email" name="email" type="email" class="form-input @error('email') is-invalid @enderror" value="{{ old('email') }}" required autocomplete="username">
                            @if($errors->has('email'))
                                <div class="invalid-feedback">{{ $errors->first('email') }}</div>
                            @endif
                        </div>
                        <div class="mb-3">
                            <label for="whatsapp_number">No. WhatsApp</label>
                            <input id="whatsapp_number" name="whatsapp_number" type="text" class="form-input @error('whatsapp_number') is-invalid @enderror" placeholder="62812xxxxxx" value="{{ old('whatsapp_number') }}" required autocomplete="tel">
                            @if($errors->has('whatsapp_number'))
                                <div class="invalid-feedback">{{ $errors->first('whatsapp_number') }}</div>
                            @endif
                        </div>
                        <div class="mb-3">
                            <label for="password">Password</label>
                            <input id="password" name="password" type="password" class="form-input @error('password') is-invalid @enderror" placeholder="Minimal 8 karakter" required autocomplete="new-password">
                            @if($errors->has('password'))
                                <div class="invalid-feedback">{{ $errors->first('password') }}</div>
                            @endif
                        </div>
                        <div class="mb-3">
                            <label for="password_confirmation">Konfirmasi Password</label>
                            <input id="password_confirmation" name="password_confirmation" type="password" class="form-input @error('password_confirmation') is-invalid @enderror" placeholder="Ulangi password" required autocomplete="new-password">
                            @if($errors->has('password_confirmation'))
                                <div class="invalid-feedback">{{ $errors->first('password_confirmation') }}</div>
                            @endif
                        </div>
                        <button type="submit" class="btn-primary">Daftar</button>
                        <div class="helper">
                            Sudah punya akun? <a href="{{ route('login') }}" style="color: var(--accent); font-weight: 700;">Login</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
