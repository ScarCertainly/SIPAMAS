<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class UserMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        // Izinkan user dan admin
        if (!auth()->check() || !in_array(auth()->user()->role, ['user', 'admin'], true)) {
            abort(403, 'Unauthorized access');
        }

        return $next($request);
    }
}
