import React from 'react';
import { Navbar } from './components/Navbar';
import { LoginPage } from './components/LoginPage';
import { FeaturesSection } from './components/FeaturesSection';
import { TestimoniSection } from './components/TestimoniSection';
import { PameranSection } from './components/PameranSection';

export default function AppContent() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <div className="pt-16">
        <LoginPage />
        <FeaturesSection />
        <TestimoniSection />
        <PameranSection />
      </div>
    </div>
  );
}
