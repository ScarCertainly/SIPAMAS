<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Category;

class CategorySeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            'Sampah & Limbah Rumah Tangga',
            'Pencemaran Air (Sungai/Drainase)',
            'Pencemaran Udara & Asap',
            'Ruang Terbuka Hijau & Penebangan Pohon',
            'Sanitasi & Kebersihan Lingkungan',
            'Banjir Akibat Lingkungan',
            'Limbah B3 / Industri',
            'Edukasi & Program Lingkungan',
        ];

        foreach ($categories as $name) {
            Category::firstOrCreate(['name' => $name]);
        }
    }
}
