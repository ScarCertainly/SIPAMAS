<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement("UPDATE complaints SET status = 'process' WHERE status = 'approved'");
        DB::statement("ALTER TABLE complaints MODIFY COLUMN status ENUM('pending','process','rejected','done') NOT NULL DEFAULT 'pending'");
    }

    public function down(): void
    {
        DB::statement("ALTER TABLE complaints MODIFY COLUMN status ENUM('pending','process','approved','rejected','done') NOT NULL DEFAULT 'pending'");
    }
};
