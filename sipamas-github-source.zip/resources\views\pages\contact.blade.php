@extends('layouts.app')

@section('title', 'Kontak SIPAMAS')

@push('styles')
<style>
    .sipamas-hero {
        text-align: center;
        margin-bottom: 2rem;
    }
    .sipamas-hero h2 {
        font-size: clamp(2rem, 3.2vw, 2.8rem);
        font-weight: 800;
        color: #0f172a;
        margin-bottom: 0.5rem;
    }
    .sipamas-hero p {
        color: #64748b;
        max-width: 720px;
        margin: 0 auto;
        font-size: 1.05rem;
    }
    .contact-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
        gap: 24px;
    }
    .contact-card {
        background: #ffffff;
        border: 1px solid rgba(148, 163, 184, 0.2);
        border-radius: 18px;
        padding: 22px;
        box-shadow: 0 12px 26px rgba(15, 23, 42, 0.06);
    }
    .contact-item {
        display: flex;
        gap: 12px;
        margin-bottom: 16px;
    }
    .contact-icon {
        width: 42px;
        height: 42px;
        border-radius: 12px;
        background: #ecfeff;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        color: #0f766e;
        flex: 0 0 auto;
        font-weight: 700;
    }
    .contact-hours {
        background: #f1f5f9;
        border-radius: 14px;
        padding: 14px;
        color: #475569;
    }
    .contact-form .form-control,
    .contact-form .form-select {
        margin-top: 6px;
    }
    body.app-theme-dark .sipamas-hero h2 {
        color: #f8fafc;
    }
    body.app-theme-dark .sipamas-hero p {
        color: #cbd5e1;
    }
    body.app-theme-dark .contact-card {
        background: linear-gradient(180deg, rgba(15, 23, 42, 0.96) 0%, rgba(17, 24, 39, 0.96) 100%);
        border-color: rgba(148, 163, 184, 0.24);
        color: #e2e8f0;
    }
    body.app-theme-dark .contact-card h4,
    body.app-theme-dark .contact-card .fw-semibold,
    body.app-theme-dark .contact-card .form-label {
        color: #f8fafc;
    }
    body.app-theme-dark .alert-success {
        background: rgba(20, 83, 45, 0.3);
        border-color: rgba(74, 222, 128, 0.28);
        color: #dcfce7;
    }
    body.app-theme-dark .contact-icon {
        background: rgba(15, 118, 110, 0.16);
        color: #5eead4;
    }
    body.app-theme-dark .contact-hours {
        background: rgba(15, 23, 42, 0.72);
        border: 1px solid rgba(45, 212, 191, 0.18);
        color: #cbd5e1;
    }
    body.app-theme-dark .contact-form .form-control,
    body.app-theme-dark .contact-form .form-select {
        background: rgba(15, 23, 42, 0.78);
        border-color: rgba(45, 212, 191, 0.22);
        color: #e2e8f0;
    }
    body.app-theme-dark .contact-form .form-control.is-invalid,
    body.app-theme-dark .contact-form .form-select.is-invalid {
        border-color: rgba(248, 113, 113, 0.56);
    }
    body.app-theme-dark .contact-form .form-control::placeholder {
        color: #94a3b8;
    }
    body.app-theme-dark .contact-form .form-control:focus,
    body.app-theme-dark .contact-form .form-select:focus {
        border-color: rgba(45, 212, 191, 0.42);
        box-shadow: 0 0 0 0.2rem rgba(20, 184, 166, 0.16);
    }
</style>
@endpush

@section('content')
<div class="app-card p-4 p-md-5">
    <div class="sipamas-hero">
        <h2>Hubungi SIPAMAS</h2>
        <p>Ada pertanyaan atau kendala? Tim SIPAMAS siap membantu.</p>
    </div>

    @if(session('status') === 'contact-message-sent')
        <div class="alert alert-success mb-4">
            Pesan Anda sudah dikirim ke SIPAMAS dan masuk ke notifikasi admin.
        </div>
    @endif

    <div class="contact-grid">
        <div class="contact-card">
            <h4 class="mb-3">Informasi Kontak</h4>
            <p class="text-muted mb-4">
                Hubungi kami melalui saluran berikut atau kirim pesan lewat formulir.
            </p>

            <div class="contact-item">
                <div class="contact-icon">✉️</div>
                <div>
                    <div class="fw-semibold">Email</div>
                    <div class="text-muted">info@ecovoice.local</div>
                    <div class="text-muted">support@ecovoice.local</div>
                </div>
            </div>

            <div class="contact-item">
                <div class="contact-icon">📞</div>
                <div>
                    <div class="fw-semibold">Telepon</div>
                    <div class="text-muted">(021) 1234-5678</div>
                    <div class="text-muted">+62 811 8888 9999</div>
                </div>
            </div>

            <div class="contact-item">
                <div class="contact-icon">📍</div>
                <div>
                    <div class="fw-semibold">Alamat</div>
                    <div class="text-muted">Dinas Lingkungan, Jl. Merdeka No. 45, Jakarta</div>
                </div>
            </div>

            <div class="contact-hours">
                <div class="fw-semibold mb-1">Jam Layanan</div>
                <div>Senin - Kamis: 08:00 - 16:00 WIB</div>
                <div>Jumat: 08:00 - 15:30 WIB</div>
                <div>Sabtu - Minggu: Libur</div>
            </div>
        </div>

        <div class="contact-card contact-form">
            <h4 class="mb-3">Kirim Pesan</h4>
            <form method="POST" action="{{ route('contact.submit') }}">
                @csrf
                <div class="mb-3">
                    <label class="form-label">Nama Lengkap</label>
                    <input
                        type="text"
                        name="name"
                        class="form-control @error('name') is-invalid @enderror"
                        placeholder="Masukkan nama Anda"
                        value="{{ old('name', auth()->user()->name ?? '') }}"
                        required>
                    @error('name')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input
                        type="email"
                        name="email"
                        class="form-control @error('email') is-invalid @enderror"
                        placeholder="nama@email.com"
                        value="{{ old('email', auth()->user()->email ?? '') }}"
                        required>
                    @error('email')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                <div class="mb-3">
                    <label class="form-label">Pesan</label>
                    <textarea
                        name="message"
                        class="form-control @error('message') is-invalid @enderror"
                        rows="5"
                        placeholder="Tulis pesan Anda di sini..."
                        required>{{ old('message') }}</textarea>
                    @error('message')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                <button type="submit" class="btn btn-primary w-100">Kirim Pesan</button>
            </form>
        </div>
    </div>
</div>
@endsection
