@extends('layouts.app')

@section('title', 'Detail Pengaduan')

@push('styles')
<style>
    .admin-complaint-shell {
        max-width: 1180px;
        margin: 0 auto;
    }
    .admin-complaint-hero {
        border: 1px solid rgba(15, 118, 110, 0.18);
        background: linear-gradient(135deg, rgba(15, 118, 110, 0.08) 0%, rgba(236, 253, 245, 0.96) 100%);
        border-radius: 18px;
        padding: 20px;
    }
    .admin-complaint-title {
        font-size: clamp(1.3rem, 2.8vw, 1.95rem);
        font-weight: 800;
        color: #0f3f42;
        margin-bottom: 4px;
    }
    .admin-complaint-card {
        border-radius: 22px;
        border: 1px solid rgba(15, 118, 110, 0.16);
        background: linear-gradient(180deg, rgba(255, 255, 255, 0.96) 0%, rgba(249, 253, 252, 0.96) 100%);
        box-shadow: 0 20px 35px rgba(15, 23, 42, 0.08);
        overflow: hidden;
    }
    .admin-complaint-body {
        padding: 24px;
    }
    .admin-complaint-label {
        font-size: 0.78rem;
        letter-spacing: 0.35px;
        text-transform: uppercase;
        font-weight: 800;
        color: #0f766e;
        margin-bottom: 8px;
    }
    .admin-photo-box,
    .admin-response-box,
    .admin-qr-box,
    .admin-location-box {
        border: 1px solid rgba(15, 118, 110, 0.16);
        border-radius: 18px;
        background: rgba(240, 253, 250, 0.58);
    }
    .admin-photo-box,
    .admin-response-photo {
        overflow: hidden;
        aspect-ratio: 4 / 3;
    }
    .admin-response-photo {
        border: 1px solid rgba(15, 118, 110, 0.16);
        border-radius: 18px;
        background: rgba(240, 253, 250, 0.58);
    }
    .admin-response-box,
    .admin-qr-box,
    .admin-location-box {
        padding: 18px;
    }
    .admin-summary-item + .admin-summary-item {
        margin-top: 16px;
        padding-top: 16px;
        position: relative;
    }
    .admin-summary-item + .admin-summary-item::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: min(100%, 220px);
        height: 1px;
        background: rgba(15, 118, 110, 0.12);
    }
    .admin-status-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 8px 12px;
        border-radius: 999px;
        font-size: 0.82rem;
        font-weight: 700;
    }
    .admin-status-badge.pending {
        background: #fef3c7;
        color: #92400e;
    }
    .admin-status-badge.process {
        background: #dbeafe;
        color: #1d4ed8;
    }
    .admin-status-badge.done {
        background: #dcfce7;
        color: #166534;
    }
    .admin-status-badge.rejected {
        background: #fee2e2;
        color: #b91c1c;
    }
    .admin-feed-item {
        display: flex;
    }
    .admin-feed-item.admin {
        justify-content: flex-start;
    }
    .admin-feed-item.user {
        justify-content: flex-end;
    }
    .admin-feed-item + .admin-feed-item {
        margin-top: 12px;
    }
    .admin-feed-card {
        border: 1px solid rgba(15, 118, 110, 0.12);
        border-radius: 16px;
        padding: 14px 16px;
        background: rgba(255, 255, 255, 0.72);
    }
    .admin-chat-bubble {
        border-radius: 16px;
        padding: 14px 16px;
        width: fit-content;
        max-width: min(100%, 680px);
    }
    .admin-chat-bubble.admin {
        background: rgba(15, 118, 110, 0.12);
        border: 1px solid rgba(15, 118, 110, 0.18);
    }
    .admin-chat-bubble.user {
        background: rgba(59, 130, 246, 0.1);
        border: 1px solid rgba(59, 130, 246, 0.18);
    }
    #complaint-qr {
        width: 180px;
        min-height: 180px;
        margin: 0 auto;
    }
    #complaint-qr img,
    #complaint-qr canvas {
        display: block;
        margin: 0 auto;
    }
    body.app-theme-dark .admin-complaint-hero {
        border-color: rgba(45, 212, 191, 0.24);
        background: linear-gradient(135deg, rgba(20, 184, 166, 0.12) 0%, rgba(15, 23, 42, 0.92) 100%);
    }
    body.app-theme-dark .admin-complaint-title {
        color: #ccfbf1;
    }
    body.app-theme-dark .admin-complaint-card {
        border-color: rgba(148, 163, 184, 0.28);
        background: linear-gradient(180deg, rgba(15, 23, 42, 0.96) 0%, rgba(17, 24, 39, 0.96) 100%);
        box-shadow: 0 24px 35px rgba(2, 6, 23, 0.45);
    }
    body.app-theme-dark .admin-complaint-label {
        color: #99f6e4;
    }
    body.app-theme-dark .admin-photo-box,
    body.app-theme-dark .admin-response-box,
    body.app-theme-dark .admin-response-photo,
    body.app-theme-dark .admin-qr-box,
    body.app-theme-dark .admin-location-box,
    body.app-theme-dark .admin-feed-card {
        border-color: rgba(45, 212, 191, 0.24);
        background: rgba(15, 60, 56, 0.16);
    }
    body.app-theme-dark .admin-summary-item + .admin-summary-item::before {
        background: rgba(148, 163, 184, 0.16);
    }
    body.app-theme-dark .admin-complaint-shell .fw-semibold,
    body.app-theme-dark .admin-complaint-shell h4,
    body.app-theme-dark .admin-complaint-shell p,
    body.app-theme-dark .admin-complaint-shell li,
    body.app-theme-dark .admin-complaint-shell div {
        color: #e2e8f0;
    }
    body.app-theme-dark .admin-complaint-shell .text-muted,
    body.app-theme-dark .admin-complaint-shell .small {
        color: #94a3b8 !important;
    }
    @media (prefers-color-scheme: dark) {
        .admin-complaint-hero {
            border-color: rgba(45, 212, 191, 0.24);
            background: linear-gradient(135deg, rgba(20, 184, 166, 0.12) 0%, rgba(15, 23, 42, 0.92) 100%);
        }
        .admin-complaint-title {
            color: #ccfbf1;
        }
        .admin-complaint-card {
            border-color: rgba(148, 163, 184, 0.28);
            background: linear-gradient(180deg, rgba(15, 23, 42, 0.96) 0%, rgba(17, 24, 39, 0.96) 100%);
            box-shadow: 0 24px 35px rgba(2, 6, 23, 0.45);
        }
        .admin-complaint-label {
            color: #99f6e4;
        }
        .admin-photo-box,
        .admin-response-box,
        .admin-response-photo,
        .admin-qr-box,
        .admin-location-box,
        .admin-feed-card {
            border-color: rgba(45, 212, 191, 0.24);
            background: rgba(15, 60, 56, 0.16);
        }
        .admin-summary-item + .admin-summary-item {
            border-top-color: rgba(148, 163, 184, 0.16);
        }
    }
</style>
@endpush

@section('content')
@php
    $statusTheme = match($complaint->status) {
        'approved', 'process' => 'process',
        'rejected' => 'rejected',
        'done' => 'done',
        default => 'pending'
    };
    $statusLabel = match($complaint->status) {
        'approved' => 'Diproses',
        'rejected' => 'Ditolak',
        'process' => 'Diproses',
        'done' => 'Selesai',
        default => 'Pending'
    };
@endphp

<div class="admin-complaint-shell">
    <div class="admin-complaint-hero mb-4">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
            <div>
                <div class="admin-complaint-title">Detail Pengaduan</div>
                <p class="text-muted mb-0">Informasi lengkap laporan pengguna dan histori tindak lanjutnya.</p>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <a href="{{ route('dashboard', ['section' => 'pengaduan']) }}" class="btn btn-outline-secondary btn-sm">Kembali</a>
                <a href="{{ route('admin.complaints.edit', $complaint) }}" class="btn btn-primary btn-sm">Tindak Lanjut</a>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="admin-complaint-card">
                <div class="admin-complaint-body">
                    <div class="admin-complaint-label">Laporan Utama</div>
                    @if($complaint->image_evidence_url)
                        <div class="admin-photo-box d-flex align-items-center justify-content-center mb-4">
                            <img src="{{ $complaint->image_evidence_url }}" alt="Lampiran" class="w-100 h-100" style="object-fit: contain;">
                        </div>
                    @endif
                    <h4 class="fw-semibold mb-3">{{ $complaint->title }}</h4>
                    <p class="mb-0 lh-lg">{{ $complaint->description }}</p>
                </div>
            </div>

            <div class="admin-complaint-card mt-4">
                <div class="admin-complaint-body">
                    <div class="d-flex justify-content-between align-items-center gap-3 flex-wrap mb-3">
                        <div class="admin-complaint-label mb-0">Respons Resmi Admin</div>
                        <span class="admin-status-badge {{ $statusTheme }}">{{ $statusLabel }}</span>
                    </div>

                    @if($complaint->admin_response_message || $complaint->admin_action_taken || $complaint->admin_response_image_url)
                        <div class="admin-response-box">
                            <div class="d-flex justify-content-between align-items-start gap-3 flex-wrap mb-3">
                                <div>
                                    <div class="fw-semibold">{{ $complaint->adminResponder->name ?? 'Admin' }}</div>
                                    <div class="small text-muted">
                                        {{ $complaint->admin_responded_at?->format('d M Y, H:i') ?? 'Waktu respons belum tercatat' }}
                                    </div>
                                </div>
                                <a href="{{ route('admin.complaints.edit', $complaint) }}" class="btn btn-sm btn-outline-secondary">Perbarui Respons</a>
                            </div>
                            @if($complaint->admin_response_message)
                                <div class="mb-3">
                                    <div class="small text-muted mb-1">Pesan ke pelapor</div>
                                    <div class="lh-lg">{{ $complaint->admin_response_message }}</div>
                                </div>
                            @endif
                            @if($complaint->admin_action_taken)
                                <div class="mb-3">
                                    <div class="small text-muted mb-1">Tindakan yang dilakukan</div>
                                    <div class="lh-lg">{{ $complaint->admin_action_taken }}</div>
                                </div>
                            @endif
                            @if($complaint->admin_response_image_url)
                                <div>
                                    <div class="small text-muted mb-2">Foto bukti tindak lanjut</div>
                                    <div class="admin-response-photo d-flex align-items-center justify-content-center">
                                        <img src="{{ $complaint->admin_response_image_url }}" alt="Foto bukti tindak lanjut admin" class="w-100 h-100" style="object-fit: contain;">
                                    </div>
                                </div>
                            @endif
                        </div>
                    @else
                        <div class="text-muted">Belum ada respons resmi dari admin untuk laporan ini.</div>
                    @endif
                </div>
            </div>

            <div class="admin-complaint-card mt-4">
                <div class="admin-complaint-body">
                    <div class="d-flex justify-content-between align-items-center gap-3 flex-wrap mb-3">
                        <div class="admin-complaint-label mb-0">Percakapan Laporan</div>
                        <span class="admin-status-badge {{ $complaint->allow_user_chat ? 'done' : 'pending' }}">
                            {{ $complaint->allow_user_chat ? 'Chat Diizinkan' : 'Chat Belum Aktif' }}
                        </span>
                    </div>
                    @forelse($complaint->comments as $comment)
                        <div class="admin-feed-item {{ $comment->admin_id ? 'admin' : 'user' }}">
                            <div class="admin-feed-card admin-chat-bubble {{ $comment->admin_id ? 'admin' : 'user' }}">
                                <div class="d-flex justify-content-between gap-3 flex-wrap mb-1">
                                    <strong>{{ $comment->admin->name ?? $comment->user->name ?? 'User' }}</strong>
                                    <small class="text-muted">{{ $comment->created_at->format('d M Y H:i') }}</small>
                                </div>
                                <div class="small text-muted mb-2">
                                    {{ $comment->admin_id ? 'Admin' : 'User Pelapor' }}
                                </div>
                                <div class="lh-lg">{{ $comment->comment }}</div>
                            </div>
                        </div>
                    @empty
                        <div class="text-muted">Belum ada percakapan untuk laporan ini.</div>
                    @endforelse
                </div>
            </div>

            <div class="admin-complaint-card mt-4">
                <div class="admin-complaint-body">
                    <div class="admin-complaint-label">Riwayat Status</div>
                    @forelse($complaint->statusHistories as $history)
                        @php
                            $oldLabel = match($history->old_status) {
                                'approved' => 'Diproses',
                                'rejected' => 'Ditolak',
                                'process' => 'Diproses',
                                'done' => 'Selesai',
                                'pending' => 'Pending',
                                default => $history->old_status ?? '-'
                            };
                            $newLabel = match($history->new_status) {
                                'approved' => 'Diproses',
                                'rejected' => 'Ditolak',
                                'process' => 'Diproses',
                                'done' => 'Selesai',
                                'pending' => 'Pending',
                                default => $history->new_status ?? '-'
                            };
                        @endphp
                        <div class="admin-feed-item">
                            <div class="admin-feed-card">
                                <div class="d-flex justify-content-between gap-3 flex-wrap mb-1">
                                    <strong>{{ $history->admin->name ?? 'Admin' }}</strong>
                                    <small class="text-muted">{{ $history->created_at->format('d M Y H:i') }}</small>
                                </div>
                                <div class="small">Status: {{ $oldLabel }} -> <strong>{{ $newLabel }}</strong></div>
                                @if($history->note)
                                    <div class="small text-muted mt-1">{{ $history->note }}</div>
                                @endif
                            </div>
                        </div>
                    @empty
                        <div class="text-muted">Belum ada perubahan status.</div>
                    @endforelse
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="admin-complaint-card">
                <div class="admin-complaint-body">
                    <div class="admin-complaint-label">Ringkasan</div>
                    <div class="admin-summary-item">
                        <div class="text-muted mb-1">Pelapor</div>
                        <div class="fw-semibold">{{ $complaint->user->name ?? '-' }}</div>
                        <div class="small text-muted">{{ $complaint->user->email ?? '' }}</div>
                    </div>
                    <div class="admin-summary-item">
                        <div class="text-muted mb-1">Kategori</div>
                        <div class="fw-semibold">{{ $complaint->category->name ?? '-' }}</div>
                    </div>
                    <div class="admin-summary-item">
                        <div class="text-muted mb-1">Status</div>
                        <span class="admin-status-badge {{ $statusTheme }}">{{ $statusLabel }}</span>
                    </div>
                    <div class="admin-summary-item">
                        <div class="text-muted mb-1">Akses Chat</div>
                        <div class="fw-semibold">{{ $complaint->allow_user_chat ? 'Diizinkan untuk user' : 'Belum diizinkan' }}</div>
                    </div>
                    <div class="admin-summary-item">
                        <div class="text-muted mb-1">Tanggal Laporan</div>
                        <div class="fw-semibold">{{ $complaint->created_at->format('d M Y, H:i') }}</div>
                    </div>
                    <div class="admin-summary-item">
                        <div class="text-muted mb-2">QR Detail Pengaduan</div>
                        <div class="admin-qr-box">
                            <div id="complaint-qr"></div>
                            <div class="small text-muted mt-2 text-center">Scan untuk membuka halaman detail ini dengan cepat.</div>
                        </div>
                    </div>
                    <div class="admin-summary-item">
                        <div class="text-muted mb-2">Lokasi</div>
                        <div class="admin-location-box small lh-lg">
                            @if($complaint->street_address)
                                <div>{{ $complaint->street_address }}</div>
                            @endif
                            @if($complaint->village || $complaint->district || $complaint->city || $complaint->province)
                                <div>{{ collect([$complaint->village, $complaint->district, $complaint->city, $complaint->province])->filter()->join(', ') }}</div>
                            @endif
                            @if($complaint->latitude && $complaint->longitude)
                                <div class="mt-2">
                                    <span class="text-muted">GPS:</span> {{ $complaint->latitude }}, {{ $complaint->longitude }}
                                </div>
                                <a href="https://www.google.com/maps?q={{ $complaint->latitude }},{{ $complaint->longitude }}" target="_blank" rel="noopener noreferrer">Buka di Google Maps</a>
                            @endif
                            @if(
                                !$complaint->street_address
                                && !$complaint->village
                                && !$complaint->district
                                && !$complaint->city
                                && !$complaint->province
                                && !($complaint->latitude && $complaint->longitude)
                            )
                                <span class="text-muted">Lokasi belum diisi.</span>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <script>
        (function () {
            const target = document.getElementById('complaint-qr');
            if (!target || typeof QRCode === 'undefined') {
                return;
            }

            new QRCode(target, {
                text: @json(route('admin.complaints.show', $complaint)),
                width: 180,
                height: 180,
                correctLevel: QRCode.CorrectLevel.M
            });
        })();
    </script>
@endpush
