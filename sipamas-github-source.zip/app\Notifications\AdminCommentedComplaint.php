<?php

namespace App\Notifications;

use App\Models\Complaint;
use App\Models\ComplaintComment;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class AdminCommentedComplaint extends Notification
{
    use Queueable;

    public function __construct(
        private Complaint $complaint,
        private ComplaintComment $comment
    ) {}

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toArray(object $notifiable): array
    {
        return [
            'complaint_id' => $this->complaint->id,
            'complaint_title' => $this->complaint->title,
            'comment' => $this->comment->comment,
            'admin_name' => $this->comment->admin->name ?? 'Admin',
            'sent_at' => $this->comment->created_at?->toDateTimeString(),
        ];
    }
}
