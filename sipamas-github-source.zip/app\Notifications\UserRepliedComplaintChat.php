<?php

namespace App\Notifications;

use App\Models\Complaint;
use App\Models\ComplaintComment;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class UserRepliedComplaintChat extends Notification
{
    use Queueable;

    public function __construct(
        private Complaint $complaint,
        private ComplaintComment $comment
    ) {}

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toArray(object $notifiable): array
    {
        return [
            'notification_type' => 'complaint_chat_reply',
            'title' => 'Balasan Chat Pengaduan',
            'complaint_id' => $this->complaint->id,
            'complaint_title' => $this->complaint->title,
            'message' => $this->comment->comment,
            'sender_name' => $this->comment->user->name ?? 'User',
            'sender_email' => $this->comment->user->email ?? null,
            'action_url' => route('admin.complaints.show', $this->complaint),
            'action_label' => 'Buka Pengaduan',
            'sent_at' => $this->comment->created_at?->toDateTimeString(),
        ];
    }
}
