@extends('layouts.app')

@section('title', 'Pengaturan SIPAMAS')

@push('styles')
<style>
    .setting-hero {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    .setting-hero h2 {
        font-size: clamp(2rem, 3.2vw, 2.8rem);
        font-weight: 800;
        color: #0f172a;
        margin-bottom: 0.5rem;
    }
    .setting-hero p {
        color: #64748b;
        max-width: 720px;
        margin: 0 auto;
        font-size: 1.05rem;
    }
    .setting-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 18px;
    }
    .setting-card {
        background: #ffffff;
        border: 1px solid rgba(148, 163, 184, 0.2);
        border-radius: 18px;
        padding: 20px;
        box-shadow: 0 12px 26px rgba(15, 23, 42, 0.06);
    }
    .setting-card h5 {
        margin-bottom: 10px;
    }
    .setting-actions {
        display: grid;
        gap: 10px;
        margin-top: 14px;
    }
    .setting-muted {
        color: #64748b;
        font-size: 0.95rem;
    }
    .setting-label {
        font-weight: 600;
        color: #0f172a;
    }
    .theme-pref-card {
        position: relative;
        overflow: hidden;
    }
    .theme-pref-card::after {
        content: "";
        position: absolute;
        inset: auto -30px -50px auto;
        width: 150px;
        height: 150px;
        border-radius: 999px;
        background: radial-gradient(circle, rgba(20, 184, 166, 0.18) 0%, rgba(20, 184, 166, 0) 70%);
        pointer-events: none;
    }
    .theme-choice-group {
        display: grid;
        gap: 12px;
        margin-top: 16px;
    }
    .theme-choice {
        position: relative;
        display: flex;
        align-items: flex-start;
        gap: 14px;
        padding: 16px;
        border-radius: 16px;
        border: 1px solid rgba(148, 163, 184, 0.24);
        background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);
        cursor: pointer;
        transition: 0.2s ease;
    }
    .theme-choice:hover {
        transform: translateY(-1px);
        border-color: rgba(15, 118, 110, 0.28);
        box-shadow: 0 10px 24px rgba(15, 23, 42, 0.06);
    }
    .theme-choice input {
        margin-top: 3px;
    }
    .theme-choice strong {
        display: block;
        margin-bottom: 4px;
        color: #0f172a;
    }
    .theme-choice span {
        color: #64748b;
        font-size: 0.92rem;
        line-height: 1.45;
    }
    .theme-choice.active {
        border-color: rgba(15, 118, 110, 0.3);
        background: linear-gradient(135deg, rgba(15, 118, 110, 0.08), rgba(22, 163, 74, 0.05));
        box-shadow: 0 14px 28px rgba(15, 118, 110, 0.08);
    }
    body.app-theme-dark .setting-hero h2,
    body.app-theme-dark .setting-label,
    body.app-theme-dark .theme-choice strong {
        color: #e2e8f0;
    }
    body.app-theme-dark .setting-hero p,
    body.app-theme-dark .setting-muted,
    body.app-theme-dark .theme-choice span {
        color: #94a3b8;
    }
    body.app-theme-dark .setting-card,
    body.app-theme-dark .theme-choice {
        background: linear-gradient(180deg, #0f172a 0%, #111827 100%);
        border-color: rgba(148, 163, 184, 0.18);
    }
    body.app-theme-dark .theme-choice.active {
        border-color: rgba(45, 212, 191, 0.3);
        background: linear-gradient(135deg, rgba(20, 184, 166, 0.14), rgba(15, 23, 42, 0.96));
        box-shadow: 0 14px 28px rgba(2, 6, 23, 0.28);
    }
</style>
@endpush

@section('content')
<div class="app-card p-4 p-md-5">
    @if (session('status') === 'notification-preference-updated')
        <div class="alert alert-success mb-4">
            Pengaturan notifikasi berhasil diperbarui.
        </div>
    @endif

    <div class="setting-hero">
        <h2>Pengaturan SIPAMAS</h2>
        <p>Atur preferensi aplikasi yang benar-benar berpengaruh pada tampilan dan perilaku akun Anda.</p>
    </div>

    <div class="setting-grid">
        <div class="setting-card theme-pref-card">
            <h5>Tema Tampilan</h5>
            <p class="setting-muted">Pilihan ini langsung diterapkan ke halaman yang Anda buka, termasuk dashboard, pengaduan, notifikasi, dan halaman informasi lain di aplikasi.</p>
            <div class="theme-choice-group" data-theme-choice-group>
                <label class="theme-choice" data-theme-choice="light">
                    <input type="radio" name="theme_mode" value="light" data-theme-radio>
                    <div>
                        <strong>Mode Terang</strong>
                        <span>Tampilan lebih bersih, segar, dan cocok untuk penggunaan siang hari.</span>
                    </div>
                </label>
                <label class="theme-choice" data-theme-choice="dark">
                    <input type="radio" name="theme_mode" value="dark" data-theme-radio>
                    <div>
                        <strong>Mode Gelap</strong>
                        <span>Latar lebih redup dan nyaman untuk fokus lebih lama atau saat malam hari.</span>
                    </div>
                </label>
            </div>
        </div>

        <div class="setting-card">
            <h5>Preferensi Notifikasi</h5>
            <p class="setting-muted">Kontrol visibilitas ikon notifikasi di navbar dan menu notifikasi di sidebar.</p>
            <div class="setting-actions">
                <form method="POST" action="{{ route('setting.notifications.update') }}">
                    @csrf
                    @method('PATCH')
                    <input type="hidden" name="show_notifications" value="0">
                    <div class="form-check form-switch mb-3">
                        <input
                            class="form-check-input"
                            type="checkbox"
                            role="switch"
                            id="showNotificationsSwitch"
                            name="show_notifications"
                            value="1"
                            {{ auth()->user()->show_notifications ?? true ? 'checked' : '' }}>
                        <label class="form-check-label setting-label" for="showNotificationsSwitch">
                            Tampilkan notifikasi
                        </label>
                    </div>
                    <button type="submit" class="btn btn-outline-secondary w-100">Simpan Preferensi</button>
                </form>
            </div>
        </div>

        <div class="setting-card">
            <h5>Aksi Notifikasi</h5>
            <p class="setting-muted">Kelola status notifikasi akun Anda tanpa perlu membuka halaman lain.</p>
            <div class="setting-actions">
                <form method="POST" action="{{ route('notifications.readAll') }}">
                    @csrf
                    <button type="submit" class="btn btn-outline-secondary w-100">Tandai Semua Sudah Dibaca</button>
                </form>
            </div>
        </div>

        <div class="setting-card">
            <h5>Keamanan Akun</h5>
            <p class="setting-muted">Ganti password akun Anda untuk menjaga keamanan akses.</p>
            <div class="setting-actions">
                <a href="{{ route('profile.edit') }}" class="btn btn-outline-secondary w-100">Ubah Password</a>
            </div>
        </div>

    </div>
</div>
@endsection

@push('scripts')
<script>
    (function () {
        function syncThemeChoices() {
            var theme = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';

            document.querySelectorAll('[data-theme-choice]').forEach(function (item) {
                item.classList.toggle('active', item.getAttribute('data-theme-choice') === theme);
            });
        }

        document.querySelectorAll('[data-theme-radio]').forEach(function (radio) {
            radio.addEventListener('change', syncThemeChoices);
        });

        syncThemeChoices();
        document.addEventListener('click', function () {
            window.setTimeout(syncThemeChoices, 0);
        });
    })();
</script>
@endpush
