@php
    $manifestPath = public_path('landing/.vite/manifest.json');
    $manifest = file_exists($manifestPath)
        ? json_decode(file_get_contents($manifestPath), true)
        : [];
    $entry = $manifest['home.html'] ?? null;

    $entryCss = [];
    $visited = [];
    $collectCss = function ($key) use (&$collectCss, &$entryCss, &$visited, $manifest) {
        if (!$key || isset($visited[$key]) || !isset($manifest[$key])) {
            return;
        }
        $visited[$key] = true;
        $node = $manifest[$key];
        foreach (($node['css'] ?? []) as $cssFile) {
            if (!in_array($cssFile, $entryCss, true)) {
                $entryCss[] = $cssFile;
            }
        }
        foreach (($node['imports'] ?? []) as $importKey) {
            $collectCss($importKey);
        }
    };
    $collectCss('home.html');

    // Fallback: grab first hashed asset if manifest not present
    $cssFiles = glob(public_path('landing/assets/index-*.css'));
    $jsFiles  = glob(public_path('landing/assets/home-*.js'));

    $homeConfig = [
        'homeUrl' => route('home'),
        'complaintListUrl' => $complaintListUrl ?? route('complaints.index'),
        'createComplaintUrl' => $createComplaintUrl ?? route('complaints.create'),
        'dashboardUrl' => route('dashboard', ['section' => 'pengaduan']),
        'isAdmin' => auth()->user()?->role === 'admin',
        'profileUrl' => route('profil.edit'),
        'logoutUrl' => route('logout'),
        'csrfToken' => csrf_token(),
        'user' => auth()->user()
            ? [
                'name' => auth()->user()->name,
                'role' => auth()->user()->role,
                'photoUrl' => auth()->user()->profile_photo_url,
            ]
            : null,
        'settingsUrl' => route('setting'),
        'faqUrl' => route('faq'),
        'aboutUrl' => route('about'),
        'contactUrl' => route('contact'),
    ];
    $homeStatsPayload = $homeStats ?? [];
    $homeHeroStatsPayload = $heroStats ?? [];
    $homeComplaintsPayload = $homeComplaints ?? [];
    $homeSearchPayload = $homeSearch ?? ['query' => '', 'hasQuery' => false, 'resultCount' => 0, 'status' => 'all', 'category' => 'all'];
    $homeFilterOptionsPayload = $homeFilterOptions ?? ['categories' => [], 'statuses' => []];
@endphp
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="color-scheme" content="light dark">
    <title>SIPAMAS - Home</title>
    <script>
        (function () {
            var storedTheme = null;
            try {
                storedTheme = localStorage.getItem('sipamas-theme');
            } catch (error) {
                storedTheme = null;
            }

            var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
            var useDark = storedTheme ? storedTheme === 'dark' : prefersDark;
            document.documentElement.classList.toggle('dark', useDark);
        })();
    </script>

    @if(!empty($entryCss))
        @foreach($entryCss as $css)
            <link rel="stylesheet" href="{{ asset('landing/' . $css) }}">
        @endforeach
    @elseif(!empty($cssFiles))
        <link rel="stylesheet" href="{{ asset('landing/assets/' . basename($cssFiles[0])) }}">
    @endif

    @if($entry && isset($entry['imports']))
        @foreach($entry['imports'] as $import)
            @php $importFile = $manifest[$import]['file'] ?? null; @endphp
            @if($importFile)
                <link rel="modulepreload" href="{{ asset('landing/' . $importFile) }}">
            @endif
        @endforeach
    @endif
</head>
<body class="min-h-screen bg-white dark:bg-slate-950">
    <div id="root"></div>
    <script>
        window.homeConfig = {!! json_encode($homeConfig, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) !!};
        window.homeStats = {!! json_encode($homeStatsPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) !!};
        window.homeHeroStats = {!! json_encode($homeHeroStatsPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) !!};
        window.homeComplaints = {!! json_encode($homeComplaintsPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) !!};
        window.homeSearch = {!! json_encode($homeSearchPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) !!};
        window.homeFilterOptions = {!! json_encode($homeFilterOptionsPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) !!};
    </script>

    @if($entry)
        <script type="module" src="{{ asset('landing/' . $entry['file']) }}"></script>
    @elseif(!empty($jsFiles))
        <script type="module" src="{{ asset('landing/assets/' . basename($jsFiles[0])) }}"></script>
    @else
        <div style="padding:24px;color:#b91c1c;font-weight:600;">
            Build asset home tidak ditemukan. Jalankan <code>npm run build</code> di <code>_design/LandingPageSipamas</code> lalu salin hasilnya ke <code>public/landing</code>.
        </div>
    @endif
</body>
</html>
