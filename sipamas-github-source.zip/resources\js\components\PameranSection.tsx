import React from 'react';

export function PameranSection() {
  const items = [
    { title: 'Peta & Marker', desc: 'Lihat titik pengaduan dengan status warna di peta.' },
    { title: 'Detail Laporan', desc: 'Judul, kategori, lokasi, dan foto bukti tersaji rapi.' },
    { title: 'Riwayat Status', desc: 'Timeline perubahan status oleh admin dan notifikasi.' },
  ];

  return (
    <section id="pameran" className="py-16 bg-slate-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-3xl sm:text-4xl font-serif text-slate-900 mb-3">Pameran fitur</h2>
          <p className="text-slate-600">Cuplikan fungsi utama SIPAMAS.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {items.map((it) => (
            <div key={it.title} className="p-6 rounded-xl bg-white border border-slate-200 shadow-sm">
              <h3 className="text-xl font-semibold text-slate-900 mb-2">{it.title}</h3>
              <p className="text-slate-600">{it.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
