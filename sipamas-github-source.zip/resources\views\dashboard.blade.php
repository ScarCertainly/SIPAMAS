@extends('layouts.app')

@section('title', 'Dashboard')

@push('styles')
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="">
    <style>
        .admin-dashboard-page .app-nav, .admin-dashboard-page .app-sidebar { display: none; }
        .admin-dashboard-page .app-shell { max-width: none; padding: 0; }
        .admin-dashboard-page .app-layout { display: block; margin: 0; }
        .admin-dashboard-page .app-main, .admin-dashboard-page .app-main-full { grid-column: auto; }
        .admin-dashboard-page, .admin-dashboard-page * { font-family: "Plus Jakarta Sans", system-ui, -apple-system, "Segoe UI", sans-serif; }
        .admin-dashboard { min-height: 100vh; display: grid; grid-template-columns: 212px minmax(0,1fr); background: #f8fafc; }
        .admin-dashboard-sidebar { background: #fff; border-right: 1px solid #e5e7eb; padding: 20px 12px 18px; display: flex; flex-direction: column; gap: 16px; }
        .admin-dashboard-brand, .admin-dashboard-user-main, .admin-dashboard-profile { display: flex; align-items: center; gap: 12px; }
        .admin-dashboard-brand { padding: 0 6px; }
        .admin-dashboard-brand-mark, .admin-dashboard-avatar, .admin-dashboard-user-avatar { display: inline-flex; align-items: center; justify-content: center; font-weight: 800; }
        .admin-dashboard-brand-mark { width: 42px; height: 42px; border-radius: 14px; color: #fff; background: linear-gradient(135deg,#16a34a 0%,#15803d 100%); }
        .admin-dashboard-brand-mark svg { width: 24px; height: 24px; }
        .admin-dashboard-brand-title { font-size: 1.05rem; font-weight: 800; color: #111827; line-height: 1.1; }
        .admin-dashboard-brand-subtitle, .admin-dashboard-user-email, .admin-dashboard-list-meta, .admin-dashboard-profile-role, .admin-dashboard-card-title, .admin-dashboard-panel-copy, .admin-dashboard-progress-meta, .admin-dashboard-muted { color: #64748b; }
        .admin-dashboard-brand-subtitle, .admin-dashboard-profile-role, .admin-dashboard-user-email, .admin-dashboard-list-meta { font-size: 0.82rem; }
        .admin-dashboard-nav { display: flex; flex-direction: column; gap: 8px; }
        .admin-dashboard-nav-label { margin: 0 6px 4px; color: #94a3b8; text-transform: uppercase; letter-spacing: .12em; font-size: .71rem; font-weight: 800; }
        .admin-dashboard-link { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 12px; color: #374151; text-decoration: none; border: 1px solid transparent; font-weight: 600; transition: .2s ease; }
        .admin-dashboard-link svg { width: 18px; height: 18px; flex: 0 0 auto; }
        .admin-dashboard-link:hover { background: #f8fafc; color: #0f172a; border-color: #e2e8f0; }
        .admin-dashboard-link.active { background: #ecfdf5; border-color: #bbf7d0; color: #16a34a; }
        .admin-dashboard-spacer { flex: 1; }
        .admin-dashboard-settings { border-top: 1px solid #e5e7eb; padding-top: 14px; }
        .admin-dashboard-main { min-width: 0; width: 100%; padding: 18px 18px 28px; }
        .admin-dashboard-panel-head, .admin-dashboard-card-head, .admin-dashboard-user-head, .admin-dashboard-progress-head { display: flex; justify-content: space-between; gap: 12px; }
        .admin-dashboard-profile-name, .admin-dashboard-user-name, .admin-dashboard-list-title, .admin-dashboard-progress-name { font-weight: 700; color: #0f172a; }
        .admin-dashboard-card, .admin-dashboard-panel, .admin-dashboard-table, .admin-dashboard-user-card { background: #fff; border: 1px solid #e5e7eb; box-shadow: 0 2px 8px rgba(15,23,42,.04); }
        .admin-dashboard-page-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; margin-bottom: 20px; }
        .admin-dashboard-title { font-size: 1.75rem; font-weight: 800; line-height: 1.15; color: #111827; margin: 0 0 6px; }
        .admin-dashboard-subtitle { color: #6b7280; margin: 0; font-size: .95rem; line-height: 1.5; max-width: 720px; }
        .admin-dashboard-toolbar { display: flex; gap: 12px; flex-wrap: wrap; align-items: flex-start; justify-content: flex-end; }
        .admin-dashboard-tag, .admin-dashboard-badge { display: inline-flex; align-items: center; border-radius: 999px; font-weight: 700; }
        .admin-dashboard-grid, .admin-dashboard-stats, .admin-dashboard-user-grid, .admin-dashboard-user-stats { display: grid; gap: 18px; }
        .admin-dashboard-inline-actions, .admin-dashboard-badges { margin-top: 12px; }
        .admin-dashboard-inline-actions {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }
        .admin-dashboard-clock { min-width: 240px; flex: 0 0 240px; border-radius: 16px; background: linear-gradient(135deg,#16a34a 0%,#0f766e 100%); color: #fff; padding: 16px 18px; box-shadow: 0 10px 20px rgba(15,118,110,.14); }
        .admin-dashboard-clock-label { color: rgba(255,255,255,.82); font-size: .8rem; }
        .admin-dashboard-clock-time { font-size: 2rem; font-weight: 800; line-height: 1; margin: 10px 0 6px; }
        .admin-dashboard-clock-date { font-size: .9rem; color: rgba(255,255,255,.86); }
        .admin-dashboard-profile-menu { min-width: 220px; border: 1px solid #e5e7eb; border-radius: 16px; padding: 8px; box-shadow: 0 18px 34px rgba(15, 23, 42, 0.12); }
        .admin-dashboard-profile-trigger { display: inline-flex; align-items: center; gap: 12px; min-height: 74px; border: 1px solid #e5e7eb; border-radius: 16px; background: #fff; padding: 10px 14px; color: #0f172a; box-shadow: 0 2px 8px rgba(15,23,42,.04); }
        .admin-dashboard-profile-trigger:hover,
        .admin-dashboard-profile-trigger.show { background: #f8fafc; border-color: #dbe3ee; color: #0f172a; }
        .admin-dashboard-profile-avatar { width: 42px; height: 42px; border-radius: 14px; display: inline-flex; align-items: center; justify-content: center; overflow: hidden; background: linear-gradient(135deg,#dcfce7 0%,#bbf7d0 100%); color: #15803d; font-weight: 800; flex: 0 0 auto; }
        .admin-dashboard-profile-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .admin-dashboard-profile-meta { min-width: 0; text-align: left; }
        .admin-dashboard-profile-label { font-size: .75rem; color: #64748b; line-height: 1.1; }
        .admin-dashboard-profile-name { font-size: .94rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .admin-dashboard-profile-menu .dropdown-item { border-radius: 12px; padding: 10px 12px; font-weight: 600; color: #334155; }
        .admin-dashboard-profile-menu .dropdown-item:hover { background: #f8fafc; color: #0f172a; }
        .admin-dashboard-profile-menu .dropdown-item-danger { color: #dc2626; }
        .admin-dashboard-profile-menu .dropdown-item-danger:hover { background: #fef2f2; color: #b91c1c; }
        .admin-dashboard-stats { grid-template-columns: repeat(4,minmax(0,1fr)); margin-bottom: 20px; }
        .admin-dashboard-card, .admin-dashboard-panel, .admin-dashboard-user-card, .admin-dashboard-table { border-radius: 16px; }
        .admin-dashboard-card { padding: 18px; }
        .admin-dashboard-card-head, .admin-dashboard-panel-head, .admin-dashboard-user-head, .admin-dashboard-progress-head { align-items: flex-start; }
        .admin-dashboard-card-icon, .admin-dashboard-list-icon { display: inline-flex; align-items: center; justify-content: center; }
        .admin-dashboard-card-icon { width: 48px; height: 48px; border-radius: 14px; }
        .admin-dashboard-card-icon svg, .admin-dashboard-list-icon svg { width: 24px; height: 24px; }
        .admin-dashboard-card-value { font-size: 1.85rem; font-weight: 800; color: #111827; margin: 8px 0 2px; line-height: 1; }
        .admin-dashboard-card-foot { color: #6b7280; font-size: .82rem; margin-top: 8px; display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
        .admin-dashboard-card-trend-up { color: #16a34a; font-weight: 700; }
        .admin-dashboard-card-trend-down { color: #dc2626; font-weight: 700; }
        .admin-dashboard-grid { grid-template-columns: minmax(0,1.35fr) minmax(320px,.85fr); gap: 20px; margin-bottom: 20px; }
        .admin-dashboard-panel { padding: 20px; }
        .admin-dashboard-panel-title { font-size: 1.1rem; font-weight: 800; color: #111827; margin-bottom: 4px; }
        .admin-dashboard-tag { background: #eff6ff; color: #2563eb; padding: 6px 10px; font-size: .74rem; }
        .admin-dashboard-progress-list, .admin-dashboard-list { display: flex; flex-direction: column; gap: 16px; }
        .admin-dashboard-progress-head { align-items: center; margin-bottom: 9px; }
        .admin-dashboard-progress-track { height: 10px; border-radius: 999px; background: #e2e8f0; overflow: hidden; }
        .admin-dashboard-progress-bar { height: 100%; border-radius: 999px; background: linear-gradient(90deg,#22c55e 0%,#16a34a 100%); }
        .admin-dashboard-map { width: 100%; height: 380px; border-radius: 14px; border: 1px solid #e5e7eb; overflow: hidden; }
        .admin-dashboard-list-item { display: flex; align-items: flex-start; gap: 14px; padding-bottom: 16px; border-bottom: 1px solid #f1f5f9; }
        .admin-dashboard-list-item:last-child { border-bottom: 0; padding-bottom: 0; }
        .admin-dashboard-list-icon { width: 44px; height: 44px; border-radius: 14px; background: #f8fafc; color: #475569; flex: 0 0 auto; }
        .admin-dashboard-list-main { flex: 1; min-width: 0; }
        .admin-dashboard-list-copy { margin-top: 6px; color: #475569; font-size: .9rem; line-height: 1.5; }
        .admin-dashboard-badge { padding: 6px 10px; font-size: .75rem; }
        .admin-dashboard-badge.pending { background: #fef3c7; color: #92400e; }
        .admin-dashboard-badge.process { background: #dbeafe; color: #1d4ed8; }
        .admin-dashboard-badge.done { background: #dcfce7; color: #166534; }
        .admin-dashboard-badge.rejected { background: #fee2e2; color: #b91c1c; }
        .admin-dashboard-badge.category { background: #f8fafc; color: #475569; border: 1px solid #e2e8f0; }
        .admin-dashboard-user-grid { grid-template-columns: repeat(3,minmax(0,1fr)); }
        .admin-dashboard-user-card { padding: 18px; }
        .admin-dashboard-user-avatar { width: 48px; height: 48px; border-radius: 14px; background: linear-gradient(135deg,#dcfce7 0%,#bbf7d0 100%); color: #15803d; flex: 0 0 auto; }
        .admin-dashboard-user-stats { grid-template-columns: repeat(2,minmax(0,1fr)); gap: 12px; }
        .admin-dashboard-user-stat { border-radius: 14px; background: #f8fafc; padding: 12px; }
        .admin-dashboard-user-stat-label { color: #64748b; font-size: .78rem; }
        .admin-dashboard-user-stat-value { font-size: 1.15rem; font-weight: 800; color: #0f172a; margin-top: 4px; }
        .admin-dashboard-search-form {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 16px;
        }
        .admin-dashboard-filter-block {
            margin-top: 18px;
            margin-bottom: 4px;
            padding: 16px;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            background: #f8fafc;
        }
        .admin-dashboard-filter-block .admin-dashboard-search-form {
            margin-bottom: 0;
        }
        .admin-dashboard-search-form input {
            flex: 1 1 280px;
            min-height: 44px;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            padding: 10px 14px;
            background: #fff;
        }
        .admin-dashboard-role-form {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }
        .admin-dashboard-role-select {
            min-width: 150px;
            min-height: 38px;
            border: 1px solid #d1d5db;
            border-radius: 10px;
            padding: 6px 10px;
            background: #fff;
        }
        .admin-dashboard-badge.admin {
            background: #fee2e2;
            color: #b91c1c;
        }
        .admin-dashboard-badge.user {
            background: #dbeafe;
            color: #1d4ed8;
        }
        .admin-dashboard-badge.blacklisted {
            background: #e5e7eb;
            color: #111827;
        }
        .admin-dashboard-table td .admin-dashboard-badge {
            white-space: nowrap;
        }
        .admin-dashboard-table .admin-dashboard-list-meta {
            margin-top: 4px;
        }
        .admin-dashboard-table { padding: 6px; overflow-x: auto; }
        .admin-dashboard-table table { width: 100%; border-collapse: collapse; }
        .admin-dashboard-table th, .admin-dashboard-table td { padding: 16px 14px; vertical-align: top; }
        .admin-dashboard-table th { color: #94a3b8; font-size: .74rem; text-transform: uppercase; letter-spacing: .08em; font-weight: 800; border-bottom: 1px solid #e2e8f0; }
        .admin-dashboard-table td { color: #334155; border-top: 1px solid #f1f5f9; }
        .admin-dashboard-table tbody tr:first-child td { border-top: 0; }
        .admin-dashboard-table--complaints table {
            min-width: 0;
            table-layout: fixed;
        }
        .admin-dashboard-table--complaints .col-no {
            width: 48px;
        }
        .admin-dashboard-table--complaints th,
        .admin-dashboard-table--complaints td {
            padding: 14px 10px;
        }
        .admin-dashboard-table--complaints .col-reporter {
            width: 120px;
        }
        .admin-dashboard-table--complaints .col-title {
            width: 31%;
        }
        .admin-dashboard-table--complaints .col-category {
            width: 22%;
        }
        .admin-dashboard-table--complaints .col-status {
            width: 110px;
        }
        .admin-dashboard-table--complaints .col-actions {
            width: 166px;
        }
        .admin-dashboard-table--complaints .col-date {
            width: 92px;
        }
        .admin-dashboard-table--complaints td.col-actions-cell,
        .admin-dashboard-table--complaints td.col-status-cell {
            white-space: nowrap;
        }
        .admin-dashboard-table--complaints td.col-title,
        .admin-dashboard-table--complaints td.col-category,
        .admin-dashboard-table--complaints td.col-reporter {
            overflow-wrap: anywhere;
        }
        .admin-dashboard-table--complaints td.col-actions-cell .admin-dashboard-inline-actions {
            margin-top: 0;
            gap: 6px;
        }
        .admin-dashboard-table--complaints td.col-actions-cell .btn {
            min-width: 0;
            padding-inline: 14px;
        }
        .admin-dashboard-table--complaints td.col-date-cell {
            color: #475569;
            white-space: normal;
        }
        .admin-dashboard-empty { border: 1px dashed #cbd5e1; border-radius: 14px; padding: 16px; color: #64748b; background: #f8fafc; }
        .admin-dashboard-user-home { max-width: 920px; }
        .admin-dashboard-panel-flat {
            background: transparent;
            border: 0;
            box-shadow: none;
            padding: 0;
        }
        .admin-stats-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 18px; margin-bottom: 20px; }
        .admin-stats-card { background: #fff; border: 1px solid #e5e7eb; border-radius: 18px; padding: 20px; box-shadow: 0 2px 8px rgba(15,23,42,.04); }
        .admin-stats-card-label { color: #64748b; font-size: .84rem; }
        .admin-stats-card-value { color: #111827; font-size: 2rem; font-weight: 800; margin-top: 10px; line-height: 1; }
        .admin-stats-card-value.good { color: #16a34a; }
        .admin-stats-card-meta { margin-top: 12px; display: flex; align-items: center; gap: 6px; flex-wrap: wrap; font-size: .82rem; color: #64748b; }
        .admin-stats-card-change.up { color: #16a34a; font-weight: 700; }
        .admin-stats-card-change.down { color: #dc2626; font-weight: 700; }
        .admin-stats-chart-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 20px; margin-bottom: 20px; }
        .admin-stats-chart-card { background: #fff; border: 1px solid #e5e7eb; border-radius: 18px; box-shadow: 0 2px 8px rgba(15,23,42,.04); padding: 20px; }
        .admin-stats-chart-head { display: flex; justify-content: space-between; align-items: flex-start; gap: 12px; margin-bottom: 18px; }
        .admin-stats-chart-title { font-size: 1.05rem; font-weight: 800; color: #111827; margin: 0 0 4px; }
        .admin-stats-chart-copy { margin: 0; color: #64748b; font-size: .88rem; }
        .admin-stats-chart-box { position: relative; height: 320px; }
        .admin-stats-category-list { display: flex; flex-direction: column; gap: 14px; }
        .admin-stats-category-item { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding-bottom: 14px; border-bottom: 1px solid #f1f5f9; }
        .admin-stats-category-item:last-child { padding-bottom: 0; border-bottom: 0; }
        .admin-stats-category-main { display: flex; align-items: center; gap: 12px; min-width: 0; }
        .admin-stats-category-icon { width: 42px; height: 42px; border-radius: 14px; display: inline-flex; align-items: center; justify-content: center; background: #f3f4f6; color: #475569; }
        .admin-stats-category-icon svg { width: 20px; height: 20px; }
        .admin-stats-category-name { font-weight: 700; color: #111827; }
        .admin-stats-category-sub { font-size: .82rem; color: #64748b; }
        .admin-stats-category-share { font-size: .82rem; font-weight: 700; color: #16a34a; white-space: nowrap; }
        .admin-stats-area-list { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px 16px; margin-top: 16px; }
        .admin-stats-area-item { display: flex; align-items: center; gap: 8px; min-width: 0; }
        .admin-stats-area-swatch { width: 10px; height: 10px; border-radius: 999px; flex: 0 0 auto; }
        .admin-stats-area-name { font-size: .84rem; color: #334155; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .admin-stats-area-value { margin-left: auto; font-size: .84rem; font-weight: 700; color: #111827; }
        .admin-reports-toolbar { display: flex; align-items: center; justify-content: space-between; gap: 16px; margin-bottom: 20px; flex-wrap: wrap; }
        .admin-reports-toolbar-actions { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
        .admin-reports-chip { display: inline-flex; align-items: center; gap: 8px; min-height: 40px; padding: 0 14px; border: 1px solid #e5e7eb; border-radius: 12px; background: #fff; color: #475569; font-weight: 600; }
        .admin-reports-chip svg { width: 16px; height: 16px; }
        .admin-reports-export-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            min-height: 40px;
            padding: 0 16px;
            border-radius: 12px;
            font-size: .95rem;
            font-weight: 700;
            line-height: 1;
        }
        .admin-reports-export-btn svg {
            width: 16px;
            height: 16px;
        }
        .admin-reports-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 18px; margin-bottom: 20px; }
        .admin-reports-card { background: #fff; border: 1px solid #e5e7eb; border-radius: 18px; padding: 20px; box-shadow: 0 2px 8px rgba(15,23,42,.04); }
        .admin-reports-card-label { color: #64748b; font-size: .84rem; }
        .admin-reports-card-value { color: #111827; font-size: 2rem; font-weight: 800; margin-top: 10px; line-height: 1; }
        .admin-reports-card-value.good { color: #16a34a; }
        .admin-reports-card-meta { margin-top: 12px; display: flex; align-items: center; gap: 6px; flex-wrap: wrap; color: #64748b; font-size: .82rem; }
        .admin-reports-card-change.up { color: #16a34a; font-weight: 700; }
        .admin-reports-card-change.down { color: #dc2626; font-weight: 700; }
        .admin-reports-layout { display: grid; grid-template-columns: minmax(0, 1.2fr) minmax(320px, .8fr); gap: 20px; margin-bottom: 20px; }
        .admin-reports-list { display: flex; flex-direction: column; gap: 16px; }
        .admin-reports-list-item { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding-bottom: 16px; border-bottom: 1px solid #f1f5f9; }
        .admin-reports-list-item:last-child { padding-bottom: 0; border-bottom: 0; }
        .admin-reports-list-main { display: flex; align-items: center; gap: 12px; min-width: 0; }
        .admin-reports-rank { width: 42px; height: 42px; border-radius: 14px; background: #dcfce7; color: #15803d; display: inline-flex; align-items: center; justify-content: center; font-weight: 800; flex: 0 0 auto; }
        .admin-reports-rank svg { width: 18px; height: 18px; }
        .admin-reports-list-name { font-weight: 700; color: #111827; }
        .admin-reports-list-sub { color: #64748b; font-size: .82rem; }
        .admin-reports-list-metric { text-align: right; }
        .admin-reports-list-metric strong { display: block; color: #111827; }
        .admin-reports-list-metric span { color: #64748b; font-size: .78rem; }
        .admin-reports-area-list { display: flex; flex-direction: column; gap: 14px; }
        .admin-reports-area-item { display: flex; flex-direction: column; gap: 8px; }
        .admin-reports-area-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
        .admin-reports-area-name { font-weight: 700; color: #111827; }
        .admin-reports-area-total { color: #111827; font-size: .82rem; font-weight: 700; }
        .admin-reports-area-track { width: 100%; height: 12px; background: #e5e7eb; border-radius: 999px; overflow: hidden; }
        .admin-reports-area-bar { height: 100%; border-radius: 999px; background: linear-gradient(90deg,#16a34a 0%,#22c55e 100%); }
        .admin-reports-area-meta { display: flex; align-items: center; justify-content: space-between; gap: 12px; color: #64748b; font-size: .78rem; }
        .admin-reports-template-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 16px; }
        .admin-reports-template { display: flex; flex-direction: column; gap: 12px; border: 1px solid #e5e7eb; border-radius: 16px; padding: 18px; background: #fff; transition: .2s ease; }
        .admin-reports-template:hover { border-color: #bbf7d0; box-shadow: 0 8px 18px rgba(22,163,74,.08); }
        .admin-reports-template-icon { width: 44px; height: 44px; border-radius: 14px; display: inline-flex; align-items: center; justify-content: center; background: #ecfdf5; color: #16a34a; }
        .admin-reports-template-icon svg { width: 20px; height: 20px; }
        .admin-reports-template-title { font-weight: 700; color: #111827; }
        .admin-reports-template-copy { color: #64748b; font-size: .84rem; line-height: 1.5; }
        .admin-reports-template-action { margin-top: auto; }
        body.app-theme-dark .admin-dashboard { background: linear-gradient(180deg, #020617 0%, #0f172a 100%); }
        body.app-theme-dark .admin-dashboard-sidebar { background: #0b1220; border-right-color: rgba(148, 163, 184, 0.16); }
        body.app-theme-dark .admin-dashboard-brand-title,
        body.app-theme-dark .admin-dashboard-title,
        body.app-theme-dark .admin-dashboard-panel-title,
        body.app-theme-dark .admin-dashboard-profile-name,
        body.app-theme-dark .admin-dashboard-user-name,
        body.app-theme-dark .admin-dashboard-list-title,
        body.app-theme-dark .admin-dashboard-progress-name,
        body.app-theme-dark .admin-dashboard-card-value,
        body.app-theme-dark .admin-dashboard-user-stat-value,
        body.app-theme-dark .admin-stats-card-value,
        body.app-theme-dark .admin-stats-chart-title,
        body.app-theme-dark .admin-stats-category-name,
        body.app-theme-dark .admin-stats-area-value,
        body.app-theme-dark .admin-reports-card-value,
        body.app-theme-dark .admin-reports-list-name,
        body.app-theme-dark .admin-reports-list-metric strong,
        body.app-theme-dark .admin-reports-area-name,
        body.app-theme-dark .admin-reports-area-total,
        body.app-theme-dark .admin-reports-template-title { color: #f8fafc; }
        body.app-theme-dark .admin-dashboard-brand-subtitle,
        body.app-theme-dark .admin-dashboard-user-email,
        body.app-theme-dark .admin-dashboard-list-meta,
        body.app-theme-dark .admin-dashboard-profile-role,
        body.app-theme-dark .admin-dashboard-card-title,
        body.app-theme-dark .admin-dashboard-panel-copy,
        body.app-theme-dark .admin-dashboard-progress-meta,
        body.app-theme-dark .admin-dashboard-muted,
        body.app-theme-dark .admin-dashboard-subtitle,
        body.app-theme-dark .admin-dashboard-card-foot,
        body.app-theme-dark .admin-dashboard-user-stat-label,
        body.app-theme-dark .admin-stats-card-label,
        body.app-theme-dark .admin-stats-card-meta,
        body.app-theme-dark .admin-stats-chart-copy,
        body.app-theme-dark .admin-stats-category-sub,
        body.app-theme-dark .admin-stats-area-name,
        body.app-theme-dark .admin-reports-card-label,
        body.app-theme-dark .admin-reports-card-meta,
        body.app-theme-dark .admin-reports-list-copy,
        body.app-theme-dark .admin-reports-list-sub,
        body.app-theme-dark .admin-reports-list-metric span,
        body.app-theme-dark .admin-reports-area-meta,
        body.app-theme-dark .admin-reports-template-copy,
        body.app-theme-dark .admin-dashboard-table td,
        body.app-theme-dark .admin-dashboard-table td.col-date-cell { color: #94a3b8; }
        body.app-theme-dark .admin-dashboard-card,
        body.app-theme-dark .admin-dashboard-panel,
        body.app-theme-dark .admin-dashboard-table,
        body.app-theme-dark .admin-dashboard-user-card,
        body.app-theme-dark .admin-dashboard-profile-trigger,
        body.app-theme-dark .admin-dashboard-profile-menu,
        body.app-theme-dark .admin-stats-card,
        body.app-theme-dark .admin-stats-chart-card,
        body.app-theme-dark .admin-reports-card,
        body.app-theme-dark .admin-reports-chip,
        body.app-theme-dark .admin-reports-template { background: #0f172a; border-color: rgba(148, 163, 184, 0.16); box-shadow: 0 18px 34px rgba(2, 6, 23, 0.34); color: #e2e8f0; }
        body.app-theme-dark .admin-dashboard-link { color: #cbd5e1; }
        body.app-theme-dark .admin-dashboard-link:hover { background: #162132; border-color: rgba(45, 212, 191, 0.2); color: #f8fafc; }
        body.app-theme-dark .admin-dashboard-settings { border-top-color: rgba(148, 163, 184, 0.16); }
        body.app-theme-dark .admin-dashboard-filter-block,
        body.app-theme-dark .admin-dashboard-user-stat { background: #111827; border-color: rgba(148, 163, 184, 0.14); }
        body.app-theme-dark .admin-dashboard-search-form input,
        body.app-theme-dark .admin-dashboard-role-select { background: #020617; border-color: rgba(148, 163, 184, 0.18); color: #e2e8f0; }
        body.app-theme-dark .admin-dashboard-search-form input::placeholder { color: #64748b; }
        body.app-theme-dark .admin-dashboard-table th { color: #94a3b8; border-bottom-color: rgba(148, 163, 184, 0.14); }
        body.app-theme-dark .admin-dashboard-table td,
        body.app-theme-dark .admin-dashboard-list-item,
        body.app-theme-dark .admin-stats-category-item,
        body.app-theme-dark .admin-reports-list-item { border-color: rgba(148, 163, 184, 0.12); }
        body.app-theme-dark .admin-dashboard-list-icon,
        body.app-theme-dark .admin-stats-category-icon,
        body.app-theme-dark .admin-reports-rank,
        body.app-theme-dark .admin-reports-template-icon { background: #111827; color: #cbd5e1; }
        body.app-theme-dark .admin-dashboard-empty { background: #020617; border-color: rgba(45, 212, 191, 0.24); color: #94a3b8; }
        body.app-theme-dark .admin-dashboard-map { border-color: rgba(148, 163, 184, 0.16); }
        body.app-theme-dark .admin-dashboard-profile-menu .dropdown-item { color: #e2e8f0; }
        body.app-theme-dark .admin-dashboard-profile-menu .dropdown-item:hover { background: #162132; color: #f8fafc; }
        body.app-theme-dark .admin-dashboard-profile-trigger:hover,
        body.app-theme-dark .admin-dashboard-profile-trigger.show { background: #162132; border-color: rgba(45, 212, 191, 0.2); color: #f8fafc; }
        body.app-theme-dark .admin-reports-chip { color: #cbd5e1; }
        body.app-theme-dark .admin-reports-area-track { background: #1f2937; }
        body.app-theme-dark .pagination .page-link { color: #cbd5e1; background: #0f172a; border-color: rgba(148, 163, 184, 0.18); }
        body.app-theme-dark .pagination .page-link:hover { color: #f8fafc; background: #162132; border-color: rgba(45, 212, 191, 0.26); }
        body.app-theme-dark .pagination .active .page-link { background: #0f766e; border-color: #0f766e; color: #ffffff; }
        body.app-theme-dark .leaflet-popup-content-wrapper,
        body.app-theme-dark .leaflet-popup-tip { background: #0f172a; color: #e2e8f0; }
        body.app-theme-dark .leaflet-popup-content a { color: #5eead4; }
        @media (max-width:1199.98px) { .admin-dashboard-stats, .admin-dashboard-user-grid, .admin-stats-grid { grid-template-columns: repeat(2,minmax(0,1fr)); } .admin-dashboard-grid, .admin-stats-chart-grid { grid-template-columns: 1fr; } }
        @media (max-width:1199.98px) { .admin-reports-grid { grid-template-columns: repeat(2,minmax(0,1fr)); } .admin-reports-layout, .admin-reports-template-grid { grid-template-columns: 1fr; } }
        @media (max-width:991.98px) { .admin-dashboard { grid-template-columns: 1fr; } .admin-dashboard-sidebar { border-right: 0; border-bottom: 1px solid #e5e7eb; } }
        @media (max-width:767.98px) { .admin-dashboard-main { padding: 16px; } .admin-dashboard-user-head, .admin-dashboard-page-head, .admin-reports-toolbar { flex-direction: column; align-items: stretch; } .admin-dashboard-stats, .admin-dashboard-user-grid, .admin-stats-grid, .admin-stats-area-list, .admin-reports-grid, .admin-reports-template-grid { grid-template-columns: 1fr; } .admin-dashboard-role-form { align-items: stretch; } .admin-dashboard-role-select { width: 100%; } .admin-stats-chart-box { height: 280px; } .admin-dashboard-toolbar, .admin-reports-toolbar-actions { justify-content: stretch; } .admin-dashboard-clock, .admin-dashboard-profile-trigger, .admin-reports-chip { width: 100%; flex-basis: auto; } .admin-dashboard-table--complaints td.col-actions-cell .btn { min-width: 0; } }
    </style>
@endpush

@section('content')
@php
    $currentSection = request('section', 'dashboard');
    $completedCount = max(0, ($stats['total'] ?? 0) - (($stats['process'] ?? 0) + ($stats['rejected'] ?? 0) + ($stats['pending'] ?? 0)));
    $mapPoints = ($activeComplaintLocations ?? collect())->map(function ($complaint) {
        return [
            'id' => $complaint->id,
            'title' => $complaint->title,
            'status' => $complaint->status,
            'latitude' => (float) $complaint->latitude,
            'longitude' => (float) $complaint->longitude,
            'address' => collect([$complaint->street_address, $complaint->village, $complaint->district, $complaint->city, $complaint->province])->filter()->join(', '),
            'detailUrl' => route('admin.complaints.show', $complaint),
        ];
    })->values();
    $topCategoryTotal = max(1, (int) (($categoryStats ?? collect())->max('total') ?? 1));
    $topLocationTotal = max(1, (int) (($locationStats ?? collect())->max('total') ?? 1));
    $topMonthTotal = max(1, (int) (($monthlyStats ?? collect())->max('total') ?? 1));
    $statisticsOverview = $statisticsOverview ?? [];
    $monthlyTrendStats = $monthlyTrendStats ?? collect();
    $categoryBreakdownStats = $categoryBreakdownStats ?? collect();
    $areaDistributionStats = $areaDistributionStats ?? collect();
    $responseTimeStats = $responseTimeStats ?? collect();
    $resolutionRateStats = $resolutionRateStats ?? collect();
    $adminUser = auth()->user();
    $navItems = [
        'dashboard' => ['label' => 'Dashboard', 'icon' => 'dashboard'],
        'pengaduan' => ['label' => 'Pengaduan', 'icon' => 'complaints'],
        'petugas' => ['label' => 'Daftar User', 'icon' => 'users'],
        'statistik' => ['label' => 'Statistik', 'icon' => 'stats'],
        'laporan' => ['label' => 'Laporan', 'icon' => 'reports'],
    ];
    $sectionCopy = [
        'dashboard' => 'Pantau ringkasan operasional SIPAMAS dari satu tempat.',
        'pengaduan' => 'Kelola laporan aktif dan pantau titik pengaduan lapangan.',
        'petugas' => 'Kelola daftar user, cari akun, dan atur role akses.',
        'statistik' => 'Lihat analisis performa, distribusi area, dan tren pengaduan.',
        'laporan' => 'Siapkan rekap bulanan dan akses ekspor data administrasi.',
    ][$currentSection] ?? 'Pantau ringkasan operasional SIPAMAS dari satu tempat.';
    $iconSvg = function (string $name): string {
        return match ($name) {
            'dashboard' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 13h7v8H3z"/><path d="M14 3h7v18h-7z"/><path d="M3 3h7v7H3z"/></svg>',
            'complaints' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
            'users' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
            'stats' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20V10"/><path d="M18 20V4"/><path d="M6 20v-6"/></svg>',
            'reports' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M16 13H8"/><path d="M16 17H8"/><path d="M10 9H8"/></svg>',
            'settings' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.07-1l2.02-1.57-2-3.46-2.45 1a7 7 0 0 0-1.73-1l-.37-2.61h-4l-.37 2.61a7 7 0 0 0-1.73 1l-2.45-1-2 3.46L5.07 11a7 7 0 0 0 0 2l-2.02 1.57 2 3.46 2.45-1a7 7 0 0 0 1.73 1l.37 2.61h4l.37-2.61a7 7 0 0 0 1.73-1l2.45 1 2-3.46L18.93 13c.05-.33.07-.66.07-1z"/></svg>',
            'search' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.35-4.35"/></svg>',
            'bell' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 17h5l-1.4-1.4A2 2 0 0 1 18 14.2V11a6 6 0 0 0-12 0v3.2a2 2 0 0 1-.6 1.4L4 17h5"/><path d="M9 17a3 3 0 0 0 6 0"/></svg>',
            'clock' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>',
            'check' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6 9 17l-5-5"/></svg>',
            'warning' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 9v4"/><path d="M12 17h.01"/><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/></svg>',
            'trash' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>',
            'droplets' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.32 0L12 2.69z"/></svg>',
            'trees' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22V11"/><path d="M8 11h8"/><path d="m12 2 5 7H7l5-7z"/><path d="m12 6 6 9H6l6-9z"/></svg>',
            'factory' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 21h18"/><path d="M5 21V8l7 4V8l7 4v9"/><path d="M9 21v-4"/><path d="M13 21v-4"/><path d="M17 21v-4"/></svg>',
            default => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg>',
        };
    };
    $categoryIconName = function (string $label): string {
        $name = strtolower($label);
        return match (true) {
            str_contains($name, 'sampah'), str_contains($name, 'limbah') => 'trash',
            str_contains($name, 'air'), str_contains($name, 'drainase') => 'droplets',
            str_contains($name, 'udara'), str_contains($name, 'asap'), str_contains($name, 'industri') => 'factory',
            str_contains($name, 'hijau'), str_contains($name, 'pohon'), str_contains($name, 'penebangan') => 'trees',
            default => 'warning',
        };
    };
@endphp
@if(auth()->user()->role === 'admin')
    <div class="admin-dashboard-page">
        <div class="admin-dashboard">
            <aside class="admin-dashboard-sidebar">
                <div class="admin-dashboard-brand">
                    <span class="admin-dashboard-brand-mark">{!! $iconSvg('dashboard') !!}</span>
                    <div>
                        <div class="admin-dashboard-brand-title">SIPAMAS</div>
                        <div class="admin-dashboard-brand-subtitle">Admin dashboard</div>
                    </div>
                </div>
                <div class="admin-dashboard-nav">
                    <div class="admin-dashboard-nav-label">Navigation</div>
                    @foreach($navItems as $key => $item)
                        <a href="{{ route('dashboard', ['section' => $key]) }}" class="admin-dashboard-link {{ $currentSection === $key ? 'active' : '' }}">
                            {!! $iconSvg($item['icon']) !!}
                            <span>{{ $item['label'] }}</span>
                        </a>
                    @endforeach
                </div>
                <div class="admin-dashboard-spacer"></div>
                <div class="admin-dashboard-settings">
                    <a href="{{ route('setting') }}" class="admin-dashboard-link">{!! $iconSvg('settings') !!}<span>Pengaturan</span></a>
                </div>
            </aside>

            <main class="admin-dashboard-main">
                <section class="admin-dashboard-page-head">
                    <div>
                        <h1 class="admin-dashboard-title">{{ $navItems[$currentSection]['label'] ?? 'Dashboard' }}</h1>
                        <p class="admin-dashboard-subtitle">
                            {{ $sectionCopy }}
                            @if(($dashboardSearch ?? '') !== '')
                                Hasil pencarian untuk "{{ $dashboardSearch }}".
                            @endif
                        </p>
                    </div>
                    <div class="admin-dashboard-toolbar">
                        <div class="admin-dashboard-clock">
                            <div class="admin-dashboard-clock-label">Waktu Sekarang</div>
                            <div id="admin-clock-time" class="admin-dashboard-clock-time">--:--:--</div>
                            <div id="admin-clock-date" class="admin-dashboard-clock-date">Memuat tanggal...</div>
                        </div>
                        <div class="dropdown">
                            <button class="admin-dashboard-profile-trigger dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <span class="admin-dashboard-profile-avatar">
                                    @if($adminUser?->profile_photo_url)
                                        <img src="{{ $adminUser->profile_photo_url }}" alt="Foto {{ $adminUser->name }}">
                                    @else
                                        {{ strtoupper(mb_substr($adminUser->name ?? 'A', 0, 1)) }}
                                    @endif
                                </span>
                                <span class="admin-dashboard-profile-meta">
                                    <span class="admin-dashboard-profile-label d-block">Admin</span>
                                    <span class="admin-dashboard-profile-name d-block">{{ $adminUser->name ?? 'Admin' }}</span>
                                </span>
                            </button>
                            <div class="dropdown-menu dropdown-menu-end admin-dashboard-profile-menu">
                                <a class="dropdown-item" href="{{ route('profil.edit') }}">Edit Profile</a>
                                <form method="POST" action="{{ route('logout') }}">
                                    @csrf
                                    <button type="submit" class="dropdown-item dropdown-item-danger w-100 text-start">Logout</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </section>

                @if($currentSection === 'dashboard')
                    <section class="admin-dashboard-stats">
                        <article class="admin-dashboard-card"><div class="admin-dashboard-card-head"><div><div class="admin-dashboard-card-title">Total Pengaduan</div><div class="admin-dashboard-card-value">{{ $stats['total'] ?? 0 }}</div><div class="admin-dashboard-card-foot"><span class="admin-dashboard-card-trend-up">Data live</span><span>semua laporan</span></div></div><span class="admin-dashboard-card-icon" style="background:#dbeafe;color:#2563eb;">{!! $iconSvg('complaints') !!}</span></div></article>
                        <article class="admin-dashboard-card"><div class="admin-dashboard-card-head"><div><div class="admin-dashboard-card-title">Sedang Diproses</div><div class="admin-dashboard-card-value text-primary">{{ $stats['process'] ?? 0 }}</div><div class="admin-dashboard-card-foot"><span class="admin-dashboard-card-trend-up">Aktif</span><span>butuh tindak lanjut</span></div></div><span class="admin-dashboard-card-icon" style="background:#ffedd5;color:#ea580c;">{!! $iconSvg('clock') !!}</span></div></article>
                        <article class="admin-dashboard-card"><div class="admin-dashboard-card-head"><div><div class="admin-dashboard-card-title">Selesai Ditangani</div><div class="admin-dashboard-card-value text-success">{{ $completedCount }}</div><div class="admin-dashboard-card-foot"><span class="admin-dashboard-card-trend-up">Resolved</span><span>laporan ditutup</span></div></div><span class="admin-dashboard-card-icon" style="background:#dcfce7;color:#16a34a;">{!! $iconSvg('check') !!}</span></div></article>
                        <article class="admin-dashboard-card"><div class="admin-dashboard-card-head"><div><div class="admin-dashboard-card-title">Perlu Perhatian</div><div class="admin-dashboard-card-value text-danger">{{ ($stats['pending'] ?? 0) + ($stats['rejected'] ?? 0) }}</div><div class="admin-dashboard-card-foot"><span class="admin-dashboard-card-trend-down">Alert</span><span>pending dan ditolak</span></div></div><span class="admin-dashboard-card-icon" style="background:#fee2e2;color:#dc2626;">{!! $iconSvg('warning') !!}</span></div></article>
                    </section>
                @endif

                @if($currentSection === 'statistik')
                    <section class="admin-stats-grid">
                        <article class="admin-stats-card">
                            <div class="admin-stats-card-label">Total Pengaduan</div>
                            <div class="admin-stats-card-value">{{ number_format($statisticsOverview['total']['value'] ?? 0, 0, ',', '.') }}</div>
                            <div class="admin-stats-card-meta">
                                @php $change = $statisticsOverview['total']['change'] ?? null; @endphp
                                @if(!is_null($change))
                                    <span class="admin-stats-card-change {{ $change >= 0 ? 'up' : 'down' }}">{{ $change >= 0 ? '+' : '' }}{{ $change }}%</span>
                                @endif
                                <span>{{ $statisticsOverview['total']['copy'] ?? 'vs periode lalu' }}</span>
                            </div>
                        </article>
                        <article class="admin-stats-card">
                            <div class="admin-stats-card-label">Tingkat Penyelesaian</div>
                            <div class="admin-stats-card-value good">{{ number_format((float) ($statisticsOverview['resolution_rate']['value'] ?? 0), 1, ',', '.') }}%</div>
                            <div class="admin-stats-card-meta">
                                @php $change = $statisticsOverview['resolution_rate']['change'] ?? null; @endphp
                                @if(!is_null($change))
                                    <span class="admin-stats-card-change {{ $change >= 0 ? 'up' : 'down' }}">{{ $change >= 0 ? '+' : '' }}{{ $change }}%</span>
                                @endif
                                <span>{{ $statisticsOverview['resolution_rate']['copy'] ?? 'tingkat penyelesaian' }}</span>
                            </div>
                        </article>
                        <article class="admin-stats-card">
                            <div class="admin-stats-card-label">Waktu Respon Rata-rata</div>
                            <div class="admin-stats-card-value">{{ number_format((float) ($statisticsOverview['avg_response_days']['value'] ?? 0), 1, ',', '.') }} hari</div>
                            <div class="admin-stats-card-meta">
                                @php $change = $statisticsOverview['avg_response_days']['change'] ?? null; @endphp
                                @if(!is_null($change))
                                    <span class="admin-stats-card-change {{ $change >= 0 ? 'up' : 'down' }}">{{ $change >= 0 ? '+' : '' }}{{ $change }}%</span>
                                @endif
                                <span>{{ $statisticsOverview['avg_response_days']['copy'] ?? 'respon rata-rata' }}</span>
                            </div>
                        </article>
                        <article class="admin-stats-card">
                            <div class="admin-stats-card-label">Area Aktif</div>
                            <div class="admin-stats-card-value">{{ number_format($statisticsOverview['active_areas']['value'] ?? 0, 0, ',', '.') }}</div>
                            <div class="admin-stats-card-meta">
                                <span>{{ $statisticsOverview['active_areas']['copy'] ?? 'wilayah aktif' }}</span>
                            </div>
                        </article>
                    </section>

                    <section class="admin-stats-chart-grid">
                        <div class="admin-stats-chart-card">
                            <div class="admin-stats-chart-head">
                                <div>
                                    <h3 class="admin-stats-chart-title">Tren Pengaduan Bulanan</h3>
                                    <p class="admin-stats-chart-copy">Perbandingan total, selesai, dan pending enam bulan terakhir.</p>
                                </div>
                                <span class="admin-dashboard-tag">6 bulan</span>
                            </div>
                            @if($monthlyTrendStats->isNotEmpty())
                                <div class="admin-stats-chart-box">
                                    <canvas id="monthly-trend-chart"></canvas>
                                </div>
                            @else
                                <div class="admin-dashboard-empty">Belum ada data tren bulanan.</div>
                            @endif
                        </div>
                        <div class="admin-stats-chart-card">
                            <div class="admin-stats-chart-head">
                                <div>
                                    <h3 class="admin-stats-chart-title">Distribusi Area</h3>
                                    <p class="admin-stats-chart-copy">Wilayah dengan kontribusi laporan terbesar.</p>
                                </div>
                                <span class="admin-dashboard-tag">Sebaran</span>
                            </div>
                            @if($areaDistributionStats->isNotEmpty())
                                <div class="admin-stats-chart-box" style="height:250px;">
                                    <canvas id="area-distribution-chart"></canvas>
                                </div>
                                <div class="admin-stats-area-list">
                                    @foreach($areaDistributionStats as $area)
                                        <div class="admin-stats-area-item">
                                            <span class="admin-stats-area-swatch" style="background-color: {{ $area['color'] }}"></span>
                                            <span class="admin-stats-area-name">{{ $area['name'] }}</span>
                                            <span class="admin-stats-area-value">{{ number_format((float) $area['value'], 1, ',', '.') }}%</span>
                                        </div>
                                    @endforeach
                                </div>
                            @else
                                <div class="admin-dashboard-empty">Belum ada data area.</div>
                            @endif
                        </div>
                    </section>

                    <section class="admin-stats-chart-grid">
                        <div class="admin-stats-chart-card">
                            <div class="admin-stats-chart-head">
                                <div>
                                    <h3 class="admin-stats-chart-title">Statistik Kategori</h3>
                                    <p class="admin-stats-chart-copy">Kategori pengaduan paling dominan saat ini.</p>
                                </div>
                                <span class="admin-dashboard-tag">Top 5</span>
                            </div>
                            @if($categoryBreakdownStats->isNotEmpty())
                                <div class="admin-stats-category-list">
                                    @foreach($categoryBreakdownStats as $category)
                                        <div class="admin-stats-category-item">
                                            <div class="admin-stats-category-main">
                                                <span class="admin-stats-category-icon">{!! $iconSvg($categoryIconName($category['category'])) !!}</span>
                                                <div>
                                                    <div class="admin-stats-category-name">{{ $category['category'] }}</div>
                                                    <div class="admin-stats-category-sub">{{ number_format($category['count'], 0, ',', '.') }} pengaduan</div>
                                                </div>
                                            </div>
                                            <div class="admin-stats-category-share">{{ number_format((float) $category['share'], 1, ',', '.') }}%</div>
                                        </div>
                                    @endforeach
                                </div>
                            @else
                                <div class="admin-dashboard-empty">Belum ada statistik kategori.</div>
                            @endif
                        </div>
                        <div class="admin-stats-chart-card">
                            <div class="admin-stats-chart-head">
                                <div>
                                    <h3 class="admin-stats-chart-title">Waktu Respon per Kategori</h3>
                                    <p class="admin-stats-chart-copy">Estimasi hari penanganan berdasarkan kategori laporan.</p>
                                </div>
                                <span class="admin-dashboard-tag">Rata-rata hari</span>
                            </div>
                            @if($responseTimeStats->isNotEmpty())
                                <div class="admin-stats-chart-box">
                                    <canvas id="response-time-chart"></canvas>
                                </div>
                            @else
                                <div class="admin-dashboard-empty">Belum ada data waktu respon.</div>
                            @endif
                        </div>
                    </section>

                    <section class="admin-stats-chart-card mb-4">
                        <div class="admin-stats-chart-head">
                            <div>
                                <h3 class="admin-stats-chart-title">Tingkat Penyelesaian Bulanan</h3>
                                <p class="admin-stats-chart-copy">Persentase laporan selesai dari laporan yang masuk tiap bulan.</p>
                            </div>
                            <span class="admin-dashboard-tag">Resolution rate</span>
                        </div>
                        @if($resolutionRateStats->isNotEmpty())
                            <div class="admin-stats-chart-box">
                                <canvas id="resolution-rate-chart"></canvas>
                            </div>
                        @else
                            <div class="admin-dashboard-empty">Belum ada data tingkat penyelesaian.</div>
                        @endif
                    </section>

                    <section class="admin-dashboard-grid">
                        <div class="admin-dashboard-panel">
                            <div class="admin-dashboard-panel-head"><div><div class="admin-dashboard-panel-title">Kategori Pengaduan</div><p class="admin-dashboard-panel-copy">Distribusi kategori paling aktif di SIPAMAS.</p></div><span class="admin-dashboard-tag">Top kategori</span></div>
                            @if($categoryStats->isNotEmpty())
                                <div class="admin-dashboard-progress-list">
                                    @foreach($categoryStats as $category)
                                        <div><div class="admin-dashboard-progress-head"><div class="admin-dashboard-progress-name">{{ $category->label }}</div><div class="admin-dashboard-progress-meta">{{ $category->total }} laporan</div></div><div class="admin-dashboard-progress-track"><div class="admin-dashboard-progress-bar" style="width: {{ min(100, round(($category->total / $topCategoryTotal) * 100)) }}%"></div></div></div>
                                    @endforeach
                                </div>
                            @else
                                <div class="admin-dashboard-empty">Belum ada statistik kategori.</div>
                            @endif
                        </div>
                        <div class="admin-dashboard-panel">
                            <div class="admin-dashboard-panel-head"><div><div class="admin-dashboard-panel-title">Lokasi Teratas</div><p class="admin-dashboard-panel-copy">Sebaran kota atau kabupaten dengan laporan terbanyak.</p></div><span class="admin-dashboard-tag">Live area</span></div>
                            @if($locationStats->isNotEmpty())
                                <div class="admin-dashboard-progress-list">
                                    @foreach($locationStats as $location)
                                        <div><div class="admin-dashboard-progress-head"><div class="admin-dashboard-progress-name">{{ $location->label }}</div><div class="admin-dashboard-progress-meta">{{ $location->total }}</div></div><div class="admin-dashboard-progress-track"><div class="admin-dashboard-progress-bar" style="width: {{ min(100, round(($location->total / $topLocationTotal) * 100)) }}%"></div></div></div>
                                    @endforeach
                                </div>
                            @else
                                <div class="admin-dashboard-empty">Belum ada data lokasi.</div>
                            @endif
                        </div>
                    </section>
                @endif

                @if(in_array($currentSection, ['dashboard', 'pengaduan']))
                    <section class="admin-dashboard-grid">
                        <div class="admin-dashboard-panel">
                            <div class="admin-dashboard-panel-head"><div><div class="admin-dashboard-panel-title">Peta Pengaduan Aktif</div><p class="admin-dashboard-panel-copy">Pantau pengaduan pending dan in process secara geografis.</p></div><span class="admin-dashboard-tag">{{ ($activeComplaintLocations ?? collect())->count() }} titik</span></div>
                            <div id="dashboard-active-map" class="admin-dashboard-map"></div>
                        </div>
                        <div class="admin-dashboard-panel">
                            <div class="admin-dashboard-panel-head"><div><div class="admin-dashboard-panel-title">Pengaduan Terbaru</div><p class="admin-dashboard-panel-copy">Daftar cepat untuk tindak lanjut admin.</p></div><a href="{{ route('dashboard', ['section' => 'pengaduan']) }}#kelola-pengaduan" class="btn btn-outline-secondary btn-sm">Lihat Semua</a></div>
                            @if($complaints->take(5)->isNotEmpty())
                                <div class="admin-dashboard-list">
                                    @foreach($complaints->take(5) as $complaint)
                                        @php
                                            $statusTheme = match($complaint->status) {
                                                'approved', 'process' => 'process',
                                                'rejected' => 'rejected',
                                                'done' => 'done',
                                                default => 'pending'
                                            };
                                            $statusLabel = match($complaint->status) {
                                                'approved', 'process' => 'Diproses',
                                                'rejected' => 'Ditolak',
                                                'done' => 'Selesai',
                                                default => 'Pending'
                                            };
                                        @endphp
                                        <article class="admin-dashboard-list-item">
                                            <span class="admin-dashboard-list-icon">{!! $iconSvg('complaints') !!}</span>
                                            <div class="admin-dashboard-list-main">
                                                <div class="admin-dashboard-list-title">{{ $complaint->title }}</div>
                                                <div class="admin-dashboard-list-meta">{{ $complaint->user->name ?? '-' }} | {{ $complaint->created_at->format('d M Y') }}</div>
                                                <div class="admin-dashboard-badges"><span class="admin-dashboard-badge {{ $statusTheme }}">{{ $statusLabel }}</span><span class="admin-dashboard-badge category">{{ $complaint->category->name ?? 'Tanpa kategori' }}</span></div>
                                                <div class="admin-dashboard-inline-actions">
                                                    <a href="{{ route('admin.complaints.show', $complaint) }}" class="btn btn-sm btn-outline-secondary">Detail</a>
                                                    <a href="{{ route('admin.complaints.edit', $complaint) }}" class="btn btn-sm btn-primary">Tindak Lanjut</a>
                                                </div>
                                            </div>
                                        </article>
                                    @endforeach
                                </div>
                            @else
                                <div class="admin-dashboard-empty">Belum ada pengaduan.</div>
                            @endif
                        </div>
                    </section>
                @endif

                @if(($currentSection ?? 'dashboard') === 'dashboard')
                    <section id="pesan-kontak-admin" class="admin-dashboard-panel mb-4">
                        <div class="admin-dashboard-panel-head">
                            <div>
                                <div class="admin-dashboard-panel-title">Pesan Kontak Masuk</div>
                                <p class="admin-dashboard-panel-copy">Pesan dari halaman Kontak SIPAMAS akan masuk ke notifikasi admin dan diringkas di sini.</p>
                            </div>
                            <a href="{{ route('notifications.index') }}" class="btn btn-outline-secondary btn-sm">Lihat Semua Notifikasi</a>
                        </div>
                        @if(($adminContactNotifications ?? collect())->isNotEmpty())
                            <div class="admin-dashboard-list">
                                @foreach($adminContactNotifications as $contactNotification)
                                    @php
                                        $contactData = $contactNotification->data;
                                    @endphp
                                    <article class="admin-dashboard-list-item">
                                        <span class="admin-dashboard-list-icon">{!! $iconSvg('bell') !!}</span>
                                        <div class="admin-dashboard-list-main">
                                            <div class="admin-dashboard-list-title">{{ $contactData['title'] ?? 'Pesan Kontak SIPAMAS' }}</div>
                                            <div class="admin-dashboard-list-meta">
                                                {{ $contactData['sender_name'] ?? 'User' }} | {{ $contactData['sender_email'] ?? '-' }} | {{ $contactNotification->created_at->diffForHumans() }}
                                            </div>
                                            <div class="admin-dashboard-list-copy">
                                                {{ \Illuminate\Support\Str::limit((string) ($contactData['message'] ?? '-'), 180) }}
                                            </div>
                                            <div class="admin-dashboard-inline-actions">
                                                <a href="{{ route('notifications.index') }}" class="btn btn-sm btn-outline-secondary">Buka Notifikasi</a>
                                                @if(is_null($contactNotification->read_at))
                                                    <span class="admin-dashboard-badge pending">Baru</span>
                                                @else
                                                    <span class="admin-dashboard-badge category">Sudah dibaca</span>
                                                @endif
                                            </div>
                                        </div>
                                    </article>
                                @endforeach
                            </div>
                        @else
                            <div class="admin-dashboard-empty">Belum ada pesan dari halaman kontak.</div>
                        @endif
                    </section>
                @endif

                @if(in_array($currentSection, ['dashboard', 'petugas']))
                    <section class="admin-dashboard-panel admin-dashboard-panel-flat mb-4">
                        <div class="admin-dashboard-panel-head"><div><div class="admin-dashboard-panel-title">Daftar User</div><p class="admin-dashboard-panel-copy">Cari user dan ubah role menjadi user, admin, atau blacklisted langsung dari dashboard.</p></div><a href="{{ route('dashboard', ['section' => 'petugas']) }}" class="btn btn-outline-secondary btn-sm">Kelola User Lengkap</a></div>
                        @if (session('user_role_status'))
                            <div class="alert alert-success mb-3">{{ session('user_role_status') }}</div>
                        @endif
                        @if (session('user_role_error'))
                            <div class="alert alert-danger mb-3">{{ session('user_role_error') }}</div>
                        @endif
                        <form method="GET" action="{{ route('dashboard') }}" class="admin-dashboard-search-form">
                            <input type="hidden" name="section" value="petugas">
                            <input type="text" name="user_q" value="{{ $dashboardUserSearch ?? '' }}" placeholder="Cari nama atau email user">
                            <button type="submit" class="btn btn-primary">Cari</button>
                            <a href="{{ route('dashboard', ['section' => 'petugas']) }}" class="btn btn-outline-secondary">Reset</a>
                        </form>
                        @if($dashboardUsers->count() > 0)
                            <div class="admin-dashboard-table">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Nama</th>
                                            <th>Email</th>
                                            <th>Role</th>
                                            <th>Total Aduan</th>
                                            <th>Terdaftar</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($dashboardUsers as $userRow)
                                            <tr>
                                                <td>
                                                    <div class="fw-semibold">{{ $userRow->name }}</div>
                                                </td>
                                                <td>{{ $userRow->email }}</td>
                                                <td>
                                                    <span class="admin-dashboard-badge {{ $userRow->role }}">
                                                        {{ ucfirst($userRow->role) }}
                                                    </span>
                                                </td>
                                                <td>{{ $userRow->complaints_count }}</td>
                                                <td>{{ $userRow->created_at?->format('d M Y') }}</td>
                                                <td>
                                                    <form method="POST" action="{{ route('admin.users.role.update', $userRow) }}" class="admin-dashboard-role-form">
                                                        @csrf
                                                        @method('PATCH')
                                                        <select name="role" class="admin-dashboard-role-select" {{ auth()->id() === $userRow->id ? 'disabled' : '' }}>
                                                            <option value="user" {{ $userRow->role === 'user' ? 'selected' : '' }}>User</option>
                                                            <option value="admin" {{ $userRow->role === 'admin' ? 'selected' : '' }}>Admin</option>
                                                            <option value="blacklisted" {{ $userRow->role === 'blacklisted' ? 'selected' : '' }}>Blacklisted</option>
                                                        </select>
                                                        @if(auth()->id() === $userRow->id)
                                                            <button type="button" class="btn btn-sm btn-outline-secondary" disabled>Akun aktif</button>
                                                        @else
                                                            <button type="submit" class="btn btn-sm btn-primary">Simpan</button>
                                                        @endif
                                                    </form>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            <div class="mt-3">
                                {{ $dashboardUsers->links() }}
                            </div>
                        @else
                            <div class="admin-dashboard-empty">Belum ada user untuk dikelola.</div>
                        @endif
                    </section>
                @endif

                @if($currentSection === 'laporan')
                    <section class="admin-reports-toolbar">
                        <div>
                            <div class="admin-dashboard-panel-title">Laporan Lengkap</div>
                            <p class="admin-dashboard-panel-copy">Tampilan laporan dirapikan mengikuti referensi dashboard yang Anda lampirkan.</p>
                        </div>
                        <div class="admin-reports-toolbar-actions">
                            <span class="admin-reports-chip">{!! $iconSvg('clock') !!}<span>Periode 6 bulan terakhir</span></span>
                            <a href="{{ route('admin.complaints.export.csv') }}" class="btn btn-success admin-reports-export-btn">{!! $iconSvg('reports') !!} Export Laporan</a>
                        </div>
                    </section>

                    <section class="admin-reports-grid">
                        <article class="admin-reports-card">
                            <div class="admin-reports-card-label">Total Pengaduan</div>
                            <div class="admin-reports-card-value">{{ number_format($stats['total'] ?? 0, 0, ',', '.') }}</div>
                            <div class="admin-reports-card-meta">
                                @php $change = $statisticsOverview['total']['change'] ?? null; @endphp
                                @if(!is_null($change))
                                    <span class="admin-reports-card-change {{ $change >= 0 ? 'up' : 'down' }}">{{ $change >= 0 ? '+' : '' }}{{ $change }}%</span>
                                @endif
                                <span>{{ $statisticsOverview['total']['copy'] ?? 'vs periode lalu' }}</span>
                            </div>
                        </article>
                        <article class="admin-reports-card">
                            <div class="admin-reports-card-label">Selesai Ditangani</div>
                            <div class="admin-reports-card-value good">{{ number_format($completedCount, 0, ',', '.') }}</div>
                            <div class="admin-reports-card-meta">
                                @php $change = $statisticsOverview['resolution_rate']['change'] ?? null; @endphp
                                @if(!is_null($change))
                                    <span class="admin-reports-card-change {{ $change >= 0 ? 'up' : 'down' }}">{{ $change >= 0 ? '+' : '' }}{{ $change }}%</span>
                                @endif
                                <span>tingkat penyelesaian {{ number_format((float) ($statisticsOverview['resolution_rate']['value'] ?? 0), 1, ',', '.') }}%</span>
                            </div>
                        </article>
                        <article class="admin-reports-card">
                            <div class="admin-reports-card-label">Waktu Respon</div>
                            <div class="admin-reports-card-value">{{ number_format((float) ($statisticsOverview['avg_response_days']['value'] ?? 0), 1, ',', '.') }} hari</div>
                            <div class="admin-reports-card-meta">
                                @php $change = $statisticsOverview['avg_response_days']['change'] ?? null; @endphp
                                @if(!is_null($change))
                                    <span class="admin-reports-card-change {{ $change >= 0 ? 'up' : 'down' }}">{{ $change >= 0 ? '+' : '' }}{{ $change }}%</span>
                                @endif
                                <span>{{ $statisticsOverview['avg_response_days']['copy'] ?? 'respon rata-rata' }}</span>
                            </div>
                        </article>
                        <article class="admin-reports-card">
                            <div class="admin-reports-card-label">Area Aktif</div>
                            <div class="admin-reports-card-value">{{ number_format($statisticsOverview['active_areas']['value'] ?? 0, 0, ',', '.') }}</div>
                            <div class="admin-reports-card-meta">
                                <span>{{ $statisticsOverview['active_areas']['copy'] ?? 'wilayah aktif' }}</span>
                            </div>
                        </article>
                    </section>

                    <section class="admin-reports-layout">
                        <div class="admin-stats-chart-card">
                            <div class="admin-stats-chart-head">
                                <div>
                                    <h3 class="admin-stats-chart-title">Perbandingan Tren Bulanan</h3>
                                    <p class="admin-stats-chart-copy">Total, selesai, dan pending untuk evaluasi cepat laporan.</p>
                                </div>
                                <span class="admin-dashboard-tag">Trend</span>
                            </div>
                            @if($monthlyTrendStats->isNotEmpty())
                                <div class="admin-stats-chart-box">
                                    <canvas id="reports-monthly-trend-chart"></canvas>
                                </div>
                            @else
                                <div class="admin-dashboard-empty">Belum ada data tren bulanan.</div>
                            @endif
                        </div>

                        <div class="admin-stats-chart-card">
                            <div class="admin-stats-chart-head">
                                <div>
                                    <h3 class="admin-stats-chart-title">Performa Kategori</h3>
                                    <p class="admin-stats-chart-copy">Kategori paling dominan untuk bahan laporan berkala.</p>
                                </div>
                                <span class="admin-dashboard-tag">Top 5</span>
                            </div>
                            @if($categoryBreakdownStats->isNotEmpty())
                                <div class="admin-reports-list">
                                    @foreach($categoryBreakdownStats as $category)
                                        <div class="admin-reports-list-item">
                                            <div class="admin-reports-list-main">
                                                <span class="admin-reports-rank">{!! $iconSvg($categoryIconName($category['category'])) !!}</span>
                                                <div>
                                                    <div class="admin-reports-list-name">{{ $category['category'] }}</div>
                                                    <div class="admin-reports-list-sub">{{ number_format($category['count'], 0, ',', '.') }} pengaduan</div>
                                                </div>
                                            </div>
                                            <div class="admin-reports-list-metric">
                                                <strong>{{ number_format((float) $category['share'], 1, ',', '.') }}%</strong>
                                                <span>dari total laporan</span>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            @else
                                <div class="admin-dashboard-empty">Belum ada data kategori.</div>
                            @endif
                        </div>
                    </section>

                    <section class="admin-reports-layout">
                        <div class="admin-stats-chart-card">
                            <div class="admin-stats-chart-head">
                                <div>
                                    <h3 class="admin-stats-chart-title">Ringkasan per Area</h3>
                                    <p class="admin-stats-chart-copy">Wilayah dengan kontribusi laporan tertinggi.</p>
                                </div>
                                <span class="admin-dashboard-tag">Sebaran</span>
                            </div>
                            @if($areaDistributionStats->isNotEmpty())
                                <div class="admin-reports-area-list">
                                    @foreach($areaDistributionStats as $area)
                                        <div class="admin-reports-area-item">
                                            <div class="admin-reports-area-head">
                                                <div class="admin-reports-area-name">{{ $area['name'] }}</div>
                                                <div class="admin-reports-area-total">{{ $area['count'] }} laporan</div>
                                            </div>
                                            <div class="admin-reports-area-track">
                                                <div class="admin-reports-area-bar" style="width: {{ min(100, (float) $area['value']) }}%; background: {{ $area['color'] }};"></div>
                                            </div>
                                            <div class="admin-reports-area-meta">
                                                <span>Kontribusi wilayah</span>
                                                <span>{{ number_format((float) $area['value'], 1, ',', '.') }}%</span>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            @else
                                <div class="admin-dashboard-empty">Belum ada data area.</div>
                            @endif
                        </div>

                        <div class="admin-stats-chart-card">
                            <div class="admin-stats-chart-head">
                                <div>
                                    <h3 class="admin-stats-chart-title">Akses Cepat Laporan</h3>
                                    <p class="admin-stats-chart-copy">Shortcut ke data utama yang biasanya dipakai admin.</p>
                                </div>
                                <span class="admin-dashboard-tag">Quick access</span>
                            </div>
                            <div class="admin-reports-template-grid">
                                <div class="admin-reports-template">
                                    <span class="admin-reports-template-icon">{!! $iconSvg('reports') !!}</span>
                                    <div class="admin-reports-template-title">Export Data CSV</div>
                                    <div class="admin-reports-template-copy">Unduh rekap pengaduan untuk pelaporan bulanan dan arsip eksternal.</div>
                                    <div class="admin-reports-template-action">
                                        <a href="{{ route('admin.complaints.export.csv') }}" class="btn btn-outline-success btn-sm">Export</a>
                                    </div>
                                </div>
                                <div class="admin-reports-template">
                                    <span class="admin-reports-template-icon">{!! $iconSvg('stats') !!}</span>
                                    <div class="admin-reports-template-title">Lihat Statistik</div>
                                    <div class="admin-reports-template-copy">Buka analisis tren, distribusi area, dan waktu respon secara terpisah.</div>
                                    <div class="admin-reports-template-action">
                                        <a href="{{ route('dashboard', ['section' => 'statistik']) }}" class="btn btn-outline-secondary btn-sm">Buka Statistik</a>
                                    </div>
                                </div>
                                <div class="admin-reports-template">
                                    <span class="admin-reports-template-icon">{!! $iconSvg('complaints') !!}</span>
                                    <div class="admin-reports-template-title">Daftar Pengaduan</div>
                                    <div class="admin-reports-template-copy">Masuk ke daftar pengaduan untuk audit detail sebelum membuat rekap.</div>
                                    <div class="admin-reports-template-action">
                                        <a href="{{ route('dashboard', ['section' => 'pengaduan']) }}" class="btn btn-outline-secondary btn-sm">Lihat Data</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                @endif

                @if($currentSection === 'pengaduan')
                    <section id="kelola-pengaduan" class="admin-dashboard-panel">
                        <div class="admin-dashboard-panel-head">
                            <div>
                                <div class="admin-dashboard-panel-title">Kelola Pengaduan</div>
                                <p class="admin-dashboard-panel-copy">Filter, ekspor, dan tindak lanjuti seluruh pengaduan dalam satu area kerja.</p>
                            </div>
                            <div class="admin-reports-toolbar-actions">
                                <a href="{{ route('admin.complaints.export.csv', request()->except('complaints_page', 'users_page')) }}" class="btn btn-outline-success btn-sm">Export CSV</a>
                                <button type="button" id="export-dashboard-pdf-btn" class="btn btn-primary btn-sm">Export PDF</button>
                            </div>
                        </div>
                        <div class="admin-dashboard-filter-block">
                            <form method="GET" action="{{ route('dashboard') }}" class="admin-dashboard-search-form">
                                <input type="hidden" name="section" value="pengaduan">
                                <input type="text" name="q" value="{{ $dashboardSearch ?? '' }}" placeholder="Judul, deskripsi, nama, email">
                                <select name="status" class="admin-dashboard-role-select">
                                    <option value="">Semua Status</option>
                                    <option value="pending" {{ ($dashboardStatus ?? '') === 'pending' ? 'selected' : '' }}>Pending</option>
                                    <option value="process" {{ ($dashboardStatus ?? '') === 'process' ? 'selected' : '' }}>In Process</option>
                                    <option value="rejected" {{ ($dashboardStatus ?? '') === 'rejected' ? 'selected' : '' }}>Ditolak</option>
                                    <option value="done" {{ ($dashboardStatus ?? '') === 'done' ? 'selected' : '' }}>Selesai</option>
                                </select>
                                <select name="category_id" class="admin-dashboard-role-select">
                                    <option value="">Semua Kategori</option>
                                    @foreach($dashboardCategories as $categoryOption)
                                        <option value="{{ $categoryOption->id }}" {{ (string) ($dashboardCategoryId ?? '') === (string) $categoryOption->id ? 'selected' : '' }}>{{ $categoryOption->name }}</option>
                                    @endforeach
                                </select>
                                <input type="date" name="date_from" value="{{ $dashboardDateFrom ?? '' }}" class="admin-dashboard-role-select">
                                <input type="date" name="date_to" value="{{ $dashboardDateTo ?? '' }}" class="admin-dashboard-role-select">
                                <button type="submit" class="btn btn-primary">Terapkan</button>
                                <a href="{{ route('dashboard', ['section' => 'pengaduan']) }}" class="btn btn-outline-secondary">Reset</a>
                            </form>
                        </div>
                        @if($complaintTable->count() > 0)
                            <div class="admin-dashboard-table admin-dashboard-table--complaints">
                                <table id="dashboard-complaints-table">
                                    <thead><tr><th class="col-no">#</th><th class="col-reporter">Pelapor</th><th class="col-title">Judul</th><th class="col-category">Kategori</th><th class="col-status">Status</th><th class="col-actions">Aksi</th><th class="col-date">Tanggal</th></tr></thead>
                                    <tbody>
                                        @foreach($complaintTable as $complaint)
                                            @php
                                                $statusTheme = match($complaint->status) {
                                                    'approved', 'process' => 'process',
                                                    'rejected' => 'rejected',
                                                    'done' => 'done',
                                                    default => 'pending'
                                                };
                                                $statusLabel = match($complaint->status) {
                                                    'approved', 'process' => 'Diproses',
                                                    'rejected' => 'Ditolak',
                                                    'done' => 'Selesai',
                                                    default => 'Pending'
                                                };
                                            @endphp
                                            <tr>
                                                <td class="col-no">{{ $loop->iteration + (($complaintTable->currentPage() - 1) * $complaintTable->perPage()) }}</td>
                                                <td class="col-reporter">{{ $complaint->user->name ?? '-' }}</td>
                                                <td class="col-title"><div class="fw-semibold">{{ $complaint->title }}</div><div class="admin-dashboard-list-meta">{{ $complaint->user->email ?? '-' }}</div></td>
                                                <td class="col-category">{{ $complaint->category->name ?? 'Tanpa kategori' }}</td>
                                                <td class="col-status-cell"><span class="admin-dashboard-badge {{ $statusTheme }}">{{ $statusLabel }}</span></td>
                                                <td class="col-actions-cell">
                                                    <div class="admin-dashboard-inline-actions">
                                                        <a href="{{ route('admin.complaints.show', $complaint) }}" class="btn btn-sm btn-outline-secondary">Detail</a>
                                                        <a href="{{ route('admin.complaints.edit', $complaint) }}" class="btn btn-sm btn-primary">Tindak Lanjut</a>
                                                    </div>
                                                </td>
                                                <td class="col-date-cell">{{ $complaint->created_at->format('d M Y') }}</td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                            <div class="mt-3">
                                {{ $complaintTable->links() }}
                            </div>
                        @else
                            <div class="admin-dashboard-empty">Belum ada pengaduan untuk ditampilkan.</div>
                        @endif
                    </section>
                @endif
            </main>
        </div>
    </div>
@else
    <div class="admin-dashboard-user-home">
        <div class="admin-dashboard-panel">
            <div class="admin-dashboard-panel-head"><div><div class="admin-dashboard-panel-title">Dashboard User</div><p class="admin-dashboard-panel-copy">Akses cepat ke pengaduan Anda dari halaman ini.</p></div></div>
            <div class="admin-dashboard-inline-actions">
                <a href="{{ route('complaints.index') }}" class="btn btn-primary">Lihat Komplain</a>
                <a href="{{ route('complaints.create') }}" class="btn btn-outline-secondary">Buat Pengaduan</a>
            </div>
        </div>
    </div>
@endif
@endsection

@if(auth()->user()->role === 'admin')
    @push('scripts')
        <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js"></script>
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
        <script>
            (function () {
                const timezone = 'Asia/Jakarta';
                const serverNowMs = {{ now(config('app.timezone'))->timestamp * 1000 }};
                const clientStartMs = Date.now();
                const clockTimeEl = document.getElementById('admin-clock-time');
                const clockDateEl = document.getElementById('admin-clock-date');
                const points = @json($mapPoints);
                const monthlyTrend = @json($monthlyTrendStats);
                const areaDistribution = @json($areaDistributionStats);
                const responseTime = @json($responseTimeStats);
                const resolutionRate = @json($resolutionRateStats);
                document.body.classList.add('admin-dashboard-page');
                const isDarkTheme = document.body.classList.contains('app-theme-dark');

                const timeFormatter = new Intl.DateTimeFormat('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false, timeZone: timezone });
                const dateFormatter = new Intl.DateTimeFormat('id-ID', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric', timeZone: timezone });
                const renderClock = () => {
                    const nowDate = new Date(serverNowMs + (Date.now() - clientStartMs));
                    if (clockTimeEl) clockTimeEl.textContent = timeFormatter.format(nowDate);
                    if (clockDateEl) clockDateEl.textContent = `${dateFormatter.format(nowDate)} (WIB)`;
                };
                renderClock();
                setInterval(renderClock, 1000);

                const exportPdfBtn = document.getElementById('export-dashboard-pdf-btn');
                if (exportPdfBtn) {
                    exportPdfBtn.addEventListener('click', function () {
                        const jsPDFNS = window.jspdf;
                        const table = document.getElementById('dashboard-complaints-table');
                        if (!jsPDFNS || !table) {
                            return;
                        }

                        const rows = Array.from(table.querySelectorAll('tbody tr'))
                            .map((row) => Array.from(row.querySelectorAll('td')).map((cell) => (cell.textContent || '').trim()))
                            .filter((cells) => cells.length >= 7);

                        if (!rows.length) {
                            alert('Tidak ada data pengaduan untuk diekspor.');
                            return;
                        }

                        const { jsPDF } = jsPDFNS;
                        const doc = new jsPDF({ orientation: 'landscape', unit: 'pt', format: 'a4' });
                        doc.setFontSize(15);
                        doc.text('Laporan Pengaduan Lingkungan', 40, 40);
                        doc.setFontSize(10);
                        doc.text(`Dicetak: ${new Date().toLocaleString('id-ID')}`, 40, 60);
                        doc.autoTable({
                            startY: 78,
                            head: [['#', 'Pelapor', 'Judul', 'Kategori', 'Status', 'Aksi', 'Tanggal']],
                            body: rows.map((cells) => [cells[0], cells[1], cells[2], cells[3], cells[4], '-', cells[6]]),
                            styles: { fontSize: 9, cellPadding: 5 },
                            headStyles: { fillColor: [15, 118, 110] },
                            alternateRowStyles: { fillColor: [245, 252, 249] }
                        });
                        const now = new Date();
                        const stamp = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
                        doc.save(`laporan-pengaduan-${stamp}.pdf`);
                    });
                }

                const mapEl = document.getElementById('dashboard-active-map');
                if (mapEl && typeof L !== 'undefined') {
                    const map = L.map(mapEl).setView([-2.5489, 118.0149], 5);
                    const tileUrl = isDarkTheme
                        ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
                        : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
                    L.tileLayer(tileUrl, { maxZoom: 19, attribution: '&copy; OpenStreetMap contributors &copy; CARTO' }).addTo(map);

                    if (!points.length) {
                        L.popup().setLatLng([-2.5489, 118.0149]).setContent('Belum ada pengaduan aktif dengan titik lokasi.').openOn(map);
                        return;
                    }

                    const bounds = [];
                    const statusLabel = { pending: 'Pending', process: 'Diproses', approved: 'Diproses', done: 'Selesai', rejected: 'Ditolak' };
                    points.forEach((point) => {
                        const marker = L.marker([point.latitude, point.longitude]).addTo(map);
                        marker.bindPopup(`<div style="min-width:220px"><strong>${point.title}</strong><br><small>Status: ${statusLabel[point.status] ?? point.status}</small><br><small>${point.address || 'Alamat tidak tersedia'}</small><br><a href="${point.detailUrl}">Lihat detail</a></div>`);
                        bounds.push([point.latitude, point.longitude]);
                    });

                    if (bounds.length === 1) map.setView(bounds[0], 14);
                    else map.fitBounds(bounds, { padding: [36, 36] });
                }

                if (typeof Chart !== 'undefined') {
                    const defaultGrid = { color: isDarkTheme ? 'rgba(148, 163, 184, 0.16)' : '#e5e7eb' };
                    const defaultTicks = { color: isDarkTheme ? '#94a3b8' : '#64748b', font: { size: 12 } };
                    const defaultLegend = { labels: { color: isDarkTheme ? '#cbd5e1' : '#475569' } };

                    const monthlyTrendEl = document.getElementById('monthly-trend-chart');
                    if (monthlyTrendEl && monthlyTrend.length) {
                        new Chart(monthlyTrendEl, {
                            type: 'line',
                            data: {
                                labels: monthlyTrend.map((item) => item.month),
                                datasets: [
                                    { label: 'Total', data: monthlyTrend.map((item) => item.total), borderColor: '#6b7280', backgroundColor: '#6b7280', tension: 0.35, borderWidth: 2 },
                                    { label: 'Selesai', data: monthlyTrend.map((item) => item.resolved), borderColor: '#16a34a', backgroundColor: '#16a34a', tension: 0.35, borderWidth: 2 },
                                    { label: 'Pending', data: monthlyTrend.map((item) => item.pending), borderColor: '#f59e0b', backgroundColor: '#f59e0b', tension: 0.35, borderWidth: 2 }
                                ]
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: { legend: { position: 'top', ...defaultLegend } },
                                scales: { x: { grid: { display: false }, ticks: defaultTicks }, y: { beginAtZero: true, grid: defaultGrid, ticks: defaultTicks } }
                            }
                        });
                    }

                    const reportsMonthlyTrendEl = document.getElementById('reports-monthly-trend-chart');
                    if (reportsMonthlyTrendEl && monthlyTrend.length) {
                        new Chart(reportsMonthlyTrendEl, {
                            type: 'line',
                            data: {
                                labels: monthlyTrend.map((item) => item.month),
                                datasets: [
                                    { label: 'Total', data: monthlyTrend.map((item) => item.total), borderColor: '#94a3b8', backgroundColor: 'rgba(148, 163, 184, 0.18)', tension: 0.35, fill: true, borderWidth: 2 },
                                    { label: 'Selesai', data: monthlyTrend.map((item) => item.resolved), borderColor: '#16a34a', backgroundColor: 'rgba(22, 163, 74, 0.18)', tension: 0.35, fill: true, borderWidth: 2 },
                                    { label: 'Pending', data: monthlyTrend.map((item) => item.pending), borderColor: '#f59e0b', backgroundColor: 'rgba(245, 158, 11, 0.18)', tension: 0.35, fill: true, borderWidth: 2 }
                                ]
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: { legend: { position: 'top', ...defaultLegend } },
                                scales: { x: { grid: { display: false }, ticks: defaultTicks }, y: { beginAtZero: true, grid: defaultGrid, ticks: defaultTicks } }
                            }
                        });
                    }

                    const areaDistributionEl = document.getElementById('area-distribution-chart');
                    if (areaDistributionEl && areaDistribution.length) {
                        new Chart(areaDistributionEl, {
                            type: 'doughnut',
                            data: {
                                labels: areaDistribution.map((item) => item.name),
                                datasets: [{
                                    data: areaDistribution.map((item) => item.value),
                                    backgroundColor: areaDistribution.map((item) => item.color),
                                    borderWidth: 0
                                }]
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: { legend: { display: false, ...defaultLegend } },
                                cutout: '62%'
                            }
                        });
                    }

                    const responseTimeEl = document.getElementById('response-time-chart');
                    if (responseTimeEl && responseTime.length) {
                        new Chart(responseTimeEl, {
                            type: 'bar',
                            data: {
                                labels: responseTime.map((item) => item.category),
                                datasets: [{
                                    label: 'Rata-rata (hari)',
                                    data: responseTime.map((item) => item.avgTime),
                                    backgroundColor: '#16a34a',
                                    borderRadius: 10
                                }]
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: {
                                    legend: { display: false },
                                    tooltip: { callbacks: { label: (context) => `${context.parsed.y} hari` } }
                                },
                                scales: { x: { grid: { display: false }, ticks: defaultTicks }, y: { beginAtZero: true, grid: defaultGrid, ticks: defaultTicks } }
                            }
                        });
                    }

                    const resolutionRateEl = document.getElementById('resolution-rate-chart');
                    if (resolutionRateEl && resolutionRate.length) {
                        new Chart(resolutionRateEl, {
                            type: 'line',
                            data: {
                                labels: resolutionRate.map((item) => item.month),
                                datasets: [{
                                    label: 'Tingkat Penyelesaian',
                                    data: resolutionRate.map((item) => item.rate),
                                    borderColor: '#16a34a',
                                    backgroundColor: '#16a34a',
                                    tension: 0.35,
                                    borderWidth: 3,
                                    pointRadius: 4,
                                    pointHoverRadius: 5,
                                    fill: false
                                }]
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: {
                                    legend: { display: true, position: 'top', ...defaultLegend },
                                    tooltip: { callbacks: { label: (context) => `${context.parsed.y}%` } }
                                },
                                scales: {
                                    x: { grid: { display: false }, ticks: defaultTicks },
                                    y: { beginAtZero: true, max: 100, grid: defaultGrid, ticks: { ...defaultTicks, callback: (value) => `${value}%` } }
                                }
                            }
                        });
                    }
                }
            })();
        </script>
    @endpush
@endif
