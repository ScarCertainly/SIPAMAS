<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class GuestWhatsAppLoginController extends Controller
{
    /**
     * Handle guest login using WhatsApp number.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'guest_name' => ['nullable', 'string', 'max:255'],
            'guest_whatsapp' => ['required', 'string', 'max:25'],
        ]);

        $whatsappNumber = $this->normalizeWhatsAppNumber($validated['guest_whatsapp']);

        if (!preg_match('/^62\\d{8,13}$/', $whatsappNumber)) {
            return back()
                ->withErrors([
                    'guest_whatsapp' => 'Format nomor WhatsApp tidak valid. Gunakan 08xx atau 62xx.',
                ])
                ->withInput();
        }

        $user = User::where('whatsapp_number', $whatsappNumber)->first();

        if ($user && $user->role === 'admin') {
            return back()
                ->withErrors([
                    'guest_whatsapp' => 'Nomor WhatsApp ini terdaftar sebagai admin dan tidak bisa digunakan untuk login guest.',
                ])
                ->withInput();
        }

        if ($user && $user->role === 'blacklisted') {
            return back()
                ->withErrors([
                    'guest_whatsapp' => 'Akun dengan nomor WhatsApp ini telah diblokir.',
                ])
                ->withInput();
        }

        if (! $user) {
            $displayName = trim((string) ($validated['guest_name'] ?? ''));
            if ($displayName === '') {
                $displayName = 'Guest ' . substr($whatsappNumber, -4);
            }

            $user = User::create([
                'name' => $displayName,
                'email' => $this->generateGuestEmail($whatsappNumber),
                'whatsapp_number' => $whatsappNumber,
                'password' => Hash::make(Str::random(32)),
                'role' => 'user',
            ]);

            $user->forceFill(['email_verified_at' => now()])->save();
        }

        Auth::login($user, true);
        $request->session()->regenerate();

        return redirect()->route('home');
    }

    private function normalizeWhatsAppNumber(string $input): string
    {
        $digits = preg_replace('/\\D+/', '', $input) ?? '';

        if (Str::startsWith($digits, '0')) {
            return '62' . substr($digits, 1);
        }

        if (Str::startsWith($digits, '8')) {
            return '62' . $digits;
        }

        return $digits;
    }

    private function generateGuestEmail(string $whatsappNumber): string
    {
        $base = 'guest' . $whatsappNumber;
        $email = $base . '@guest.ecovoice.local';
        $counter = 1;

        while (User::where('email', $email)->exists()) {
            $email = $base . '+' . $counter . '@guest.ecovoice.local';
            $counter++;
        }

        return $email;
    }
}
