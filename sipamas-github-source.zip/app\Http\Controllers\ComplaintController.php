<?php

namespace App\Http\Controllers;

use App\Models\Complaint;
use App\Models\Category;
use App\Models\ComplaintComment;
use App\Models\User;
use App\Notifications\UserRepliedComplaintChat;
use App\Support\PublicImageUpload;
use App\Support\PublicUploadedMedia;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class ComplaintController extends Controller
{
    private const ENVIRONMENTAL_CATEGORIES = [
        'Sampah & Limbah Rumah Tangga',
        'Pencemaran Air (Sungai/Drainase)',
        'Pencemaran Udara & Asap',
        'Ruang Terbuka Hijau & Penebangan Pohon',
        'Sanitasi & Kebersihan Lingkungan',
        'Banjir Akibat Lingkungan',
        'Limbah B3 / Industri',
        'Edukasi & Program Lingkungan',
    ];

    public function index(Request $request)
    {
        $baseQuery = Complaint::query()->where('user_id', auth()->id());
        $query = Complaint::with('category')->where('user_id', auth()->id());
        $keyword = trim((string) $request->query('q', ''));

        if ($keyword !== '') {
            $query->where(function ($builder) use ($keyword) {
                $builder->where('title', 'like', '%' . $keyword . '%')
                    ->orWhere('description', 'like', '%' . $keyword . '%');
            });
        }

        $summary = [
            'total' => (clone $baseQuery)->count(),
            'pending' => (clone $baseQuery)->where('status', 'pending')->count(),
            'process' => (clone $baseQuery)->whereIn('status', ['process', 'approved'])->count(),
            'done' => (clone $baseQuery)->where('status', 'done')->count(),
            'rejected' => (clone $baseQuery)->where('status', 'rejected')->count(),
        ];

        $complaints = $query
            ->latest()
            ->paginate(10)
            ->withQueryString();

        return view('complaints.index', compact('complaints', 'summary', 'keyword'));
    }

    public function create()
    {
        $categories = $this->getEnvironmentalCategories();
        return view('complaints.create', compact('categories'));
    }

    public function store(Request $request)
    {
        $categoryIds = $this->getEnvironmentalCategories()->pluck('id')->all();

        $validated = $request->validate([
            'title' => 'required',
            'description' => 'required',
            'category_id' => ['required', Rule::in($categoryIds)],
            'image_evidence' => 'image|max:2048',
            'province' => 'nullable|string|max:100',
            'city' => 'nullable|string|max:100',
            'district' => 'nullable|string|max:100',
            'village' => 'nullable|string|max:100',
            'street_address' => 'required|string|max:255',
            'latitude' => 'nullable|numeric|between:-90,90|required_with:longitude',
            'longitude' => 'nullable|numeric|between:-180,180|required_with:latitude',
        ]);

        $imageEvidencePath = null;
        if ($request->hasFile('image_evidence')) {
            $imageEvidencePath = $this->storePublicImageEvidence($request->file('image_evidence'));
        }

        Complaint::create([
            'user_id' => auth()->id(),
            'category_id' => $validated['category_id'],
            'title' => $validated['title'],
            'description' => $validated['description'],
            'image_evidence' => $imageEvidencePath,
            'location_source' => (isset($validated['latitude'], $validated['longitude']) && $validated['latitude'] !== null && $validated['longitude'] !== null) ? 'gps' : 'manual',
            'latitude' => $validated['latitude'] ?? null,
            'longitude' => $validated['longitude'] ?? null,
            'province' => $validated['province'] ?? null,
            'city' => $validated['city'] ?? null,
            'district' => $validated['district'] ?? null,
            'village' => $validated['village'] ?? null,
            'street_address' => $validated['street_address'] ?? null,
        ]);

        return redirect()->route('complaints.index');
    }

    public function edit(Complaint $complaint)
    {
        if ($complaint->user_id !== auth()->id()) {
            abort(403, 'Unauthorized access');
        }

        $categories = $this->getEnvironmentalCategories();
        return view('complaints.edit', compact('complaint', 'categories'));
    }

    public function show(Complaint $complaint)
    {
        if ($complaint->user_id !== auth()->id()) {
            abort(403, 'Unauthorized access');
        }

        $complaint->load(['category', 'adminResponder', 'statusHistories.admin', 'comments.admin', 'comments.user']);

        return view('complaints.show', compact('complaint'));
    }

    public function storeChatMessage(Request $request, Complaint $complaint)
    {
        if ($complaint->user_id !== auth()->id()) {
            abort(403, 'Unauthorized access');
        }

        if (!$complaint->allow_user_chat) {
            return back()->withErrors([
                'chat_message' => 'Chat dengan admin belum diizinkan untuk laporan ini.',
            ]);
        }

        $validated = $request->validate([
            'chat_message' => 'required|string|max:2000',
        ]);

        $comment = ComplaintComment::create([
            'complaint_id' => $complaint->id,
            'user_id' => auth()->id(),
            'comment' => $validated['chat_message'],
        ]);

        $comment->load('user');

        User::query()
            ->where('role', 'admin')
            ->get()
            ->each(function (User $admin) use ($complaint, $comment) {
                $admin->notify(new UserRepliedComplaintChat($complaint, $comment));
            });

        return redirect()
            ->route('complaints.show', $complaint)
            ->with('status', 'chat-message-sent');
    }

    public function update(Request $request, Complaint $complaint)
    {
        if ($complaint->user_id !== auth()->id()) {
            abort(403, 'Unauthorized access');
        }

        $categoryIds = $this->getEnvironmentalCategories()->pluck('id')->all();

        $validated = $request->validate([
            'title' => 'required',
            'description' => 'required',
            'category_id' => ['required', Rule::in($categoryIds)],
            'image_evidence' => 'image|max:2048',
            'province' => 'nullable|string|max:100',
            'city' => 'nullable|string|max:100',
            'district' => 'nullable|string|max:100',
            'village' => 'nullable|string|max:100',
            'street_address' => 'required|string|max:255',
            'latitude' => 'nullable|numeric|between:-90,90|required_with:longitude',
            'longitude' => 'nullable|numeric|between:-180,180|required_with:latitude',
        ]);

        $imageEvidencePath = $complaint->image_evidence;
        if ($request->hasFile('image_evidence')) {
            $imageEvidencePath = $this->storePublicImageEvidence($request->file('image_evidence'));

            if ($complaint->image_evidence) {
                $this->deleteStoredImage($complaint->image_evidence);
            }
        }

        $latitude = array_key_exists('latitude', $validated) ? $validated['latitude'] : $complaint->latitude;
        $longitude = array_key_exists('longitude', $validated) ? $validated['longitude'] : $complaint->longitude;

        $complaint->update([
            'category_id' => $validated['category_id'],
            'title' => $validated['title'],
            'description' => $validated['description'],
            'image_evidence' => $imageEvidencePath,
            'location_source' => ($latitude !== null && $longitude !== null) ? 'gps' : 'manual',
            'latitude' => $latitude,
            'longitude' => $longitude,
            'province' => $validated['province'] ?? null,
            'city' => $validated['city'] ?? null,
            'district' => $validated['district'] ?? null,
            'village' => $validated['village'] ?? null,
            'street_address' => $validated['street_address'] ?? null,
        ]);

        return redirect()->route('complaints.index');
    }

    public function destroy(Complaint $complaint)
    {
        if ($complaint->user_id !== auth()->id()) {
            abort(403, 'Unauthorized access');
        }

        if ($complaint->image_evidence) {
            $this->deleteStoredImage($complaint->image_evidence);
        }

        $complaint->delete();

        return redirect()->route('complaints.index')->with('status', 'Pengaduan berhasil dihapus.');
    }

    private function storePublicImageEvidence($file): string
    {
        // PublicImageUpload already prefixes "uploads/", so "complaints"
        // resolves to the public /uploads/complaints directory.
        return PublicImageUpload::store($file, 'complaints', 'complaint');
    }

    private function deleteStoredImage(?string $path): void
    {
        PublicUploadedMedia::delete($path);
    }

    private function getEnvironmentalCategories()
    {
        foreach (self::ENVIRONMENTAL_CATEGORIES as $name) {
            Category::firstOrCreate(['name' => $name]);
        }

        return Category::whereIn('name', self::ENVIRONMENTAL_CATEGORIES)->orderBy('name')->get();
    }
}
