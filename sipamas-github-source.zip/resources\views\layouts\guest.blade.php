<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <meta name="color-scheme" content="light dark">

        <title>{{ config('app.name', 'Laravel') }}</title>

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Merriweather:wght@700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

        @vite(['resources/css/app.css'])
        <style>
            :root {
                --auth-bg: #ecfeff;
                --auth-card: rgba(255, 255, 255, 0.95);
                --auth-border: rgba(15, 23, 42, 0.1);
                --auth-text: #0f172a;
                --auth-muted: #475569;
            }
            body.auth-body {
                font-family: "Plus Jakarta Sans", system-ui, -apple-system, "Segoe UI", sans-serif;
                background:
                    radial-gradient(1100px 560px at 100% -10%, rgba(20, 184, 166, 0.16), transparent 60%),
                    radial-gradient(900px 500px at -10% -10%, rgba(6, 182, 212, 0.18), transparent 60%),
                    var(--auth-bg);
                color: var(--auth-text);
            }
            .auth-card {
                background: var(--auth-card);
                border: 1px solid var(--auth-border);
                border-radius: 20px;
                box-shadow: 0 18px 42px rgba(15, 23, 42, 0.1);
            }
            .auth-title {
                font-family: "Merriweather", serif;
                letter-spacing: 0.3px;
            }
            .auth-kicker {
                display: inline-flex;
                align-items: center;
                gap: 8px;
                padding: 4px 10px;
                border-radius: 999px;
                border: 1px solid rgba(15, 118, 110, 0.2);
                background: #ecfeff;
                color: #0f5f65;
                font-size: 0.72rem;
                font-weight: 700;
                letter-spacing: 0.3px;
                text-transform: uppercase;
            }
            .auth-subtitle {
                color: var(--auth-muted);
                font-size: 0.92rem;
            }
            .auth-body .text-indigo-600,
            .auth-body .hover\:text-indigo-700:hover {
                color: #0f766e !important;
            }
            .auth-body .text-gray-600,
            .auth-body .text-gray-400 {
                color: var(--auth-muted) !important;
            }
            @media (prefers-color-scheme: dark) {
                :root {
                    --auth-bg: #020617;
                    --auth-card: rgba(15, 23, 42, 0.92);
                    --auth-border: rgba(148, 163, 184, 0.22);
                    --auth-text: #e2e8f0;
                    --auth-muted: #94a3b8;
                }
                .auth-kicker {
                    border-color: rgba(45, 212, 191, 0.28);
                    background: rgba(20, 184, 166, 0.14);
                    color: #99f6e4;
                }
                .auth-body .text-gray-900 {
                    color: #e2e8f0 !important;
                }
                .auth-body .bg-white {
                    background-color: #0f172a !important;
                }
                .auth-body .border-gray-300 {
                    border-color: rgba(148, 163, 184, 0.28) !important;
                }
                .auth-body input,
                .auth-body textarea,
                .auth-body select {
                    background-color: #0b1220;
                    color: #e2e8f0;
                    border-color: rgba(148, 163, 184, 0.28);
                }
            }
        </style>
    </head>
    <body class="auth-body antialiased">
        <div class="min-h-screen flex flex-col justify-center items-center px-4 py-10">
            <div class="auth-card w-full max-w-4xl px-6 py-6 overflow-hidden">
                <div class="text-center mb-5">
                    <div class="auth-kicker mb-2">Portal Dinas Lingkungan</div>
                    <div class="auth-title text-3xl text-gray-900">SIPAMAS</div>
                    <div class="auth-subtitle">Sistem Pengaduan Lingkungan Hidup Masyarakat</div>
                </div>
                {{ $slot }}
            </div>
        </div>
    </body>
</html>
