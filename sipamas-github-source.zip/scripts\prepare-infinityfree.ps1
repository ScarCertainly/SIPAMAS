param(
    [string]$OutputDir = "_deploy\infinityfree",
    [string]$WebRootDirName = "htdocs"
)

$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $PSScriptRoot
$outputRoot = Join-Path $projectRoot $OutputDir
$appTarget = Join-Path $outputRoot "app"
$publicTarget = Join-Path $outputRoot $WebRootDirName

if (Test-Path $outputRoot) {
    Remove-Item $outputRoot -Recurse -Force
}

New-Item -ItemType Directory -Path $appTarget | Out-Null
New-Item -ItemType Directory -Path $publicTarget | Out-Null

function Copy-Tree {
    param(
        [string]$SourcePath,
        [string]$DestinationPath
    )

    if (Test-Path -LiteralPath $SourcePath -PathType Container) {
        if (-not (Test-Path -LiteralPath $DestinationPath)) {
            New-Item -ItemType Directory -Path $DestinationPath -Force | Out-Null
        }

        Get-ChildItem -LiteralPath $SourcePath -Force | ForEach-Object {
            $childDestination = Join-Path $DestinationPath $_.Name
            Copy-Tree -SourcePath $_.FullName -DestinationPath $childDestination
        }

        return
    }

    try {
        Copy-Item -LiteralPath $SourcePath -Destination $DestinationPath -Force
    } catch {
        Write-Warning ("Melewati file yang tidak bisa dicopy: {0}" -f $SourcePath)
    }
}

$rootExcludes = @(
    ".env",
    ".git",
    ".github",
    ".idea",
    ".vscode",
    ".phpunit.result.cache",
    "_deploy",
    "_design",
    "_tmp",
    "docs",
    "node_modules",
    "package-lock.json",
    "package.json",
    "phpunit.xml",
    "postcss.config.js",
    "public",
    "README.md",
    "scripts",
    "tailwind.config.js",
    "tests",
    "tmp_src",
    "vite.config.js"
)

Get-ChildItem -Path $projectRoot -Force | Where-Object {
    $rootExcludes -notcontains $_.Name
} | ForEach-Object {
    Copy-Tree -SourcePath $_.FullName -DestinationPath (Join-Path $appTarget $_.Name)
}

Get-ChildItem -Path (Join-Path $projectRoot "public") -Force | Where-Object {
    $_.Name -ne "storage"
} | ForEach-Object {
    Copy-Tree -SourcePath $_.FullName -DestinationPath (Join-Path $publicTarget $_.Name)
}

$indexPhp = @'
<?php

use Illuminate\Contracts\Http\Kernel;
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

if (file_exists($maintenance = __DIR__.'/../app/storage/framework/maintenance.php')) {
    require $maintenance;
}

require __DIR__.'/../app/vendor/autoload.php';

$app = require_once __DIR__.'/../app/bootstrap/app.php';

$kernel = $app->make(Kernel::class);

$response = $kernel->handle(
    $request = Request::capture()
)->send();

$kernel->terminate($request, $response);
'@

Set-Content -Path (Join-Path $publicTarget "index.php") -Value $indexPhp -NoNewline

$storageDirs = @(
    "app",
    "app\public",
    "framework",
    "framework\cache",
    "framework\cache\data",
    "framework\sessions",
    "framework\testing",
    "framework\views",
    "logs"
)

foreach ($dir in $storageDirs) {
    $fullPath = Join-Path $appTarget ("storage\" + $dir)
    if (-not (Test-Path $fullPath)) {
        New-Item -ItemType Directory -Path $fullPath -Force | Out-Null
    }
}

$cleanupPaths = @(
    (Join-Path $appTarget "storage\app\regions_tmp"),
    (Join-Path $appTarget "storage\framework\sessions\*"),
    (Join-Path $appTarget "storage\framework\views\*"),
    (Join-Path $appTarget "storage\logs\*.log")
)

foreach ($path in $cleanupPaths) {
    Remove-Item $path -Recurse -Force -ErrorAction SilentlyContinue
}

Write-Host "Paket InfinityFree dibuat di: $outputRoot"
Write-Host "Upload isi $publicTarget ke $WebRootDirName dan simpan folder app di luar $WebRootDirName."
