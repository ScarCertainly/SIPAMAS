import React from 'react';

export function FeaturesSection() {
  const features = [
    { title: 'Peta Lokasi Aktif', desc: 'Titik pengaduan dengan koordinat GPS siap divisualisasikan.' },
    { title: 'Lampiran Bukti', desc: 'Unggah foto pencemaran untuk mempercepat verifikasi.' },
    { title: 'Riwayat Status', desc: 'Timeline perubahan status dari pending sampai selesai.' },
  ];

  return (
    <section id="fitur" className="py-16 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-serif text-slate-900 mb-4">Fitur utama SIPAMAS</h2>
          <p className="text-slate-600">Semua yang dibutuhkan warga untuk melaporkan dan memantau pengaduan lingkungan.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {features.map((f) => (
            <div key={f.title} className="p-6 rounded-xl bg-slate-50 border border-slate-200 shadow-sm">
              <h3 className="text-xl font-semibold text-slate-900 mb-2">{f.title}</h3>
              <p className="text-slate-600">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
