@extends('layouts.app')

@section('title', 'Detail Pengaduan Saya')

@push('styles')
<style>
    .complaint-detail-shell {
        max-width: 1180px;
        margin: 0 auto;
    }
    .complaint-detail-hero {
        border: 1px solid rgba(22, 163, 74, 0.18);
        background: linear-gradient(135deg, rgba(22, 163, 74, 0.08) 0%, rgba(240, 253, 244, 0.96) 100%);
        border-radius: 18px;
        padding: 20px;
        margin-bottom: 18px;
    }
    .complaint-detail-title {
        font-size: clamp(1.25rem, 2.8vw, 1.9rem);
        font-weight: 800;
        color: #0f3f42;
        margin-bottom: 4px;
    }
    .complaint-detail-card {
        border-radius: 22px;
        border: 1px solid rgba(22, 163, 74, 0.16);
        background: linear-gradient(180deg, rgba(255, 255, 255, 0.96) 0%, rgba(249, 253, 252, 0.96) 100%);
        box-shadow: 0 20px 35px rgba(15, 23, 42, 0.08);
        overflow: hidden;
    }
    .complaint-detail-section {
        padding: 24px;
    }
    .complaint-detail-label {
        font-size: 0.78rem;
        letter-spacing: 0.35px;
        text-transform: uppercase;
        font-weight: 800;
        color: #15803d;
        margin-bottom: 8px;
    }
    .complaint-evidence-box,
    .complaint-response-box,
    .complaint-qr-box,
    .complaint-location-box,
    .complaint-timeline-box {
        border: 1px solid rgba(22, 163, 74, 0.16);
        border-radius: 18px;
        background: rgba(240, 253, 244, 0.72);
    }
    .complaint-evidence-box,
    .complaint-response-photo {
        overflow: hidden;
        aspect-ratio: 4 / 3;
    }
    .complaint-response-box,
    .complaint-qr-box,
    .complaint-location-box,
    .complaint-timeline-box {
        padding: 18px;
    }
    .complaint-response-photo {
        border: 1px solid rgba(22, 163, 74, 0.16);
        border-radius: 18px;
        background: rgba(240, 253, 244, 0.72);
    }
    .complaint-summary-item + .complaint-summary-item {
        margin-top: 16px;
        padding-top: 16px;
        position: relative;
    }
    .complaint-summary-item + .complaint-summary-item::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: min(100%, 220px);
        height: 1px;
        background: rgba(22, 163, 74, 0.12);
    }
    #user-complaint-qr {
        width: 180px;
        min-height: 180px;
        margin: 0 auto;
    }
    #user-complaint-qr img,
    #user-complaint-qr canvas {
        display: block;
        margin: 0 auto;
    }
    .complaint-status-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 8px 12px;
        border-radius: 999px;
        font-size: 0.82rem;
        font-weight: 700;
    }
    .complaint-status-badge.pending {
        background: #fef3c7;
        color: #92400e;
    }
    .complaint-status-badge.process {
        background: #dbeafe;
        color: #1d4ed8;
    }
    .complaint-status-badge.done {
        background: #dcfce7;
        color: #166534;
    }
    .complaint-status-badge.rejected {
        background: #fee2e2;
        color: #b91c1c;
    }
    .complaint-timeline-item + .complaint-timeline-item {
        margin-top: 12px;
    }
    .complaint-timeline-card {
        border: 1px solid rgba(22, 163, 74, 0.12);
        border-radius: 16px;
        padding: 14px 16px;
        background: rgba(255, 255, 255, 0.72);
    }
    .complaint-chat-box {
        border: 1px solid rgba(22, 163, 74, 0.16);
        border-radius: 18px;
        background: rgba(240, 253, 244, 0.72);
        padding: 18px;
    }
    .complaint-chat-item {
        display: flex;
    }
    .complaint-chat-item.admin {
        justify-content: flex-start;
    }
    .complaint-chat-item.user {
        justify-content: flex-end;
    }
    .complaint-chat-item + .complaint-chat-item {
        margin-top: 12px;
    }
    .complaint-chat-bubble {
        border-radius: 16px;
        padding: 14px 16px;
        width: fit-content;
        max-width: min(100%, 680px);
    }
    .complaint-chat-bubble.admin {
        background: rgba(15, 118, 110, 0.12);
        border: 1px solid rgba(15, 118, 110, 0.18);
    }
    .complaint-chat-bubble.user {
        background: rgba(59, 130, 246, 0.1);
        border: 1px solid rgba(59, 130, 246, 0.18);
    }
    body.app-theme-dark .complaint-detail-hero {
        border-color: rgba(34, 197, 94, 0.24);
        background: linear-gradient(135deg, rgba(21, 128, 61, 0.18) 0%, rgba(15, 23, 42, 0.92) 100%);
    }
    body.app-theme-dark .complaint-detail-title {
        color: #dcfce7;
    }
    body.app-theme-dark .complaint-detail-card {
        border-color: rgba(148, 163, 184, 0.28);
        background: linear-gradient(180deg, rgba(15, 23, 42, 0.96) 0%, rgba(17, 24, 39, 0.96) 100%);
        box-shadow: 0 24px 35px rgba(2, 6, 23, 0.45);
    }
    body.app-theme-dark .complaint-detail-label {
        color: #bbf7d0;
    }
    body.app-theme-dark .complaint-evidence-box,
    body.app-theme-dark .complaint-response-box,
    body.app-theme-dark .complaint-response-photo,
    body.app-theme-dark .complaint-chat-box,
    body.app-theme-dark .complaint-qr-box,
    body.app-theme-dark .complaint-location-box,
    body.app-theme-dark .complaint-timeline-box,
    body.app-theme-dark .complaint-timeline-card {
        border-color: rgba(34, 197, 94, 0.24);
        background: rgba(20, 83, 45, 0.22);
    }
    body.app-theme-dark .complaint-chat-bubble.admin {
        background: rgba(15, 118, 110, 0.24);
    }
    body.app-theme-dark .complaint-chat-bubble.user {
        background: rgba(30, 64, 175, 0.24);
    }
    body.app-theme-dark .complaint-summary-item + .complaint-summary-item {
        border-top-color: transparent;
    }
    body.app-theme-dark .complaint-summary-item + .complaint-summary-item::before {
        background: rgba(148, 163, 184, 0.16);
    }
    body.app-theme-dark .complaint-detail-shell .fw-semibold,
    body.app-theme-dark .complaint-detail-shell h4,
    body.app-theme-dark .complaint-detail-shell p,
    body.app-theme-dark .complaint-detail-shell li,
    body.app-theme-dark .complaint-detail-shell div {
        color: #e2e8f0;
    }
    body.app-theme-dark .complaint-detail-shell .text-muted,
    body.app-theme-dark .complaint-detail-shell .small {
        color: #94a3b8 !important;
    }
</style>
@endpush

@section('content')
<div class="complaint-detail-shell">
    <div class="complaint-detail-hero">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
            <div>
                <h3 class="complaint-detail-title">Detail Pengaduan Saya</h3>
                <p class="text-muted mb-0">Pantau isi laporan, respons admin, dan status penanganannya.</p>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <a href="{{ route('complaints.index') }}" class="btn btn-outline-secondary btn-sm">Kembali</a>
                <a href="{{ route('complaints.edit', $complaint) }}" class="btn btn-primary btn-sm">Edit Laporan</a>
            </div>
        </div>
    </div>

    @php
        $statusTheme = match($complaint->status) {
            'approved', 'process' => 'process',
            'rejected' => 'rejected',
            'done' => 'done',
            default => 'pending'
        };
        $statusLabel = match($complaint->status) {
            'approved' => 'Diproses',
            'rejected' => 'Ditolak',
            'process' => 'Diproses',
            'done' => 'Selesai',
            default => 'Pending'
        };
    @endphp

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="complaint-detail-card">
                <div class="complaint-detail-section">
                    <div class="complaint-detail-label">Laporan Anda</div>
                    @if($complaint->image_evidence_url)
                        <div class="mb-4">
                            <div class="complaint-evidence-box d-flex align-items-center justify-content-center">
                                <img src="{{ $complaint->image_evidence_url }}" alt="Lampiran" class="w-100 h-100" style="object-fit: contain;">
                            </div>
                        </div>
                    @endif

                    <h4 class="fw-semibold mb-3">{{ $complaint->title }}</h4>
                    <p class="mb-0 lh-lg">{{ $complaint->description }}</p>
                </div>
            </div>

            <div class="complaint-detail-card mt-4">
                <div class="complaint-detail-section">
                    <div class="d-flex justify-content-between align-items-center gap-3 flex-wrap mb-3">
                        <div class="complaint-detail-label mb-0">Respons Admin</div>
                        <span class="complaint-status-badge {{ $statusTheme }}">{{ $statusLabel }}</span>
                    </div>
                    @if($complaint->admin_response_message || $complaint->admin_action_taken || $complaint->admin_response_image_url)
                        <div class="complaint-response-box">
                            <div class="d-flex justify-content-between align-items-start gap-3 flex-wrap mb-3">
                                <div>
                                    <div class="fw-semibold">{{ $complaint->adminResponder->name ?? 'Admin' }}</div>
                                    <div class="small text-muted">
                                        {{ $complaint->admin_responded_at?->format('d M Y, H:i') ?? 'Waktu respons belum tersedia' }}
                                    </div>
                                </div>
                            </div>
                            @if($complaint->admin_response_message)
                                <div class="mb-3">
                                    <p class="text-muted mb-1">Pesan untuk Anda</p>
                                    <div class="lh-lg">{{ $complaint->admin_response_message }}</div>
                                </div>
                            @endif
                            @if($complaint->admin_action_taken)
                                <div class="mb-3">
                                    <p class="text-muted mb-1">Tindakan yang Dilakukan</p>
                                    <div class="lh-lg">{{ $complaint->admin_action_taken }}</div>
                                </div>
                            @endif
                            @if($complaint->admin_response_image_url)
                                <div>
                                    <p class="text-muted mb-2">Foto Tindak Lanjut</p>
                                    <div class="complaint-response-photo d-flex align-items-center justify-content-center">
                                        <img src="{{ $complaint->admin_response_image_url }}" alt="Foto tindak lanjut admin" class="w-100 h-100" style="object-fit: contain;">
                                    </div>
                                </div>
                            @endif
                        </div>
                    @else
                        <p class="mb-0 text-muted">Belum ada respons resmi dari admin untuk laporan ini.</p>
                    @endif
                </div>
            </div>

            <div class="complaint-detail-card mt-4">
                <div class="complaint-detail-section">
                    <div class="complaint-detail-label">Riwayat Status</div>
                    @forelse($complaint->statusHistories as $history)
                        @php
                            $oldLabel = match($history->old_status) {
                                'approved' => 'Diproses',
                                'rejected' => 'Ditolak',
                                'process' => 'Diproses',
                                'done' => 'Selesai',
                                'pending' => 'Pending',
                                default => $history->old_status ?? '-'
                            };
                            $newLabel = match($history->new_status) {
                                'approved' => 'Diproses',
                                'rejected' => 'Ditolak',
                                'process' => 'Diproses',
                                'done' => 'Selesai',
                                'pending' => 'Pending',
                                default => $history->new_status ?? '-'
                            };
                        @endphp
                        <div class="complaint-timeline-item">
                            <div class="complaint-timeline-card">
                                <div class="d-flex justify-content-between gap-3 flex-wrap mb-1">
                                    <strong>{{ $history->admin->name ?? 'Admin' }}</strong>
                                    <small class="text-muted">{{ $history->created_at->format('d M Y H:i') }}</small>
                                </div>
                                <div class="small">Status: {{ $oldLabel }} -> <strong>{{ $newLabel }}</strong></div>
                                @if($history->note)
                                    <div class="small text-muted mt-1">{{ $history->note }}</div>
                                @endif
                            </div>
                        </div>
                    @empty
                        <div class="text-muted">Belum ada perubahan status.</div>
                    @endforelse
                </div>
            </div>

            <div class="complaint-detail-card mt-4">
                <div class="complaint-detail-section">
                    <div class="d-flex justify-content-between align-items-center gap-3 flex-wrap mb-3">
                        <div class="complaint-detail-label mb-0">Chat dengan Admin</div>
                        <span class="complaint-status-badge {{ $complaint->allow_user_chat ? 'done' : 'pending' }}">
                            {{ $complaint->allow_user_chat ? 'Chat Aktif' : 'Menunggu Izin Admin' }}
                        </span>
                    </div>

                    @if(session('status') === 'chat-message-sent')
                        <div class="alert alert-success">Pesan chat berhasil dikirim ke admin.</div>
                    @endif

                    @if($complaint->allow_user_chat)
                        <div class="complaint-chat-box mb-3">
                            @forelse($complaint->comments as $comment)
                                <div class="complaint-chat-item {{ $comment->admin_id ? 'admin' : 'user' }}">
                                    <div class="complaint-chat-bubble {{ $comment->admin_id ? 'admin' : 'user' }}">
                                        <div class="d-flex justify-content-between gap-3 flex-wrap mb-1">
                                            <strong>{{ $comment->admin->name ?? $comment->user->name ?? 'User' }}</strong>
                                            <small class="text-muted">{{ $comment->created_at->format('d M Y H:i') }}</small>
                                        </div>
                                        <div class="small text-muted mb-2">
                                            {{ $comment->admin_id ? 'Admin' : 'Anda' }}
                                        </div>
                                        <div class="lh-lg">{{ $comment->comment }}</div>
                                    </div>
                                </div>
                            @empty
                                <div class="text-muted">Belum ada pesan. Anda bisa mulai chat dengan admin dari sini.</div>
                            @endforelse
                        </div>

                        <form method="POST" action="{{ route('complaints.chat.store', $complaint) }}">
                            @csrf
                            <div class="mb-3">
                                <label for="chat_message" class="form-label">Kirim Pesan</label>
                                <textarea
                                    id="chat_message"
                                    name="chat_message"
                                    rows="4"
                                    class="form-control @error('chat_message') is-invalid @enderror"
                                    placeholder="Tulis pertanyaan atau klarifikasi untuk admin...">{{ old('chat_message') }}</textarea>
                                @error('chat_message')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <button type="submit" class="btn btn-primary">Kirim ke Admin</button>
                        </form>
                    @else
                        <div class="complaint-chat-box">
                            <div class="fw-semibold mb-2">Chat belum dibuka</div>
                            <div class="text-muted">
                                Menu chat akan aktif setelah admin memberi izin dari halaman tindak lanjut laporan ini.
                            </div>
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="complaint-detail-card">
                <div class="complaint-detail-section">
                    <div class="complaint-detail-label">Ringkasan Laporan</div>
                    <div class="d-flex flex-column">
                        <div>
                            <p class="text-muted mb-1">Kategori</p>
                            <p class="mb-0 fw-medium">{{ $complaint->category->name ?? '-' }}</p>
                        </div>
                        <div class="complaint-summary-item">
                            <p class="text-muted mb-1">Status</p>
                            <span class="complaint-status-badge {{ $statusTheme }}">{{ $statusLabel }}</span>
                        </div>
                        <div class="complaint-summary-item">
                            <p class="text-muted mb-1">Tanggal</p>
                            <p class="mb-0 fw-medium">{{ $complaint->created_at->format('d M Y, H:i') }}</p>
                        </div>
                        <div class="complaint-summary-item">
                            <p class="text-muted mb-2">QR Pantau Laporan</p>
                            <div class="complaint-qr-box">
                                <div id="user-complaint-qr"></div>
                                <div class="small text-muted mt-2 text-center">Scan untuk membuka progres laporan ini.</div>
                            </div>
                        </div>
                        <div class="complaint-summary-item">
                            <p class="text-muted mb-2">Lokasi</p>
                            <div class="complaint-location-box small lh-lg">
                                @if($complaint->street_address)
                                    <div>{{ $complaint->street_address }}</div>
                                @endif
                                @if($complaint->village || $complaint->district || $complaint->city || $complaint->province)
                                    <div>{{ collect([$complaint->village, $complaint->district, $complaint->city, $complaint->province])->filter()->join(', ') }}</div>
                                @endif
                                @if($complaint->latitude && $complaint->longitude)
                                    <div class="mt-2">
                                        <span class="text-muted">GPS:</span> {{ $complaint->latitude }}, {{ $complaint->longitude }}
                                    </div>
                                    <a href="https://www.google.com/maps?q={{ $complaint->latitude }},{{ $complaint->longitude }}" target="_blank" rel="noopener noreferrer">Buka di Google Maps</a>
                                @endif
                                @if(!$complaint->street_address && !$complaint->village && !$complaint->district && !$complaint->city && !$complaint->province && !($complaint->latitude && $complaint->longitude))
                                    <span class="text-muted">Lokasi belum diisi.</span>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <script>
        (function () {
            const target = document.getElementById('user-complaint-qr');
            if (!target || typeof QRCode === 'undefined') {
                return;
            }

            new QRCode(target, {
                text: @json(route('complaints.show', $complaint)),
                width: 180,
                height: 180,
                correctLevel: QRCode.CorrectLevel.M
            });
        })();
    </script>
@endpush
