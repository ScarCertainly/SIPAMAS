<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('complaints', function (Blueprint $table) {
            $table->enum('location_source', ['manual', 'gps'])->nullable()->after('photo');
            $table->decimal('latitude', 10, 7)->nullable()->after('location_source');
            $table->decimal('longitude', 10, 7)->nullable()->after('latitude');
            $table->string('province')->nullable()->after('longitude');
            $table->string('city')->nullable()->after('province');
            $table->string('district')->nullable()->after('city');
            $table->string('village')->nullable()->after('district');
            $table->string('street_address')->nullable()->after('village');
        });
    }

    public function down(): void
    {
        Schema::table('complaints', function (Blueprint $table) {
            $table->dropColumn([
                'location_source',
                'latitude',
                'longitude',
                'province',
                'city',
                'district',
                'village',
                'street_address',
            ]);
        });
    }
};
